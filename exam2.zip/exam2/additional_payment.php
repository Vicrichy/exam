<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 2) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>DATAMIX Test Engine [Registration]</title>

<!-- BASIC CALENDAR HEADER -->
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

</style>


<script type="text/javascript" src="basiccalendar.js">


</script>

<!-- BASIC CALENDAR HEADER ENDS -->

</head>

<body background="images/reg_stuff.jpg">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("username","reg_no","title","surname","first_name","sex","address","mobile_phone","email","course","amount_paid","receipt_no");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("USERNAME","REG. NUMBER","TITLE","SURNAME","FIRST NAME","SEX","ADDRESS","MOBILE PHONE","EMAIL","COURSE","AMOUNT PAID","RECEIPT NUMBER");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
	
  <tr> 
    <td height="77" colspan="3" bgcolor="#008000">
<p align="center"><b><font size="5"><font color="#FFFFFF"><u><font face="Copperplate Gothic Bold">STUDENTS 
        REGISTRATION</font></u></font></font></b> 
      <form name="form1" method="post" action="logout.php">
        <div align="right">
          <input type="submit" name="Submit" value="Logout">
        </div>
      </form>
      
    </td>
		
    <td bgcolor="#FFFFFF">&nbsp; </td>
	</tr>
	<tr>
		
    <td width="23%" bgcolor="#000000" rowspan="3" valign="top"><strong><a href="additional_payment.php"><font color="#00FF33" size="3">[ADDITIONAL 
      PAYMENT]</font></a></strong> &nbsp; 
      <p>&nbsp;<a href="registration_page.php"><img border="0" src="images/register_students_bt.jpg" width="165" height="35"></a></p>
		
      <p> &nbsp;<a href="retrieve_data_scheduler_reg2.php"><img border="0" src="images/retrieve_reg_data_bt.jpg" width="165" height="35"></a></p>
		
      <p><a href="modify_reg_data.php"><img border="0" src="images/modify_reg_data_butt.jpg" width="172" height="35"></a> 
      </p>
		<p>&nbsp;<br>
		<br>
		&nbsp;</p>
		<p>&nbsp;
		</p>
		<p>&nbsp;</p>
		<p></td>
		
    <td width="66%" height="21" valign="top" bgcolor="#000000"><font color="#00FF00"><b> 
      ADDITIONAL PAYMENT</b></font></td>
		<td width="11%" valign="top">&nbsp; </td>
		<td width="0%" bgcolor="#008000" rowspan="3">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="66%" valign="top" height="377" rowspan="2">&nbsp;<font size="2"><b> 
      </b></font> 
      <form method="POST" action="insert_additional_payment.php"  enctype="multipart/form-data" onSubmit="return formCheck(this);">
        <p><b><font face="Agency FB" color="#CCCCCC" size="2"> </font></b></p>
			
        <p><font face="Agency FB"><b>REG. NUMBER<font color="#FF0000">*</font></b></font><b><font face="Agency FB">:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          </font><font size="3" face="Agency FB" color="#CCCCCC"> 
          <input type="text" name="reg_no" size="20">
          </font></b></p>
			
        <p><b><font face="Agency FB">COURSE<font color="#FF0000">*</font>:</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b><font face="Agency FB"><b> 
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="course" type="text" id="course" size="20">
          </b></font></p>
			
        <p><b><font face="Agency FB">AMOUNT PAID<font color="#FF0000">*</font>:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></b><font face="Agency FB"><b> 
          <input name="amount_paid" type="text" id="amount_paid" size="20">
          </b></font></p>
			
        <p><b><font face="Agency FB">RECEIPT NO<font color="#FF0000">*</font>:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          </font></b><font face="Agency FB"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input name="receipt_no" type="text" id="receipt_no" size="20">
          <input type="hidden" name="MAX_FILE_SIZE" value="1000000">
          </b></font></p>
			<p><b><font face="Agency FB">COMMENT:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
			
          <textarea name="comment" cols="26" rows="2" id="comment"></textarea>
          </font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</b></p>
			<p><font size="2"><b>&nbsp;</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			
          <input name="submit" type="submit" id="submit" value="ADD">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="reset" value="RESET" name="B2"></p>

		</form>
		</td>
		
    <td width="11%" valign="top" height="95">&nbsp; 
      <p>&nbsp;<script language="JavaScript" src="calendar.js"></script>

	<!-- BASIC CALENDAR BODY -->
	
	<script type="text/javascript">

var todaydate=new Date()
var curmonth=todaydate.getMonth()+1 //get current month (1-12)
var curyear=todaydate.getFullYear() //get current year

document.write(buildCal(curmonth ,curyear, "main", "month", "daysofweek", "days", 1));
</script>

<!-- BASIC CALENDAR BODY ENDS -->
</p>
		
    </td>
	</tr>
	<tr>
		<td width="11%" valign="top" height="188">
		<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bordercolorlight="#000080" bordercolordark="#00FFFF">
			
        <tr bgcolor="#000000"> 
          <td colspan="5" bordercolor="#00FFFF"><b> <font color="#00FFFF">COURSE 
            LIST </font></b></td>
			</tr>
			<tr>
				
          <td width="4%" rowspan="3" bgcolor="#00FF00">&nbsp;</td>
				
          <td width="2%" rowspan="3" bgcolor="#000080">&nbsp;</td>
				
          <td height="24" width="87%" bgcolor="#00FF00"><font color="#000080"><font size="2">While 
            registering a student, the course name must be entered exactly as 
            it is written below, else the record will not be saved.</font> </font></td>
				<td width="2%" rowspan="3" bgcolor="#000080">&nbsp;</td>
				
          <td width="4%" rowspan="3" bgcolor="#00FF00">&nbsp;</td>
			</tr>
			<tr>
				
          <td height="42" width="87%" bgcolor="#C0C0C0"> 
            
		    <?php 
 
  
//most sites have magic quotes on
//but if they do not, this code simulates magic quotes
if( !get_magic_quotes_gpc() )
{
    if( is_array($_POST) )
        $_POST = array_map('addslashes', $_POST);
}



include('dbconnect.php');

if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
    mysql_select_db('datamix');
	
 $query = "SELECT * FROM course_list";
			  //echo $query . "<br>\n";
          	
			$result = mysql_query($query);
			
$num_fields = mysql_num_fields($result);


echo "<table border = 1>";


//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
}
	          mysql_close($link); 	  
?>
          </td>
			</tr>
			<tr>
				
          <td bgcolor="#000000" width="87%">&nbsp;</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#008000">
		<p align="center"><b><font color="#FFFF00" size="2">Technology by  
        B-Low Solutions, Inc(08039098042)</font></b></td>
		<td bgcolor="#008000">&nbsp;
		</td>
		<td bgcolor="#FFFF00">&nbsp;
		</td>
	</tr>
</table>

</body>

</html>
<?php
}
?>