<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Exam Room</title>
</head>

<body>
<?php
// RETRIEVE THE NUMBER OF QUESTIONS ANSWERED BY THE CANDIDATE

include ('dbconnect.php');





$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;





// RETRIEVE CANDIDATE'S SURNAME

$query =mysql_query("select surname from registration_table where reg_no = '$_SESSION[reg_no]'");
$surname =mysql_result($query, 0, "surname");


// RETRIEVE CANDIDATE'S FIRST NAME

$query2 =mysql_query("select first_name from registration_table where reg_no = '$_SESSION[reg_no]'");
$firstname =mysql_result($query2, 0, "first_name");



// RETRIEVE MAX QUESTIONS
$query3 =mysql_query("select max_questions from candidate_login_table where course = '$_SESSION[course]' and test_type = '$_SESSION[test_type]' and test_date = '$system_date'");
$query_max_questions =mysql_result($query3, 0, "max_questions");


// RETRIEVE TEST DURATION
$query4 =mysql_query("select test_duration from candidate_login_table where course = '$_SESSION[course]' and test_type = '$_SESSION[test_type]' and test_date = '$system_date'");
$test_duration =mysql_result($query4, 0, "test_duration");






// RETRIEVE CANDIDATE'S DEPARTMENT

$query2a =mysql_query("select department from registration_table where reg_no = '$_SESSION[reg_no]'");
$department =mysql_result($query2a, 0, "department");

// RETRIEVE CANDIDATE'S PICTURE

$query2a =mysql_query("select pic from registration_table where reg_no = '$_SESSION[reg_no]'");
$pix =mysql_result($query2a, 0, "pic");

// RETRIEVE CANDIDATE'S CLASSROOM

$query2b =mysql_query("select classroom from registration_table where reg_no = '$_SESSION[reg_no]'");
$classroom =mysql_result($query2b, 0, "classroom");

// RETRIEVE CANDIDATE'S GENDER
$query30 =mysql_query("select gender from registration_table where reg_no = '$_SESSION[reg_no]'");
$gender=mysql_result($query30, 0, "gender");



// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


?>
<table width="979" height="503" border="1">
  <tr>
    <th width="318" align="left" valign="top" bgcolor="#B7FFB7" scope="col"><div align="left">
      <p><img src="untitled1.JPG" width="328" height="77" alt="1" /></p>
      <table width="325">
        <tr>
          <th bgcolor="#A3A3A3" scope="col"><div align="center">
            <p><strong><font face="Geneva, Arial, Helvetica, sans-serif">YOUR TEST DETAILS </font></strong></p>
            <p align="center">Please take note of your test details </p>
          </div></th>
        </tr>
      </table>
      <table width="326" border="1">
        <tr>
          <td width="98" bordercolor="#008000" bgcolor="#00FF00"><b> <font color="#000000" face="System">NAME:</font></b></td>
          <th scope="col"><div align="left"> <strong><?php echo "$firstname"; ?></strong> <strong><?php echo "$surname"; ?></strong></div></th>
        </tr>
        <tr>
          <td bordercolor="#008000" bgcolor="#808080"><span class="style4">DATE:</span></td>
          <td><strong><?php echo "$system_date"; ?></strong></td>
        </tr>
        <tr>
          <td bordercolor="#008000" bgcolor="#00FF00"><span class="style6">TEST TYPE:</span> </td>
          <td><strong><?php echo "$_SESSION[test_type]"; ?></strong></td>
        </tr>
        <tr>
          <td bordercolor="#008000" bgcolor="#808080"><span class="style4">REG.NO</span></td>
          <td><strong><?php echo "$_SESSION[reg_no]"; ?></strong></td>
        </tr>
        <tr>
          <td bordercolor="#008000" bgcolor="#00FF00"><span class="style7"><font face="System">COURSE:</font></span></td>
          <td><strong><?php echo "$_SESSION[course]"; ?></strong></td>
        </tr>
        <tr>
          <td width="98" bordercolor="#008000" bgcolor="#808080"><span class="style4">DEPARTMENT</span></td>
          <td><strong><?php echo "$department"; ?></strong></td>
        </tr>
        <tr>
          <td width="98" bordercolor="#008000" bgcolor="#00FF00"><b> <font color="#000000" face="System">CLASSROOM</font></b></td>
          <td><font color = "black"><strong><?php echo "$classroom"; ?></strong></font></td>
        </tr>
        <tr>
          <td width="98" bordercolor="#008000" bgcolor="#808080"><b><font face="System">NO OF QUESTIONS:</font></b></td>
          <td> <strong><?php echo "$query_max_questions"; ?></strong></td>
        </tr>
        <tr>
          <td width="98" valign="top" bordercolor="#008000" bgcolor="#00FF00"><b> <font color="#000000" face="System">DURATION:</font></b></td>
          <td><strong><?php echo "$test_duration"; ?> minutes</strong></td>
        </tr>
      </table>
      <p align="left">YOUR PICTURE <?php
	  //$reg_no = $_POST['reg_no'];
	 
	   if ($pix==""){
	  $picnull='female.jpg';
	  echo "<img src = 'pix/$picnull' height = '100' width = '100'>";
	  }
	 else
	  {
	  	  echo "<img src = 'pix/$pix' height = '100' width = '100'>";

	}
	 // echo "No picture available";
	  ?>
</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </div></th>
    <th width="645" valign="top" bgcolor="#B7FFB7" scope="col"><div align="center">
      <p align="left"><img src="untitled.JPG" width="640" height="77" alt="1" /></p>
      <table width="100" height="266" align="left">
        <tr>
          <th valign="top" scope="col"><div align="left">
            <?php
	echo "<h1>$display_no</h1>";
	
	?>
          </div></th>
        </tr>
      </table>
      <div align="left">
        <p><font size="+2"><b>
          <?php
	   
		   
		   
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{







//************* GENERATE RANDOM AND NON-REPETITIVE QUESTIONS. (I am using a Do loop to effect this).

do
{
include ('dbconnect.php');



// DETERMINE THE COURSE CODE
if (($_SESSION['test_type']) == 'Exam Re-sit')
{
$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_course = mysql_result($query_cc, 0, "course_code");

$query_coursecode = $query_course."_"."exam";
}
else
{
$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_course = mysql_result($query_cc, 0, "course_code");

$query_coursecode = $query_course."_".$_SESSION['test_type'];
}




// Determine the total number of questions available
$query_c = mysql_query("select count(question) from $query_coursecode where correct = 'right'");
$query_count = mysql_result($query_c, 0, "count(question)")
or die (mysql_error());


// Use this total to set the limit and initiate the random engine
mt_srand((double)microtime() * 1000000);
$number = mt_rand(1,$query_count);


//Check if the candidate has previously answered the question

$query_checkp = ("SELECT id FROM answered_questions WHERE reg_no = '$_SESSION[reg_no]' and 

course = '$_SESSION[course]' and id = '$number'");
$checkp = mysql_query($query_checkp);

$no_of_rows = mysql_num_rows($checkp) ;	


// Check if the number is available in the database table

$query_find = "SELECT id FROM $query_coursecode WHERE id = '$number'";
$result_find = mysql_query($query_find);
$no_available = mysql_num_rows($result_find);		 

}while(($no_of_rows > 0) or ($no_available == 0));

//******************************* RANDOM GENERATION ENDS






// SELECT A QUESTION
$query =mysql_query("select question from $query_coursecode where id = '$number'");
$now =mysql_result($query, 0, "question"); 
echo "$now";

//echo "$number";
}

?>
        </b></font></p>
        <p><font size="+2"><b>
          <?php


include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{



$question_count = 0 ;

// RETRIEVE THE NUMBER OF ANSWERED QUESTIONS

$query =mysql_query("select count(id) from answered_questions where reg_no = 

'$_SESSION[reg_no]' and course = '$_SESSION[course]'");
$question_query =mysql_result($query, 0, "count(id)");
$question_count = $question_query  ;

$display_no = $question_query + 1 ;


if (($_SESSION['test_type']) == 'Quiz')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}






if (($_SESSION['test_type']) == 'Exam')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}





if (($_SESSION['test_type']) == 'Exam Re-sit')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}

// DETERMINE THE AMOUNT OF TIME (IN MINUTES) SPENT BY THE CANDIDATE IN THIS SESSION

  $spent_time = round((time() - $_SESSION['start']) / 60) ; 
   

}
?>
          </b></font><font size="+2"><b>
          <?php

if (($question_count) >= ($query_max_questions) ) { 
header('Location: test_over.php');
}
?>
          </b></font><font size="+2"><b>
          <?php
if (($spent_time) >= ($query_max_time) ) { 
header('Location: test_over.php');
}
?>
        </b></font></p>
      </div>
      <p align="left">&nbsp;</p>
      <p align="left">&nbsp;</p>
      <p align="left">&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><br />
      </p>
      <p>&nbsp;</p>
    </div></th>
  </tr>
  <tr>
    <th width="318" rowspan="2" align="left" valign="top" bgcolor="#B7FFB7" scope="col">&nbsp;</th>
    <td valign="top"><div align="left">
      <p><strong>CHOOSE AN OPTION, AND CLICK &quot;SUBMIT ANSWER&quot; BUTTON TO ANSWER THE QUESTION </strong></p>
      </div></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#B7FFB7"><form id="form1" name="form1" method="post" action="">
      <table width="642" border="1">
        <tr>
          <th width="90" scope="col"><div align="left">A
            <label>
            <input name="radiobutton" type="radio" value="radiobutton" />
            <br />
            <?php
 // DETERMINE THE ID for the question
			//$query1 =mysql_query("select id from $query_coursecode where question = '$now'");
            // $move =mysql_result($query1, 0, "id"); 
             ?>
            <input type="hidden" name="move_number" size="20" value='<?php
	echo "$number";
	?>' />
            <br />
            </label>
          </div></th>
          <th width="534" scope="col"><div align="left">
            <?php
		// THE BLOCK OF CODES BELOW, PRINTS OUT THE OPTIONS FOR EACH INDIVIDUAL 

//QUESTION BESIDE EACH OPTION BUTTON

		
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'A'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);


echo "<table border = 0>";

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?>
          </div></th>
        </tr>
        <tr>
          <td>B
            <label>
            <input name="radiobutton" type="radio" value="radiobutton" />
            </label></td>
          <td><?php
	
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'B'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);


echo "<table border = 0>";

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?></td>
        </tr>
        <tr>
          <td>C
            <label>
            <input name="radiobutton" type="radio" value="radiobutton" />
            </label></td>
          <td><?php
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'C'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);


echo "<table border = 0>";

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?></td>
        </tr>
        <tr>
          <td>D
            <label>
            <input name="radiobutton" type="radio" value="radiobutton" />
            </label></td>
          <td><?php

$query =("select obj from $query_coursecode where id = '$number' and alpha = 'D'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

echo "<b>\n";
echo "<table border = 0>";

//create table body
echo "<b>\n";
echo "<tr font size=+10>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
echo "<b>\n";
echo "<b>";
while( list ($key, $value) = each($row) )
{
echo "<b>\n";
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";



// OPTION PRINTING ENDS
?></td>
        </tr>
        <tr>
          <td colspan="2"><label>
            <input type="submit" name="Submit" value="Submit" />
          </label></td>
          </tr>
      </table>
        </form>
    <p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <th width="318" align="left" valign="top" scope="col">&nbsp;</th>
    <td valign="top">&copy;2009. Afrihub Nigeria </td>
  </tr>
</table>
</body>
</html>
