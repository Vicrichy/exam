<?php

$course = $_POST['course'];
$no = $_POST['no'];
$test_type = $_POST['test_type'];
$pwd = 1;
$password = 1;
$dept = $_POST['department'];
$code = $_POST['code'];
$reg_no = $code.''.$no;

if($dept=='Comp. Repairs and Maintenance - 1st Semester')
{
include('dbconnect.php');

$fcheck1 = mysql_query("SELECT `reg_no` FROM `broadsheet_repairs` WHERE `reg_no` = '$reg_no'");

$num_rows = mysql_num_rows($fcheck1);

if($num_rows<1)
{
mysql_query("INSERT INTO `broadsheet_repairs` SET `reg_no`='$reg_no'");
}
}
elseif($dept=='Sec.Administration - 1st Semester')
{
include('dbconnect.php');

$fcheck2 = mysql_query("SELECT `reg_no` FROM `broadsheet_sec` WHERE `reg_no` = '$reg_no'");

$num_rows2 = mysql_num_rows($fcheck2);

if($num_rows2<1)
{
mysql_query("INSERT INTO `broadsheet_sec` SET `reg_no`='$reg_no'");
}
}

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");

// EXTRACT SYSTEM TIME ( note that the time is formated in 24hr mode, and with a decimal point
// for example 4:35pm is 16.35

$computer_time = date("G");



// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

  
         
    // open connection 
include ('dbconnect.php');
 
$course = $_POST['course'];
$reg_no = $_POST['reg_no'];
$test_type = $_POST['test_type'];
$password = 1;
$accesscode= 1;
$pwd = 1;


// CHECK IF ACCESS CODE IS INCORRECT
$queryxx="SELECT password FROM quiz_password WHERE password = '$accesscode'";
$resultxx=mysql_query($queryxx);


if (mysql_num_rows($resultxx) == 0) {
header('Location: password_incorrect.php');
}
else
{

// THIS CODE CHECKS IF THE CANDIDATE HAS PREVIOUSLY TAKEN THIS TEST

$check_can = "SELECT * FROM test_records WHERE test_type = '$test_type' AND reg_no = '$reg_no' AND course = '$course'";

$resultcan = mysql_query($check_can);

if (mysql_num_rows($resultcan) > 0)
{
header('Location: test_previously_taken_error.php');
mysql_close($link);
}

else
{




// THIS CODE CHECKS IF THE SPECIFIED COURSE DOES NOT EXIST

include('dbconnect.php');



$queryx="SELECT course FROM course_list WHERE course = '$course'";
$resultx=mysql_query($queryx);

if (mysql_num_rows($resultx) == 0 ) {
header('Location: course_does_not_exist.htm');
mysql_close($link);
} 
else 
{


// THIS CODE CHECKS IF THE SPECIFIED PASSWORD MATCHES WITH THE REG.NUMBER

 include('dbconnect.php');



$queryx="SELECT * FROM registration_table WHERE password = '$pwd' AND reg_no = '$reg_no'";
$resultx=mysql_query($queryx);

if (mysql_num_rows($resultx) >=1 ) {
header('Location: wrong_user_exam_password.php');
mysql_close($link);
} 
else 
{
 
 
 
// THIS CODE CHECKS IF THE SPECIFIED REG.NO DOES NOT EXIST
  
if (isset($_POST['reg_no'])) {
 include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


$queryx1="SELECT reg_no FROM registration_table WHERE reg_no = '$reg_no'";
$resultx1=mysql_query($queryx1);

if (mysql_num_rows($resultx1) == 0) {
header('Location: regno_does_not_exist.htm');
mysql_close($link);
} 
else 
{



 // THIS CODE CHECKS IF THE SPECIFIED COURSE DOES NOT EXISTS IN THE LOGIN TABLE. IT ALSO CHECKS IF THE SPECIFIED COURSE AND TEST TYPE WAS ACTIVATED.

if (isset($_POST['course'])) {

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;



 include('dbconnect.php');
 
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


$queryxx="SELECT course FROM candidate_login_table WHERE course = '$course' AND test_type = '$test_type' AND test_date = '$system_date'";
$resultxx=mysql_query($queryxx);

if (mysql_num_rows($resultxx) == 0) {
header('Location: course_not_authorised.htm');
mysql_close($link);
} 
else 
{




// THIS CODE CHECKS IF THE SYSTEM TIME IS LESS THAN THE CONFIGURED TEST TIME
include('dbconnect.php');
$query_datex = mysql_query("SELECT test_set_time FROM candidate_login_table WHERE course = '$course' AND test_type = '$test_type' AND test_date = '$system_date'");
$query_datex1 =mysql_result($query_datex, 0, "test_set_time"); 
 
    if (($computer_time) < $query_datex1) {
   header('Location: invalid_time.htm');
   mysql_close($link);
} 
else 
{
 


// THIS CODE CHECKS IF THE SYSTEM DATE
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

include('dbconnect.php');


$query_datex = mysql_query("SELECT test_date FROM candidate_login_table WHERE course = '$course' AND test_type = '$test_type'");
$query_datex1 =mysql_result($query_datex, 0, "test_date"); 
 
    if (($system_date) != $query_datex1) {
   header('Location: invalid_date.htm');
   mysql_close($link);
} 
else 
{
 
session_start();
$_SESSION['dept'] = $_POST['department']; 
$_SESSION['auth'] = 3;
$_SESSION['course'] = $_POST['course']; 
$_SESSION['reg_no'] = $_POST['reg_no'];
$_SESSION['test_type'] = $_POST['test_type']; 
$_SESSION['start'] = time();
session_register('dept'); 
session_register('course'); 
session_register('reg_no'); 
session_register('test_type'); 
header('Location: quiz_frame.php');
    
	}
}     
}
}
}
}
}
}
}
}
}
}
//}
//}
//}

?> 