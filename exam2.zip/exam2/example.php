<?php
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

$query = mysql_query("SELECT course FROM candidate_login_table WHERE reg_no = 1001 AND course = 'course_list'");
$course = mysql_result($query, 0, "course");

echo "$course";

$query =("select * from $course");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

}

?>

