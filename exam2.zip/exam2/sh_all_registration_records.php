<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>etest TEST ENGINE</title>
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

</style>
<bgsound src="file:///C|/Documents%20and%20Settings/MY%20OFFICE/Desktop/scrap/Installing%20E-desk/e-desk1.1/swordraw.wav" loop="1">

</head>

<body scroll = "yes">

<table border="0" cellpadding="0" style="border-collapse: collapse" width="101%" height="100%">
	<tr>
		
    <td height="41" colspan="5" bgcolor="#000000"> <font face="Bodoni MT Black" color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </font> <font face="Arial Narrow" color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <b><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </font></b></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"> 
      <font color="#FF0000">&lt;&nbsp;RETURN</font></a></font></td>
	</tr>
	<tr>
		
    <td height="27" colspan="5" bgcolor="#808080"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size="4">DATABASE 
      OUTPUT&nbsp;&nbsp; &nbsp;&nbsp; </font></b></td>
	</tr>
	<tr>
		<td width="6%" bgcolor="#000000" valign="top" rowspan="3">&nbsp;
		</td>
		<td width="74%" bgcolor="#CCCCCC" valign="top" height="19">
		<p><strong>REGISTRATION RECORDS</strong><font size="2"> </font></p>
		</td>
		<td width="5%" bgcolor="#000000" valign="top" rowspan="3">&nbsp;
		</td>
		<td width="7%" bgcolor="#808080" valign="top" rowspan="3">&nbsp;
		</td>
	</tr>
	<tr>
		
    <td width="74%" bgcolor="#00FFFF" valign="top" height="280"> 
      <?php
include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{



//create table header
echo "<html><head><title>REGISTRATION RESULT</title></head>";
echo "<body><center><h1><font color='maroon'>REGISTRATION:</font></h1><table cellspacing='2' cellpadding='0' width='800'>";
echo "<tr><th bgcolor=#5888C2 ><font face='Arial' color='white' width='100%'>SERIAL NO.</th><th bgcolor=#5888C2><font face='Arial' color='white'>REG. DATE</th><th bgcolor=#5888C2><font face='Arial' color='white'>PASSWORD</th><th bgcolor=#5888C2><font face='Arial' color='white'>REG NO</th><th bgcolor=#5888C2><font face='Arial' color='white'>SURNAME</th><th bgcolor=#5888C2><font face='Arial' color='white'>FIRST NAME</th><th bgcolor=#5888C2><font face='Arial' color='white'>OTHERNAMES</th><th bgcolor=#5888C2><font face='Arial' color='white'>GENDER</th><th bgcolor=#5888C2><font face='Arial' color='white'>COURSE</th><th bgcolor=#5888C2><font face='Arial' color='white'>ADDRESS</th> <th bgcolor=#5888C2><font face='Arial' color='white'>PHONE</th><th bgcolor=#5888C2><font face='Arial' color='white'>PICTURE</th><th bgcolor=#5888C2><font face='Arial' color='white'>DELETE</th>";
//end table header

//echo '<td><a href="delete.php">Delete</a></td>';
$query1 = mysql_query("SELECT `pic` FROM `registration_table` ORDER BY surname");
while($rows = mysql_fetch_array($query1) )
{
  $pix = $rows['pic'];
 } 
$query =("select id, REG_DATE,PASSWORD, REG_NO,SURNAME, FIRST_NAME, OTHERNAMES, GENDER, COURSE, ADDRESS, PHONE from registration_table ORDER BY surname");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);
$color="#FFFFFF";
//create table body

while($row=mysql_fetch_row($result))
{
//$query3b =mysql_query("select pic from registration_table ORDER BY surname");
//$pix=mysql_result($query3b, 0, "pic");

if($color=="#b8d5ff")
	{
//$pix = $row[9];
echo "<tr bgcolor=$color>";
echo "<td width='20%'>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td aligh='center'>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td>";
echo"<td>"."<img src = 'pix/$pix' height = '50' width = '80'>"."</td>";
echo"<td>".'<a href="delete_record_page.php">[DELETE]</a>'."</td>";
	$color="#FFFFFF";
		}
		
	else
	{

	
echo "<tr bgcolor=$color>";
echo "<td width='20%'>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td aligh='center'>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td>";
echo"<td>"."<img src = 'pix/$pix' height = '50' width = '80'>"."</td>";
echo"<td>".'<a href="delete_record_page.php">[DELETE]</a>'."</td>";
	$color="#b8d5ff";
	}

}
}
?>
    </td>
	</tr>
	<tr>
		<td width="74%" bgcolor="#CCCCCC" valign="top">&nbsp;
		</td>
	</tr>
	<tr>
		<td height="26" bgcolor="#808080" colspan="5"><FORM>
        <p align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="button" type="button" onClick="window.print()" value="PRINT OUT">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        </p>
      </FORM>&nbsp;</td>
	</tr>
	<tr>
		<td height="26" width="6%" bgcolor="#000000">&nbsp;</td>
		<td height="22" bgcolor="#000000" colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<font color="#FFFFFF">&nbsp;&nbsp;&nbsp;</font></td>
		<td height="26" width="8%" bgcolor="#000000">&nbsp;</td>
	</tr>
</table>

</body>

</html>