<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>DATAMIX TEST ENGINE</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background = "images/reg_stuff.jpg">
<table width="98%" height="451" border="1">
  <tr> 
    <td height="28" colspan="5" bgcolor="#003300"><p align="center"><font color="#FFFFFF" size="5"><strong>LOGON 
        NIGERIA MULTIMEDIA SERVICES LTD</strong></font></p>
      <p align="right"><b><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;back</font></a></font></b></p></td>
  </tr>
  <tr> 
    <td height="37" colspan="5" bgcolor="#00FF00"><div align="center"><strong><font size="5">ONGOING 
        CLASSES</font></strong></div></td>
  </tr>
  <tr> 
    <td width="2%" rowspan="3" bgcolor="#003300"> <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    <td width="23%" height="31" valign="top" bgcolor="#CCCCCC"><strong>CLASSES</strong></td>
    <td colspan="2" bgcolor="#CCCCCC"><strong>STUDENT LIST</strong></td>
    <td width="2%" rowspan="3" bgcolor="#003300">&nbsp;</td>
  </tr>
  <tr> 
    <td height="211" valign="top" bgcolor="#00FF00">
<p>&nbsp; 
        <?php
	$computer_date_day =date("d");
   $computer_date_month =date("n");
    $computer_date_year =date("Y");
	$dash = "-" ;
	$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
	
	
	
	include('dbconnect.php');
	mysql_select_db('datamix');
	
	//SHOW THE CLASSES
	
	$query = ("SELECT DISTINCT course FROM classes WHERE date <= '$system_date'");
	$result = mysql_query($query)
	or die (mysql_error());
$num_fields = mysql_num_fields($result);

//create table body

echo "<table border = 0>";

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
 
	
	?>
      </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp; </p></td>
    <td colspan="2" valign="top"><?php
	// SHOW THE STUDENTS
	
	$query = ("SELECT SURNAME, FIRST_NAME, MIDDLE_NAME, COURSE FROM classes WHERE date <= '$system_date' order by COURSE");
	$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

	
	
	?>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
  <tr> 
    <td height="21" valign="top" bgcolor="#003300">&nbsp;</td>
    <td width="24%" bgcolor="#003300">&nbsp;</td>
    <td width="49%" bgcolor="#003300">&nbsp;</td>
  </tr>
</table>
</body>
</html>
