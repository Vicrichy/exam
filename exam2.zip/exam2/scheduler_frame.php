<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>E:TEST :: Test Manager Panel</title>
</head>

<frameset rows="94,*,20" cols="*">
  <frame name="top" scrolling="no" noresize target="contents" src="scheduler_top.php">
  <frameset cols="150,*">
    <frame name="contents" target="main" src="scheduler_left.php">
    <frame name="main" src="scheduler_middle.php">
  </frameset>
  <frame name="bottom" scrolling="no" noresize target="contents" src="scheduler_bottom.php">
  <noframes>
  <body>
  <p>This page uses frames, but your browser doesn't support them.</p>
  </body>
  </noframes>
</frameset>

</html>
<?php
}
?>
