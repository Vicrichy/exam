<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>etest</title>
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

</style>
<bgsound src="file:///C|/Documents%20and%20Settings/MY%20OFFICE/Desktop/scrap/Installing%20E-desk/e-desk1.1/swordraw.wav" loop="1">

</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="101%" height="100%">
	<tr>
		
    <td height="41" colspan="5" bgcolor="#000000"> <font face="Bodoni MT Black" color="#FFFFFF">etest&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </font> <font face="Arial Narrow" color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <b><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </font></b></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"> 
      <font color="#FF0000">&lt;&nbsp;GO BACK</font></a></font></td>
	</tr>
	<tr>
		
    <td height="27" colspan="5" bgcolor="#808080"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#CCCCCC"> 
      <font size="4">DATABASE OUTPUT</font></font><font size="4">&nbsp;&nbsp; 
      &nbsp;&nbsp; </font></b></td>
	</tr>
	<tr>
		<td width="4%" bgcolor="#000000" valign="top" rowspan="3">&nbsp;
		</td>
		<td width="91%" bgcolor="#CCCCCC" valign="top" height="19">
		<p><strong>REGISTRATION RECORDS</strong></p>
		</td>
		<td width="2%" bgcolor="#000000" valign="top" rowspan="3">&nbsp;
		</td>
		<td width="2%" bgcolor="#808080" valign="top" rowspan="3">&nbsp;
		</td>
	</tr>
	<tr>
		
    <td width="91%" bgcolor="#00FFFF" valign="top" height="280"> 
      <?php
	

 $course=$_POST['course'];
 $session=$_POST['session'];
 $batch=$_POST['batch'];

	
include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
if ($session=="")
{
$query =("select id, REG_DATE,PASSWORD, REG_NO,SURNAME, FIRST_NAME, OTHERNAMES,DEPARTMENT, GENDER, COURSE,BATCH,CLASSROOM, SESSION, ADDRESS, PHONE, EMAIL from registration_table where course = '$course' ORDER BY surname");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);
}
else
{
$query =("select id, REG_DATE,PASSWORD, REG_NO,SURNAME, FIRST_NAME, OTHERNAMES,DEPARTMENT, GENDER, COURSE,BATCH,CLASSROOM, SESSION, ADDRESS, PHONE, EMAIL from registration_table where course = '$course' and session='$session' and Batch='$batch' ORDER BY surname");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);
$color="#FFFFFF";
}

//create table header
echo "<html><head><title>REGISTRATION RESULT</title></head>";
echo "<body><center><h1><font color='maroon'>REGISTRATION:</font></h1><table cellspacing='2' cellpadding='0' width='800'>";
echo "<tr><th bgcolor=#5888C2 ><font face='Arial' color='white' width='100%'>SERIAL NO.</th><th bgcolor=#5888C2><font face='Arial' color='white'>REG. DATE</th><th bgcolor=#5888C2><font face='Arial' color='white'>PASSWORD</th><th bgcolor=#5888C2><font face='Arial' color='white'>REG NO</th><th bgcolor=#5888C2><font face='Arial' color='white'>SURNAME</th><th bgcolor=#5888C2><font face='Arial' color='white'>FIRST NAME</th><th bgcolor=#5888C2><font face='Arial' color='white'>OTHERNAMES</th><th bgcolor=#5888C2><font face='Arial' color='white'>DEPARTMENT</th><th bgcolor=#5888C2><font face='Arial' color='white'>GENDER</th><th bgcolor=#5888C2><font face='Arial' color='white'>COURSE</th><th bgcolor=#5888C2><font face='Arial' color='white'>BATCH</th> <th bgcolor=#5888C2><font face='Arial' color='white'>CLASS ROOM</th><th bgcolor=#5888C2><font face='Arial' color='white'>SESSION</th><th bgcolor=#5888C2><font face='Arial' color='white'>ADDRESS</th> <th bgcolor=#5888C2><font face='Arial' color='white'>PHONE</th><th bgcolor=#5888C2><font face='Arial' color='white'>EMAIL</th>";
//end table header

//create table body
$color="#FFFFFF";
while($row=mysql_fetch_row($result))
{
if($color=="#b8d5ff")
	{
	echo "<tr bgcolor=$color>";
echo "<td width='20%'>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td aligh='center'>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td><td>".$row[11]."</td><td>".$row[12]."</td><td>".$row[13]."</td><td>".$row[14]."</td><td>".$row[15]."</td>";
	$color="#FFFFFF";
		}
	else
	{
echo "<tr bgcolor=$color>";
echo "<td width='20%'>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td aligh='center'>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td><td>".$row[11]."</td><td>".$row[12]."</td><td>".$row[13]."</td><td>".$row[14]."</td><td>".$row[15]."</td>";
	$color="#b8d5ff";
	}
}
}
?>
    </td>
	</tr>
	<tr>
		<td width="91%" bgcolor="#CCCCCC" valign="top">&nbsp;
		</td>
	</tr>
	<tr>
		<td height="26" width="100%" bgcolor="#808080" colspan="5"><FORM>
        <p align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="button" type="button" onClick="window.print()" value="PRINT OUT">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        </p>
      </FORM>
    </td>
	</tr>
	<tr>
		<td height="26" width="4%" bgcolor="#000000">&nbsp;</td>
		<td height="22" width="95%" bgcolor="#000000" colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td height="26" width="1%" bgcolor="#000000">&nbsp;</td>
	</tr>
</table>

</body>

</html>