<title>DATAMIX</title><?php
//THIS SCRIPT THE USERNAME AND PASSWORD TO ONLY THE SUBSCRIPTION TABLE
//uncomment for debugging
 $month=$_POST['month'];
 $day=$_POST['day'];
 $year=$_POST['year'];
 $pv_number=$_POST['pv_number'];
 $particulars=$_POST['particulars'];
 $description=$_POST['description'];
 $amount=$_POST['amount'];
 
   
 
  
 
//most sites have magic quotes on
//but if they do not, this code simulates magic quotes
if( !get_magic_quotes_gpc() )
{
    if( is_array($_POST) )
        $_POST = array_map('addslashes', $_POST);
}



//THIS CODE CHECKS THE AVAILABILITY OF THE SPECIFIED ITEM



if (isset($_POST['description'])) {
    include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

$queryx=("select item from account_items where item = '$description'");
$resultx=mysql_query($queryx);

if (mysql_num_rows($resultx) == 0) {
header('Location: unavailable_item.html');
mysql_close($link);
} 
else 
{
//ITEM AVAILABILITY CHECK ENDS

//THIS CODE CHECKS IF THE RECORD WITH THE SPECIFIED PV NUMBER, ACTUALLY EXISTS


include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

$query0=("Select * From account_records Where pv_number = '$pv_number'");
$result0=mysql_query($query0);

if (mysql_num_rows($result0) > 0) {
header('Location: pv_no_already_exists.html');
mysql_close($link);

// NAME CHECK ENDS
} 
else 
{



//we can store the order in a database as well
 
 include ('dbconnect.php');



if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
    mysql_select_db('datamix');
	
	
	

 
 
    $query  = "INSERT INTO account_records
              ( month , day , year , pv_number , particulars , description , amount )";
			
   $query .= " VALUES
             ( '$month' , '$day' , '$year' , '$pv_number' , '$particulars' , '$description' , '$amount' )";
   
			  //echo $query . "<br>\n";
 
          	
			$result = mysql_query($query);
	          	  
		
		
//we should state the order was sent
header('Location: record_saved.html');
} 
}
}
}
}
}
			 mysql_close($link);

?>