<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#CCCCCC">
<p><b><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;back</font></a></font></b></p>
<p><strong>DEBTORS LIST </strong></p>
<p>&nbsp;
<?php
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-" ;

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


include('dbconnect.php');
mysql_select_db('datamix');

$query = ("SELECT SURNAME, FIRST_NAME, C_DATE FROM registration_table WHERE c_date <= '$system_date' AND payment_status = 'PARTIAL' ");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?>
</body>
</html>
