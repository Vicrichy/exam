<?php

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with correct details</p></i></b>";
} 

else { 

?> 
<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>new page 4</title>
<meta name="Microsoft Theme" content="water 1011, default">
<base target="rtop">

<meta http-equiv="Page-Enter" content="revealTrans(Duration=5.0,Transition=3)">

<SCRIPT type="text/javascript">

 function down()
{ 
    document.mypic.src="x.jpg"
}

</SCRIPT>


<style type="text/css">
<!--
.style1 {font-size: 12}
.style4 {font-family: System}
.style6 {font-family: System; color: #000000; }
.style7 {
	color: #000000;
	font-weight: bold;
}
.style8 {color: #000000}
.style9 {
	color: #009900;
	font-family: "Courier New", Courier, monospace;
	font-weight: bold;
	font-size: 14px;
}
-->
</style>
</head>

<body bgcolor="#000000" text="white" link="#FFFFFF" vlink="#FF0000" alink="#FFFFFF">
<?php
// RETRIEVE THE NUMBER OF QUESTIONS ANSWERED BY THE CANDIDATE

include ('dbconnect.php');





$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;





// RETRIEVE MAX QUESTIONS
$query3 =mysql_query("select max_questions from candidate_login_table where course = '$_SESSION[course]' and test_type = '$_SESSION[test_type]' and test_date = '$system_date'");
$query_max_questions =mysql_result($query3, 0, "max_questions");


// RETRIEVE TEST DURATION
$query4 =mysql_query("select test_duration from candidate_login_table where course = '$_SESSION[course]' and test_type = '$_SESSION[test_type]' and test_date = '$system_date'");
$test_duration =mysql_result($query4, 0, "test_duration");


// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


?>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="409">
  <tr> 
    <td bgcolor="#009900" colspan="3"> 
      <p align="left"><b><font color="#00FF00" face="Bodoni MT Black">B-LOW SOLUTIONS, INC </font><font face="Bodoni MT Black" color="#FFFFFF"><br>
    &nbsp;</font></b></td>
  </tr>
  <tr>
    <td bgcolor="#00CC00" colspan="3"><div align="center"><strong>TEST DETAILS </strong></div></td>
  </tr>
  <tr>
    <td width="4" bgcolor="#009900"><p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>
    <td width="372" bgcolor="#FFFFFF">
	<p class="style9">Below are your test details.  Goodluck.</p>
	<table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="372" bordercolor="#008000">
        <tr> 
          <td width="98" bgcolor="#00FF00"><b> <font color="#000000" face="System">NAME:</font></b></td>
          <td width="266"><span class="style8 style4"><strong>&nbsp; <?php echo $_SESSION['name']; ?></strong></span></td>
        </tr>
        <tr>
          <td bgcolor="#808080"><span class="style4">DATE:</span></td>
          <td><span class="style8 style4"><strong>&nbsp;<?php echo "$system_date"; ?></strong></span></td>
        </tr>
        <tr>
          <td bgcolor="#00FF00"><span class="style6">DEPARTMENT:</span> </td>
          <td><span class="style8 style4"><strong>&nbsp;<?php echo "$_SESSION[dept]"; ?></strong></span></td>
        </tr>
        <tr>
          <td bgcolor="#808080"><span class="style4">REG.NO</span></td>
          <td><span class="style8 style4"><strong>&nbsp;<?php echo "$_SESSION[reg_no]"; ?></strong></span></td>
        </tr>
        <tr>
          <td bgcolor="#00FF00"><span class="style7"><font face="System">COURSE:</font></span></td>
          <td><span class="style8 style4"><strong>&nbsp;<?php echo "$_SESSION[course]"; ?></strong></span></td>
        </tr>
        <tr> 
          <td width="98" bgcolor="#808080"><b><font face="System">NO OF QUESTIONS:</font></b></td>
          <td><span class="style8 style4"><strong>&nbsp; <?php echo "$query_max_questions"; ?></strong></span></td>
        </tr>
        <tr> 
          <td width="98" height="24" valign="top" bgcolor="#00FF00"><b> <font color="#000000" face="System">DURATION:</font></b></td>
          <td height="24"><span class="style8 style4"><strong><font color="#000000" face="System">&nbsp; <?php echo "$test_duration"; ?> 
            minutes</strong></span></td>
        </tr>
    </table>
    �</p>&nbsp;
    <?php
	  //$reg_no = $_POST['reg_no'];
	 
	   if ($pix==""){
	  $picnull='female.jpg';
	  echo "<img src = 'pix/$picnull' height = '100' width = '100'>";
	  }
	 else
	  {
	  	  echo "<img src = 'pix/$pix' height = '100' width = '100'>";

	}
	 // echo "No picture available";
	  ?> 
    </p>
    <p>&nbsp;</p>   </td>
    <td width="25" bgcolor="#009900">&nbsp;</td>
  </tr>
  
  <tr>
    <td bgcolor="#009900" colspan="3">&nbsp;</td>
  </tr>
</table>

<p> 
  <iframe src="indicator.php" name="I1" width="320" height="150" class="style1"> Your browser 
  does not support inline frames or is currently configured not to display inline 
  frames. </iframe>
</p>
<p>&nbsp;</p>

</body>

</html>
<?php
}
?>