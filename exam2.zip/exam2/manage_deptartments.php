<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 2</title></head>

<body bgcolor="#CC99FF">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array( "course_code","course_name","credit_load","course_cost");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array( "COURSE CODE","COURSE NAME","CREDIT LOAD","COURSE COST");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>


<SCRIPT language="JavaScript" type="text/javascript">
function validatePwd(course_code) {

//Initialise variables
var errorMsg = "";
var space  = " ";
fieldname   = course_code; 
fieldvalue  = fieldname.value; 
fieldlength = fieldvalue.length; 
 
//It must not contain a space
if (fieldvalue.indexOf(space) > -1) {
     errorMsg += "\nThere should be no spacing.\n";
}     

//It must start with at least one letter     
if (!(fieldvalue.match(/^[a-zA-Z]+/))) {
     errorMsg += "\nThe course code must start with at least one letter.\n";
}

//If there is aproblem with the form then display an error
     if (errorMsg != ""){
          msg = "______________________________________________________\n\n";
          msg += "An error was detected in the Course code value you specified.\n";
          msg += "______________________________________________________\n";
          errorMsg += alert(msg + errorMsg + "\n\n");
		  //Clear the field if there is a problem
		  fieldname.value = "";
          document.data.cand_emaill_t.focus();
          return false;
     }
     
     return true;
}

</SCRIPT>




<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
	<tr>
		<td bgcolor="#000000" colspan="4">&nbsp;</td>
	</tr>
	<tr>
		<td width="1%" bgcolor="#000000" rowspan="6">&nbsp;<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p></td>
		<td bgcolor="#000080" colspan="2">
		<p align="center"><b><font size="5" color="#00FF00">MANAGE DEPARTMENTS </font>
		</b></td>
		<td width="4%" bgcolor="#000000" rowspan="6">&nbsp;</td>
	</tr>
	<tr>
		<td height="19" colspan="2">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="12%" height="160" bgcolor="#000080" valign="top" rowspan="2"> <u><b><font color="#00FF00" size="2"><br>
    </b></u><u> </u>
    <p></td>
		<td width="83%" height="30" bgcolor="#000066">
		<font color="#000080" face="Arial Black"><b>&nbsp;</b></font><font color="#00FF00"><strong>CREATE DEPARTMENT </strong></font></td>
	</tr>
	<tr>
		<td width="83%" height="130">This panel enables you to create, or delete the 
		institution's academic departments/disciplines that would be used in this software.
		  <p>It is important that you create your departments here. During 
		registration, the software would reject any record with a course that 
		was not created here.<br>
		<br>
		To create a department, you need to specify the the department's name, and click the &quot;CREATE&quot; button.</p>
	  <p></td>
	</tr>
	<tr>
		
    <td height="117" colspan="2" valign="top" bordercolor="#660000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <form method="POST" action="insert_create_dept_script.php" onSubmit="return formCheck(this);">
			<!--webbot bot="SaveResults" U-File="file:///C:/Documents and Settings/MY OFFICE/My Documents/FILE CABINET/MY WORKS/weboptionsict.com/_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CREATE DEPARTMENT<br> 
		  &nbsp;&nbsp;<br>
	      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>DEPT.</strong><b> NAME</b>&nbsp; 
            <input name="dept_name" type="text" id="dept_name" size="35">
        </p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			  <input type="submit" value="CREATE" name="B1">&nbsp;&nbsp;&nbsp;
		<input type="reset" value="RESET" name="B2"></p>
	  </form>
		<table width="100%" border="1">
        <tr>
          <td bgcolor="#000066"><font color="#00FF00"><strong>DEPARTMENT LIST</strong></font></td>
        </tr>
        <tr>
          <td height="65">
<form name="form2" method="post" action="sh_department_list.php">
              <input type="submit" name="Submit2" value="VIEW DEPARTMENT LIST">
            </form>
            <p>&nbsp;</p>
            <p>&nbsp;</p></td>
        </tr>
      </table> 
      <table width="100%" border="1">
        <tr>
          <td bgcolor="#000066"><strong><font color="#00FF00">DELETE DEPARTMENT </font></strong></td>
        </tr>
        <tr>
          <td><p>Here, you can delete an academic department. To delete a department, please specify 
              the department name and click Delete.</p>
            <form name="form1" method="post" action="delete_department.php">
              DEPT. NAME 
                <input name="dept_name" type="text" id="dept_name">
              <input type="submit" name="Submit" value="DELETE DEPARTMENT">
            </form>
            <p>&nbsp;</p>
            <p>&nbsp;</p></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table> </td>
	</tr>
	<tr>
	  <td height="118" colspan="2" valign="top" bordercolor="#660000">&nbsp;</td>
  </tr>
	<tr>
		<td bgcolor="#000000" colspan="4">&nbsp;</td>
	</tr>
</table>

</body>

</html>
<?php
}
?>