<?php

// DECLARE VARIABLES
$testmode =$_POST['testmode'];
$date_taken =$_POST['date_taken'];
$department =$_POST['department'];
$course =$_POST['course'];
$operator =$_POST['operator'];
$reason =$_POST['reason'];
$this_score =$_POST['this_score'];

$ip = getenv("REMOTE_ADDR");
$host = gethostbyaddr ("$ip");

$dash = "-";



// Extract system date

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$test_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// CHECK IF THE COURSE EXISTS
include('dbconnect.php');





// Retrieve candidate's surname

$query =mysql_query("select surname from registration_table where reg_no = '$reg_no'");
$surname =mysql_result($query, 0, "surname");


// Retrieve candidate's first name

$query2 =mysql_query("select first_name from registration_table where reg_no = '$reg_no'");
$firstname =mysql_result($query2, 0, "first_name");

$full_name = $surname."&nbsp;".$firstname ;








// CHECK IF THE SPECIFIED COURSE EXISTS
$query2="Select course from course_list where course = '$course'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) == 0) {
header('Location: course_does_not_exist.php');
mysql_close($link);
} 
else 
{



include('dbconnect.php');







// RETRIEVE THE CANDIDATE'S FORMER SCORE
$query_score = mysql_query("SELECT score FROM test_records WHERE department = '$department' and course= '$course' and test_type = '$testmode' and test_date = '$date_taken'");
$former_score = mysql_result($query_score, 0, "score");



// RETRIEVE THE MAX_SCORE 

$query_date = mysql_query("SELECT max_score FROM test_records WHERE department = '$department' and course= '$course' and test_type = '$testmode' and test_date = '$date_taken'");
$max_score =mysql_result($query_date, 0, "max_score"); 








//***********************PROCESS THE OPERATION

if(($operator)== 'ADD')
{

$new_score = $former_score + $this_score ;
			  
}
else
{
$new_score = $former_score - $this_score ;
}			  
			  





// IF ITS QUIZ, PERFORM THE FOLLOWING:

if(($testmode)== 'Quiz')

{


// CALC THE PERCENTAGE

// Percent:

$score_percent = round(($new_score / $max_score) * 100) ;




// DETERMINE GRADE
if(($score_percent) < 40)
{
$grade = "F";
}
elseif(($score_percent) >= 40 && ($score_percent) <= 44 )
{
$grade = "E";
}
elseif(($score_percent) >= 45 && ($score_percent) <= 49 )
{
$grade = "D";
}
elseif(($score_percent) >= 50 && ($score_percent) <= 59 )
{
$grade = "C";
}
elseif(($score_percent) >= 60 && ($score_percent) <= 69 )
{
$grade = "B";
}
else
{
$grade = "A";
}



// IF ITS EXAM, PERFORM THE FOLLOWING:

if(($testmode)== 'Exam')

{


// RETRIEVE THE CANDIDATE'S QUIZ SCORE
$query_score = mysql_query("SELECT score FROM test_records WHERE department = '$department' and course= '$course' and test_type = 'Quiz'");
$former_score = mysql_result($query_score, 0, "score");

// CALC THE PERCENTAGE

// Percent:



$score_percent = round(($new_score / $max_score) * 100) ;




// DETERMINE GRADE
if(($score_percent) < 40)
{
$grade = "F";
}
elseif(($score_percent) >= 40 && ($score_percent) <= 44 )
{
$grade = "E";
}
elseif(($score_percent) >= 45 && ($score_percent) <= 49 )
{
$grade = "D";
}
elseif(($score_percent) >= 50 && ($score_percent) <= 59 )
{
$grade = "C";
}
elseif(($score_percent) >= 60 && ($score_percent) <= 69 )
{
$grade = "B";
}
else
{
$grade = "A";
}





// UPDATE THE TEST_RECORDS WITH THE $NEW SCORE
			  
			  
$update1 = mysql_query("UPDATE test_records SET score = '$new_score' WHERE department = '$department' and course= '$course' and test_type = '$testmode' and test_date = '$date_taken'");



// UPDATE THE TEST_RECORDS WITH THE PERCENT

$update2 = mysql_query("UPDATE test_records SET percentage = '$score_percent' WHERE department = '$department' and course= '$course' and test_type = '$testmode' and test_date = '$date_taken'");



// UPDATE THE TEST_RECORDS WITH THE GRADE

$update3 = mysql_query("UPDATE test_records SET grade = '$grade' WHERE department = '$department' and course= '$course' and test_type = '$testmode' and test_date = '$date_taken'");



// RECORD THE OPERATION IN THE upgrade_monitor

$r_insert = "INSERT INTO upgrade_monitor
             (action_date, test_date, reg_no, full_name, test_type, course, former_score, mode, added_subtracted, new_score, reason, system_ip, system_name)";
			 
$r_insert .= "VALUES
              ('$system_date', '$test_date', '$reg_no', '$full_name', '$testmode', '$course', '$former_score', '$operator', '$this_score', '$new_score', '$reason', '$ip', '$host')";
			  
			  $resultr = mysql_query($r_insert);
			  
}	


// IF ITS EXAM OR EXAM RE-SIT PERFORM THE FOLLOWING:

}


		  
header('Location: score_upgraded.php');

			  

?>