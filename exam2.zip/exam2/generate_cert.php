<HTML>
<head>
<title> DATAMIX TEST ENGINE </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Page-Enter" content="revealTrans(Duration=5.0,Transition=3)">
</head><body bgcolor="#FFFFFF">
<?php $reg_no=$_POST['reg_no']; ?>
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="100%">
	<tr>
		
    <td height="109" bgcolor="#008000" colspan="4"> <font face="Blackadder ITC" size="2" color="#FFFF00"><a href="javascript:history.back()" style="margin-right:5px;"> 
      </a></font>&nbsp;&nbsp;<img src="images/sunshine_logo.gif" width="239" height="89">&nbsp;&nbsp;<font face="Blackadder ITC" color="#FFFF00" size="5">Sunshine 
	Guest House Annex</font></td>
	</tr>
	<tr>
		<td width="5%" bgcolor="#00FF00" rowspan="6">&nbsp;<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p></td>
		<td width="45%" height="29" bgcolor="#FFFF00"><font size="6">Guest Bill</font></td>
		<td width="45%" height="29">&nbsp;</td>
		<td width="5%" bgcolor="#00FF00" rowspan="6">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="90%" colspan="2" height="61"><font face="Comic Sans MS"> Thanks, 
      <?php echo "$full_name" ?> , for lodging with us. </font>
<p></td>
	</tr>
	<tr>
		
    <td width="90%" colspan="2" height="34" bgcolor="#C0C0C0"><b>DETAILED 
	EXPENSES 
      </b></td>
	</tr>
	<tr>
		
    <td width="90%" colspan="2" height="76"> 
      <?php

//uncomment for debugging
 
 $full_name=$_POST['full_name'];
 $full_name=$_POST['full_name'];
 $lodgeout_date=$_POST['lodgeout_date']; 
 $room_number=$_POST['room_number'];
 
 
//most sites have magic quotes on
//but if they do not, this code simulates magic quotes
if( !get_magic_quotes_gpc() )
{
    if( is_array($_POST) )
        $_POST = array_map('addslashes', $_POST);
}

//THIS CODE CHECKS IF THE REGISTRATION NUMBER EXISTS
$reg_no = $_POST['reg_no'];


if (isset($_POST['reg_no'])) {
include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

// RETRIEVE CANDIDATE'S SURNAME

$query =mysql_query("select surname from registration_table where reg_no = '$reg_no'");
$surname =mysql_result($query, 0, "surname");

// RETRIEVE CANDIDATE'S MIDDLE NAME

$query =mysql_query("select middle_name from registration_table where reg_no = '$reg_no'");
$middlename =mysql_result($query, 0, "middle_name");


// RETRIEVE CANDIDATE'S FIRST NAME

$query2 =mysql_query("select first_name from registration_table where reg_no = '$reg_no'");
$firstname =mysql_result($query2, 0, "first_name");

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");

$query0=("Select full_name, room_number From lodgers_current Where full_name = '$full_name' and room_number = '$room_number'");
$result0=mysql_query($query0);

if (mysql_num_rows($result0) == 0) {
header('Location: invalid_name.html');
mysql_close($link);

// NAME CHECK ENDS
} 
else 
{

//we can store the order in a database as well
 
include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
    mysql_select_db('datamix');
	
	
 $query3 = "DELETE FROM lodgers_current WHERE full_name = '$full_name' and room_number = '$room_number'";
               
		  $result = mysql_query($query3);
}
}
}
?>
      <?php
 $query2 = "UPDATE room_list SET full_name = 'empty' WHERE full_name = '$full_name' AND room = '$room_number'";
            $result = mysql_query($query2);
			
?>
      <?php 
      $query1 = "UPDATE lodgers SET lodgeout_date = '$lodgeout_date' WHERE full_name = '$full_name'";
               
		  $result = mysql_query($query1);
?>
      <?php
	  
//THE CODE BELOW PRINTS THE DETAILED EXPENSES
 
$query =("select DATE, DESCRIPTION, AMOUNT_PAID, PAYMENT_MODE from compiled where full_name='$full_name'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";


?>
      &nbsp;<br>
<hr>
      <table width="88%" border="0">
        <tr>
          <td width="55%">
            <?php 
	  // THE CODES BELOW, PRINTS OUT THE CUSTOMERS EXTRA ROOM-PAYMENTS, IF ANY.
	  

  $query6 =("select EXTRA_PAYMENT_DATE 'DATE', EXTRA_PAYMENT 'ADDITIONAL ROOM PAYMENT' from compiled where full_name='$full_name' AND description = 'Room Payment'");
$result = mysql_query($query6)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

}


//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?>
          </td>
          <td width="45%"><?php 
	  // THE CODES BELOW, PRINTS OUT THE CUSTOMERS EXTRA DEPOSIT PAYMENTS, IF ANY.
	  

  $query7 =("select EXTRA_DEPOSIT_DATE 'DATE', EXTRA_DEPOSIT 'ADDITIONAL DEPOSIT MADE' from compiled where full_name='$full_name' AND description = 'Room Payment'");
$result = mysql_query($query7)
or die (mysql_error());
$num_fields = mysql_num_fields($result);




//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?></td>
        </tr>
      </table> 
      
    </td>
	</tr>
	<tr>
		
    <td width="90%" colspan="2" height="37" bgcolor="#C0C0C0">&nbsp;</td>
	</tr>
	<tr>
		<td width="90%" colspan="2">
		  
		  
<p><strong><u>OUTSTANDING BILLS</u></strong></p>
      <p><?php 
	  // THE CODES BELOW, PRINTS OUT THE OUTSTANDING BILLS.
	  

  $query7 =("select DATE, DESCRIPTION, AMOUNT_PAID, PAYMENT_MODE from compiled where full_name='$full_name' AND PAYMENT_MODE = 'CREDIT'");
$result = mysql_query($query7)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
// OUTSTANDING BILLS, ENDS
?>
<br>
        <br>
        <strong><u>TOTAL SUMMARY OF 'CASH' PAID BILLS</u></strong></p>
      <table border="3" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bordercolorlight="#00FF00" bordercolordark="#008000">
	<tr>
	 
		  <td bgcolor="#008000" width="198"><font color="#FFFFFF"><b>DEPOSIT 
			(Naira)</b></font></td>
		  <td bgcolor="#008000" width="252">&nbsp;<font color="#FFFFFF"><b>SUM OF 
			EXPENSES (Naira)</b></font></td>
		  <td bgcolor="#008000">&nbsp;<font color="#FFFFFF"><b>BALANCE (Naira)</b></font></td>
	</tr>
	<tr>
		  <td width="198">
		  <?php 
		 // THE CODE BELOW, PRINTS OUT THE CUSTOMERS DEPOSIT PAYMENT 
		 
		  $full_name=$_POST['full_name'];
		  $sql = "SELECT DEPOSIT + EXTRA_DEPOSIT FROM compiled WHERE full_name = '$full_name'"; 

$result = mysql_query($sql)
or die (mysql_error());
echo "<table>\n";
//if I don&#8217;t use MYSQL_ASSOC or MYSQL_NUM, each row will
//be retrieved twice, and I don&#8217;t want that
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
echo "<tr>";
while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

 ?>
</td>
		  <td width="252">
		  <?php 
		  // THE CODE BELOW, SUMS UP AND PRINTS OUT THE CUSTOMERS TOTAL EXPENSES
		  
		  $sql2 = "SELECT SUM( AMOUNT_PAID ) + SUM( EXTRA_PAYMENT) FROM compiled WHERE full_name = '$full_name' AND PAYMENT_MODE = 'CASH'"; 

$result2 = mysql_query($sql2)
or die (mysql_error());
echo "<table>\n";
//if I don&#8217;t use MYSQL_ASSOC or MYSQL_NUM, each row will
//be retrieved twice, and I don&#8217;t want that
while ($row = mysql_fetch_array($result2, MYSQL_ASSOC))
{
echo "<tr>";
while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?>
</td>
		  <td>
		  <?php
		  // THE CODE BELOW, SUBTRACTS THE CUSTOMERS HOTEL EXPENSES FROM HIS DEPOSIT PAYMENT TO GIVE THE BALANCE
		   
		  $sql3 = "SELECT (SUM(DEPOSIT) + SUM(EXTRA_DEPOSIT))-(SUM( AMOUNT_PAID ) + SUM( EXTRA_PAYMENT)) FROM compiled WHERE full_name = '$full_name' AND PAYMENT_MODE = 'CASH'"; 
		  $result3 = mysql_query($sql3)
or die (mysql_error());
echo "<table>\n";
//if I don&#8217;t use MYSQL_ASSOC or MYSQL_NUM, each row will
//be retrieved twice, and I don&#8217;t want that
while ($row = mysql_fetch_array($result3, MYSQL_ASSOC))
{
echo "<tr>";
while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";


$query_balance = mysql_query("SELECT (SUM(DEPOSIT) + SUM(EXTRA_DEPOSIT))-(SUM( AMOUNT_PAID ) + SUM( EXTRA_PAYMENT)) FROM compiled WHERE full_name = '$full_name' AND PAYMENT_MODE = 'CASH'"); 
		  $balance = mysql_result($query_balance, 0, "(SUM(DEPOSIT) + SUM(EXTRA_DEPOSIT))-(SUM( AMOUNT_PAID ) + SUM( EXTRA_PAYMENT))");
		  
?>
 </td>
	</tr>
</table>
		  
		  
      <p align="center"> </td>
	</tr>
	
  <tr> 
    <td height="48" bgcolor="#008000" colspan="4">
<FORM>
        <p align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
		&nbsp;&nbsp;&nbsp;&nbsp;<input name="button" type="button" onClick="window.print()" value="PRINT OUT">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="verdana" size="2" color="white"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000"> 
        &lt;&nbsp;RETURN</font></a></font> 
        </p>
      </FORM> 
      <p align="left">&nbsp;</p></td>
	</tr>
</table>
<?php
$queryh = "DELETE FROM compiled WHERE full_name = '$full_name'";
               
		  $resulth = mysql_query($queryh);

// RECORD THE GUEST'S BALANCE

$query_insert = "INSERT INTO balance
                 (date, balance)";
$query_insert .="VALUES
                  ('$lodgeout_date', '$balance')";
				  
				   $resulti = mysql_query($query_insert);
?>
</body>
</html>   
