<?php
session_start();
include('dbconnect.php');

$query = mysql_query("SELECT * FROM `receipt` WHERE `reg_no` = '$_SESSION[reg_no]'");

while($row = mysql_fetch_array($query))
{
 $full_name = $row['name'];
 $code = $row['code'];
 $date = $row['timestamp'];
 $amount = $row['amount'];
 $course = $row['course'];
}

session_register('$full_name');
session_register('$code');
session_register('$date');
session_register('$amount');
session_register('$course');

$_SESSION['full_name'] = $full_name;
$_SESSION['code'] = $code;
$_SESSION['date'] = $date;
$_SESSION['amount'] = $amount;
$_SESSION['course'] = $course;

header("location:receipt.php");



?>