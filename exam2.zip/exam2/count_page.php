<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="refresh" content="2;url=http://localhost/smartquiz/count_page.php">
<title>New Page 1</title>
</head>

<body bgcolor="#000000">
<font face="Terminal" size="6" color="#00FF00">

<?php 
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('smartquiz');

			$query1 =mysql_query("select count(count_no) from keep_count");
             $count =mysql_result($query1, 0, "count(count_no)"); 
			 echo "$count";
			 
			 mysql_close($link);
}
             ?>
</font>
</body>

</html>
