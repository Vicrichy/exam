<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 1) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST   [CONTROL PANEL]</title>

<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style></head>

<body bgcolor="#CC99FF">
<!-- Form validation for CREATE NEW -->
<script language="JavaScript">
<!--

/***********************************************
* Required field(s) validation v1.10- By NavSurf
* Visit Nav Surf at http://navsurf.com
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

function formCreate(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("new");
	// Enter field description to appear in the dialog box
	var fieldDescription = Array("Create New Password");
	// dialog message
	var alertMsg = "Please complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<!-- Form validation for CHANGE PASSWORD -->
<script language="JavaScript">
<!--

/***********************************************
* Required field(s) validation v1.10- By NavSurf
* Visit Nav Surf at http://navsurf.com
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

function formChange(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("change_old", "change_new");
	// Enter field description to appear in the dialog box
	var fieldDescription = Array("New Password", "Old Password" );
	// dialog message
	var alertMsg = "Please complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<!-- Form validation for DELETE PASSWORD -->
<script language="JavaScript">
<!--

/***********************************************
* Required field(s) validation v1.10- By NavSurf
* Visit Nav Surf at http://navsurf.com
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

function formDelete(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("delete");
	// Enter field description to appear in the dialog box
	var fieldDescription = Array("Password to delete");
	// dialog message
	var alertMsg = "Please complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<table border="0" cellpadding="0" style="border-collapse: collapse" width="98%" height="100%">
  <tr> 
    <td height="41" colspan="14" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr> 
    <td height="27" colspan="14" bgcolor="#808080">&nbsp;</td>
  </tr>
  <tr> 
    <td width="8" bgcolor="#000000" valign="top" rowspan="10"> &nbsp; <p>&nbsp;</p>
      <p> </p>
      <p>  </a></p>
      <p>&nbsp;</p></td>
    <td width="16" bgcolor="#CC99FF" valign="top" rowspan="10">&nbsp; </td>
    <td width="16" bgcolor="#CC99FF" valign="top" rowspan="10">&nbsp; </td>
    <td width="16" bgcolor="#000000" valign="top" rowspan="10">&nbsp; </td>
    <td bgcolor="#000000" valign="top" height="38" colspan="8"> <font color="#FFFFFF"><b>PASSWORD 
      MANAGEMENT CONSOLE</b></font><br> &nbsp;</td>
    <td width="13" bgcolor="#000000" valign="top" rowspan="10">&nbsp; </td>
  </tr>
  <tr> 
    <td bgcolor="#CC99FF" valign="top" colspan="8"> &nbsp; 
      <form method="POST" action="sh_all_passwords.php">
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SHOW ALL PASSWORDS" name="B1">
        </p>
      </form>
      <p>&nbsp;</p>
      <p></td>
  </tr>
  <tr> 
    <td bgcolor="#808080" valign="top" colspan="8"> <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></td>
  </tr>
  <tr> 
    <td width="133" bgcolor="#000000" valign="top" height="19"> <b>
	<font color="#FFFFFF">REGISTRATION</font></b></td>
    <td width="8" bgcolor="#000000" valign="top" height="19">&nbsp; </td>
    <td bgcolor="#000000" valign="top" height="19"> 
	<font color="#FFFFFF"><b>ACCESS CODE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
    <td bgcolor="#000000" valign="top" height="19">&nbsp;</td>
    <td bgcolor="#000000" valign="top" height="19"><font color="#FFFFFF"><b>TEST 
	MANAGER </b></font></td>
    <td bgcolor="#000000" valign="top" height="19">&nbsp; </td>
    <td bgcolor="#000000" valign="top" height="19"><div align="center"><span class="style1">AUTHORIZED<br>
    VIEWER</span></div></td>
  </tr>
  <tr> 
    <td width="133" bgcolor="#CC99FF" valign="top" height="185"> 
      <form method="POST" action="create_new_password_registration.php" onSubmit="return formCreate(this);">
        <p><b>CREATE NEW<br>
          </b><br>
          Enter the new password<br>
          <input type="text" name="new" size="20">
          <br>
          &nbsp; 
          <input type="submit" value="CREATE NEW" name="B2">
        </p>
      </form>
      <hr> <b><br>
      </b>
      <hr></td>
    <td width="8" height="185" rowspan="6" valign="top" bgcolor="#000000">&nbsp;</td>
    <td width="174" height="-4" valign="top" bgcolor="#CC99FF"> 
      <form method="POST" action="create_new_access_code.php" onSubmit="return formCreate(this);">
        <p><b>CREATE NEW<br>
          </b><br>
          Enter the new password<br>
          <br>
          <input type="text" name="new" size="20">
          <br>
          &nbsp; 
          <br>
&nbsp;<input type="submit" value="CREATE NEW" name="B27">
        </p>
      </form>
      <hr> <b><br>
      </b>
      <hr></td>
    <td width="11" height="185" rowspan="6" valign="top" bgcolor="#000000">&nbsp; </td>
    <td width="149" height="-4" valign="top" bgcolor="#CC99FF"> 
      <form method="POST" action="create_new_password_manager.php" onSubmit="return formCreate(this);">
        <p><b>CREATE NEW<br>
          </b><br>
          Enter the new password<br>
          <br>
          <input type="text" name="new" size="20">
          <br>
          &nbsp; 
          <br>
		<br>
          <input type="submit" value="CREATE NEW" name="B30">
        <br>
&nbsp;</p>
      </form>
      <hr>
      <b><br>
      </b>
      <hr></td>
    <td width="5" height="185" rowspan="6" valign="top" bgcolor="#000000">&nbsp; </td>
    <td width="120" height="-4" valign="top" bgcolor="#CC99FF"><form method="POST" action="create_new_password_aviewer.php" onSubmit="return formCreate(this);">
      <p><b>CREATE NEW</b><br>
        Enter the new password<br>
        <br>
        <input name="new" type="text" id="new" size="20">
        <br>
        &nbsp; <br>
        <br>
        <input type="submit" value="CREATE NEW" name="B302">
        <br>
        &nbsp;</p>
    </form>
      <br></td>
    <td width="2" height="185" rowspan="6" valign="top" bgcolor="#C0C0C0">&nbsp; </td>
  </tr>
  <tr>
    <td bgcolor="#CC99FF" valign="top" height="92"><b>CHANGE PWD</b><br>
Enter the old password 
  <form method="POST" action="change_password_registration.php" onSubmit="return formChange(this);">
    <p>
      <input name="change_old" type="text" id="change_old" size="20">
      <br>
      Enter the new password
      <input name="change_new" type="text" id="change_new" size="20">
      <br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="submit" value="CHANGE" name="B22">
    </p>
  </form></td>
    <td width="174" height="-2" valign="top" bgcolor="#CC99FF"><b>CHANGE PWD</b><br>
Enter the old password 
  <form method="POST" action="change_access_code.php" onSubmit="return formChange(this);">
    <p> <br>
        <input name="change_old" type="text" id="change_old" size="20">
        <br>
        <br>
      Enter the new password
      <input name="change_new" type="text" id="change_new" size="20">
      <br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="submit" value="CHANGE" name="B28">
    </p>
  </form></td>
    <td width="149" height="-2" valign="top" bgcolor="#CC99FF"><b>CHANGE PWD</b><br>
Enter the old password
  <form method="POST" action="change_password_manager.php" onSubmit="return formChange(this);">
    <p>
      <input name="change_old" type="text" id="change_old" size="20">
      <br>
      <br>
      <br>
      Enter the new password
      <input name="change_new" type="text" id="change_new" size="20">
      <br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="submit" value="CHANGE" name="B31">
    </p>
  </form></td>
    <td width="120" height="-2" valign="top" bgcolor="#CC99FF"><b>CHANGE PWD</b><br>
Enter the old password 
  <form method="POST" action="change_password_aviewer.php" onSubmit="return formChange(this);">
    <p>
      <input name="change_old" type="text" id="change_old" size="20">
      <br>
      Enter the new password
      <input name="change_new" type="text" id="change_new" size="20">
      <br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="submit" value="CHANGE" name="B312">
    </p>
  </form></td>
  </tr>
  <tr>
    <td bgcolor="#CC99FF" valign="top" height="185"><form method="POST" action="delete_password_registration.php" onSubmit="return formChange(this);">
      <p>&nbsp;</p>
      <p><b>DELETE PWD<br>
              </b>Enter password <br>
          <input name="delete" type="text" id="delete" size="20">
          <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" value="DELETE" name="B23">
        </p>
    </form></td>
    <td width="174" height="-2" valign="top" bgcolor="#CC99FF"><form method="POST" action="delete_access_code.php" onSubmit="return formChange(this);">
      <p>&nbsp;</p>
      <p><b>DELETE PWD<br>
              </b>Enter password <br>
          <input name="delete" type="text" id="delete" size="20">
          <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" value="DELETE" name="B29">
        </p>
    </form></td>
    <td width="149" height="-2" valign="top" bgcolor="#CC99FF"><form method="POST" action="delete_password_manager.php" onSubmit="return formChange(this);">
      <p><b><br>
          <br>
          DELETE PWD<br>
        </b>Enter password <br>
        <input name="delete" type="text" id="delete" size="20">
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" value="DELETE" name="B32">
      </p>
    </form></td>
    <td width="120" height="-2" valign="top" bgcolor="#CC99FF"><form method="POST" action="delete_password_aviewer.php" onSubmit="return formChange(this);">
      <p><b><br>
        <br>
      </b><b>DELETE PWD<br>
          </b>Enter password <br>
          <input name="delete" type="text" id="delete" size="20">
          <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" value="DELETE" name="B322">
        </p>
      </form></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CC99FF">&nbsp;</td>
    <td width="174" height="-1" valign="top" bgcolor="#CC99FF">&nbsp;</td>
    <td width="149" height="-1" valign="top" bgcolor="#CC99FF">&nbsp;</td>
    <td width="120" height="-1" valign="top" bgcolor="#CC99FF">&nbsp;</td>
  </tr>
  
  <tr>
    <td bgcolor="#CC99FF" valign="top" height="24">&nbsp;</td>
    <td width="174" height="24" valign="top" bgcolor="#CC99FF">&nbsp;</td>
    <td width="149" height="24" valign="top" bgcolor="#CC99FF">&nbsp;</td>
    <td width="120" height="24" valign="top" bgcolor="#CC99FF">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#CC99FF" valign="top" height="19">&nbsp;</td>
    <td width="174" height="19" valign="top" bgcolor="#CC99FF">&nbsp;</td>
    <td width="149" height="19" valign="top" bgcolor="#CC99FF">&nbsp;</td>
    <td width="120" height="19" valign="top" bgcolor="#CC99FF">&nbsp;</td>
  </tr>
  <tr> 
    <td height="26" bgcolor="#808080" colspan="14">&nbsp;</td>
  </tr>
  <tr> 
    <td height="26" bgcolor="#000000" colspan="4">&nbsp;</td>
    <td height="26" bgcolor="#000000" colspan="9">&nbsp;</td>
    <td height="26" width="34" bgcolor="#000000">&nbsp;</td>
  </tr>
</table>

</body>

</html>

<?php
}
?>