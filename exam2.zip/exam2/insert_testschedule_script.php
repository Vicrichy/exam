<?php

$testmode =$_POST['testmode'];
//$reg_no =$_POST['reg_no'];
$course =$_POST['course'];
$start_time =$_POST['start_time'];
$duration =$_POST['duration'];
$max_questions =$_POST['max_questions'];
$max_score =$_POST['max_score'];
$dash = "-";

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$test_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;



if (isset($_POST['submit'])) {
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{



// CHECK IF THE COURSE EXISTS

$query2="Select course from course_list where course = '$course'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) == 0) {
header('Location: course_does_not_exist.php');
mysql_close($link);
} 
else 
{

include ('dbconnect.php');





// INSERT TO DATABASE

include('dbconnect.php');






if (($testmode) == 'Quiz')
{
include('dbconnect.php');


// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$test_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


//Insert to candidate login

$q_insert = "INSERT INTO candidate_login_table
             (test_date, test_set_time, test_type, course, max_time, max_questions, max_score,  test_duration)";

$q_insert .= "VALUES
              ('$test_date', '$start_time', '$testmode', '$course', '$duration', '$max_questions', '$max_score', '$duration')";
			  
			  $resultq = mysql_query($q_insert);

}



if (($testmode) == 'Exam')
{
include('dbconnect.php');


// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$test_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;




//Insert to candidate login

$q_insert = "INSERT INTO candidate_login_table
             (test_date, test_set_time, test_type, course, max_time, max_questions, max_score,  test_duration)";

$q_insert .= "VALUES
              ('$test_date', '$start_time', '$testmode', '$course', '$duration', '$max_questions', '$max_score', '$duration')";
			  
			  $resultq = mysql_query($q_insert);

}


if (($testmode) == 'Exam Re-sit')
{
include('dbconnect.php');


// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$test_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;





//Insert to candidate login

$q_insert = "INSERT INTO candidate_login_table
             (test_date, test_set_time, test_type, course, max_time, max_questions, max_score,  test_duration)";

$q_insert .= "VALUES
              ('$test_date', '$start_time', '$testmode', '$course', '$duration', '$max_questions', '$max_score', '$duration')";
			  
			  $resultq = mysql_query($q_insert);
}






			  
			  
				  
header('Location: test_activated.html');
}
}
}

?> 