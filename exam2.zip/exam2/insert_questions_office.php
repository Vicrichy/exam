<?php

session_start();

include('dbconnect.php');

//$course = $_POST['course'];

$pac = mysql_query("SELECT count(id) FROM $_SESSION[course] ORDER BY id");
$id = @mysql_result($pac, 0, "count(id)");
$numbers = range(1,50);
shuffle($numbers);

$number1 .= $numbers[0];
$number2 .= $numbers[1];
$number3 .= $numbers[2];
$number4 .= $numbers[3];
$number5 .= $numbers[4];
$number6 .= $numbers[5];
$number7 .= $numbers[6];
$number8 .= $numbers[7];
$number9 .= $numbers[8];
$number10 .= $numbers[9];
$number11 .= $numbers[10];
$number12 .= $numbers[11];
$number13 .= $numbers[12];
$number14 .= $numbers[13];
$number15 .= $numbers[14];
$number16 .= $numbers[15];
$number17 .= $numbers[16];
$number18 .= $numbers[17];
$number19 .= $numbers[18];
$number20 .= $numbers[19];
$number21 .= $numbers[20];
$number22 .= $numbers[21];
$number23 .= $numbers[22];
$number24 .= $numbers[23];
$number25 .= $numbers[24];
$number26 .= $numbers[25];
$number27 .= $numbers[26];
$number28 .= $numbers[27];
$number29 .= $numbers[28];
$number30 .= $numbers[29];
$number31 .= $numbers[30];
$number32 .= $numbers[31];
$number33 .= $numbers[32];
$number34 .= $numbers[33];
$number35 .= $numbers[34];
$number36 .= $numbers[35];
$number37 .= $numbers[36];
$number38 .= $numbers[37];
$number39 .= $numbers[38];
$number40 .= $numbers[39];

$course = $_SESSION['course'];
//Insert 1st question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number1'");
$now = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now' AND id= '$number1'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number1','$course','$now','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','1')");
include('dbconnect.php');
mysql_query("INSERT INTO offline(username,course,correct_1)VALUES('$_SESSION[reg_no]','$course','$correct')");
//Insert 2nd question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number2'");
$now2 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now2' AND id= '$number2'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number2','$course','$now2','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','2')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_2` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
//Insert 3rd question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number3'");
$now3 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now3' AND id= '$number3'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number3','$course','$now3','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','3')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_3` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
//Insert 4th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number4'");
$now4 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now4' AND id= '$number4'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number4','$course','$now4','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','4')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_4` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
//Insert 5th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number5'");
$now5 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now5' AND id= '$number5'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number5','$course','$now5','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','5')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_5` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 6th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number6'");
$now6 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now6' AND id= '$number6'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number6','$course','$now6','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','6')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_6` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course`= '$course'");

//Insert 7th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number7'");
$now7 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now7' AND id= '$number7'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number7','$course','$now7','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','7')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_7` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 8th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number8'");
$now8 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now8' AND id= '$number8'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number8','$course','$now8','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','8')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_8` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 9th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number9'");
$now9 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now9' AND id= '$number9'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number9','$course','$now9','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','9')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_9` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 10th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number10'");
$now10 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now10' AND id= '$number10'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number10','$course','$now10','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','10')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_10` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include('dbconnect.php');
$query =mysql_query("select count(id) from `user_question` where `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
$question_query = @mysql_result($query, 0, "count(id)");
//echo $question_query;

// INSERT FROM QUESTION 11- 20

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number11'");
$now = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now' AND id= '$number11'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number11','$course','$now','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','11')");
include('dbconnect.php');
mysql_query("INSERT INTO offline(username,course,correct_11)VALUES('$_SESSION[reg_no]','$course','$correct')");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number12'");
$now12 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now12' AND id= '$number12'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number12','$course','$now12','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','12')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_12` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number13'");
$now13 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now13' AND id= '$number13'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number13','$course','$now13','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','13')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_13` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number14'");
$now14 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now14' AND id= '$number14'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number14','$course','$now14','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','14')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_14` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number15'");
$now15 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now15' AND id= '$number15'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number15','$course','$now15','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','15')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_15` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number16'");
$now16 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now16' AND id= '$number16'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number16','$course','$now6','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','16')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_16` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course`= '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number17'");
$now17 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now17' AND id= '$number17'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number17','$course','$now7','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','17')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_17` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number18'");
$now18 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now18' AND id= '$number18'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number8','$course','$now18','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','18')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_18` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number19'");
$now19 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now19' AND id= '$number19'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number19','$course','$now9','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','19')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_19` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number20'");
$now20 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now20' AND id= '$number20'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number20','$course','$now10','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','20')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_20` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//INSERT QUESTION 21-30
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number21'");
$now = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now' AND id= '$number21'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number21','$course','$now','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','21')");
include('dbconnect.php');
mysql_query("INSERT INTO offline(username,course,correct_21)VALUES('$_SESSION[reg_no]','$course','$correct')");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number22'");
$now22 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now22' AND id= '$number22'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number22','$course','$now22','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','22')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_22` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number23'");
$now23 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now23' AND id= '$number23'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number23','$course','$now23','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','23')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_23` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number24'");
$now24 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now24' AND id= '$number24'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number24','$course','$now24','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','24')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_24` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number25'");
$now25 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now25' AND id= '$number25'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number25','$course','$now25','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','25')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_25` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number26'");
$now26 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now26' AND id= '$number26'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number26','$course','$now6','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','26')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_26` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course`= '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number27'");
$now27 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now27' AND id= '$number27'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number27','$course','$now7','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','27')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_27` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number28'");
$now28 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now28' AND id= '$number28'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number8','$course','$now28','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','28')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_28` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number29'");
$now29 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now29' AND id= '$number29'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number29','$course','$now9','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','29')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_29` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number30'");
$now30 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now30' AND id= '$number30'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number30','$course','$now20','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','30')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_30` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//INSERT QUESTION 31-40

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number31'");
$now = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now' AND id= '$number31'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number31','$course','$now','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','31')");
include('dbconnect.php');
mysql_query("INSERT INTO offline(username,course,correct_31)VALUES('$_SESSION[reg_no]','$course','$correct')");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number32'");
$now32 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now32' AND id= '$number32'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number32','$course','$now32','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','32')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_32` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number33'");
$now33 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now33' AND id= '$number33'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number33','$course','$now33','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','33')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_33` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number34'");
$now34 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now34' AND id= '$number34'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number34','$course','$now34','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','34')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_34` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number35'");
$now35 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now35' AND id= '$number35'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number35','$course','$now35','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','35')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_35` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number36'");
$now36 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now36' AND id= '$number36'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number36','$course','$now6','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','36')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_36` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course`= '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number37'");
$now37 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now37' AND id= '$number37'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number37','$course','$now7','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','37')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_37` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number38'");
$now38 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now38' AND id= '$number38'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number8','$course','$now38','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','38')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_38` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number39'");
$now39 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now39' AND id= '$number39'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number39','$course','$now9','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','39')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_39` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number40'");
$now40 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now40' AND id= '$number40'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number40','$course','$now30','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','40')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_40` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");


$ud = mysql_query("SELECT count(question) FROM user_question WHERE username = '$_SESSION[reg_no]' AND `course` = '$course'");
$question_query = @mysql_result($ud,0,"count(question)");

if($question_query<40)
{
  include('dbconnect.php');
  mysql_query("DELETE FROM `user_question` WHERE `username`='$_SESSION[reg_no]' AND `course` = '$course'");
  mysql_query("DELETE FROM `offline` WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
  header("location:insert_questions_office.php");
  exit();
}
else
{
  header("location:office.php");
} 
?>