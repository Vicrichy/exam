<?php
$number=$_POST['move_number'];

$choice_radio = $_POST['choice'];


if(($choice_radio)== "A")
{
include('answer_clicked_a.php');
}

elseif(($choice_radio)== "B")
{
include('answer_clicked_b.php');
}

elseif(($choice_radio)== "C")
{
include('answer_clicked_c.php');
}

elseif(($choice_radio)== "D")
{
include('answer_clicked_d.php');
}

else
{
echo "Pls select an option";
}

?>