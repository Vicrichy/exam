<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST ::: Control Panel Login</title>
<style type="text/css">
<!--
.style2 {
	font-family: System;
	font-weight: bold;
	color: #FFFFFF;
}
-->
</style>
</head>

<body bgcolor="#000000">
<?php

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

include('dbconnect.php');



// DISABLE PREVIOUS DAYS TEST SCHEDULE


// Disable Quiz, Exam or Exam Re-sit.

$delete1 = "DELETE FROM candidate_login_table WHERE test_date != '$system_date'";
$result = mysql_query($delete1);


$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "/";

$ans_date = $computer_date_day.$dash.$computer_date_month.$dash.$computer_date_year ;

$delete2 = "DELETE FROM answered_questions WHERE exam_date != '$ans_date'";
$result2 = mysql_query($delete2);

?>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
	<tr>
		<td bgcolor="#808080" colspan="5">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="5" bgcolor="#C0C0C0" height="22">&nbsp;</td>
	</tr>
	<tr>
		<td width="1%" bgcolor="#FFFFFF" rowspan="5">&nbsp;<p>&nbsp;</p>
    <td colspan="3" bgcolor="#9966CC">&nbsp; 
      <p align="center"> <font size="7">&nbsp;</font><font face="Rockwell Extra Bold" color="#00FF00" size="6"><span style="background-color: #000000">CONTROL 
        PANEL</span></font></p>
				<p><br>
		<br>
&nbsp;</td>
		<td bgcolor="#FFFFFF" width="1%" rowspan="5">&nbsp;</td>
	</tr>
	<tr>
		
    <td height="25" colspan="3"><font color="#CC99FF">This is the 
      back-end administrative console/control panel of the Testing Engine. Please 
      login.</font> 
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>	  </td>
	</tr>
	<tr>
	  <td height="23" align="center" bgcolor="#008000"> <font color="#FFFFFF" face="System"><b>TEST 
      MANAGER LOGIN </b></font></td>
	  <td height="23" align="center" bgcolor="#000000">&nbsp;</td>
	  <td height="23" align="center" bgcolor="#008000"><span class="style2">AUTHORIZED VIEWER LOGIN</span></td>
	</tr>
	<tr>
		<td width="51%" height="26" align="center" background="images/graph.jpg"><b>
		<span style="background-color: #CC99FF">Enter Password</span></b>
          <form method="POST" action="scheduler_login.php">
        <!--webbot bot="SaveResults" U-File="C:\Program Files\EasyPHP1-7\www\datamix\_private\form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
        <p>
          <input name="password" type="password" id="password" size="20">
          <br>
			<input type="submit" value="Login" name="B1"></p>
		</form></td>
	    <td width="4%" align="center" valign="top" bgcolor="#000000"><br></td>
	    <td width="43%" align="center" valign="top" background="images/graph.jpg"><b><span style="background-color: #CC99FF">Enter Password</span></b>
	      <form method="POST" action="aviewer_login.php">
            <!--webbot bot="SaveResults" U-File="C:\Program Files\EasyPHP1-7\www\datamix\_private\form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
            <p>
              <input name="password" type="password" id="password" size="20">
              <br>
              <input type="submit" value="Login" name="B12">
            </p>
        </form></td>
	</tr>
	<tr>
		<td height="26" colspan="3">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="5" bgcolor="#C0C0C0">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="5" bgcolor="#808080">
		  <p align="center"></td>
	</tr>
</table>

</body>

</html>