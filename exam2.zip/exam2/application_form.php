<?php
$code = rand();

/*include('dbconnect.php');

$sql =mysql_query("SELECT `form_code` FROM `receipt` WHERE `form_code`='$code'");
$num_rows = mysql_num_rows($sql);
if($num_rows>1)
{
 $code = $code+1;

mysql_query("INSERT INTO receipt SET `form_code`= '$code'");
}*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Pacific Computer::Application Form</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.style1 {
	font-size: 18px;
	font-weight: bold;
}
.style4 {font-size: 14px; font-weight: bold; }
.style5 {
	font-size: 12px;
	font-weight: bold;
}
.style8 {font-size: 16px; font-weight: bold; }
.style9 {font-size: 14px}
.style10 {font-size: 18px}
.style11 {font-size: 12px}
#Layer1 {
	position:absolute;
	width:41px;
	height:27px;
	z-index:1;
	left: 596px;
	top: 966px;
}
#Layer2 {
	position:absolute;
	width:47px;
	height:26px;
	z-index:2;
	left: 524px;
	top: 966px;
}
.style12 {font-size: 10px}
-->
</style></head>

<body onload="window.print();">
<table width="767" border="0" align="center" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td colspan="2" rowspan="3" valign="top"><img src="logos.JPG" alt="logo" width="121" height="128" /></td>
    <td height="75" colspan="11" align="center" valign="top"><p class="style1">PACIFIC COMPUTER AND MANAGEMENT COLLEGE NIGERIA LIMITED </p>
    <p>&nbsp; </p></td>
  </tr>
  <tr>
    <td width="12" height="13"></td>
    <td width="12"></td>
    <td width="13"></td>
    <td width="146"></td>
    <td width="26"></td>
    <td width="46"></td>
    <td width="33"></td>
    <td width="49"></td>
    <td width="29"></td>
    <td colspan="2" rowspan="3" valign="top"><p><strong>119 Ndidem Usang Iso Road,</strong></p>
    <p><strong>Calabar,</strong><strong>Cross River State</strong></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td height="46"></td>
    <td colspan="7" align="center" valign="top" bordercolor="#000000" class="style1" border=4><table width="260" border="2">
      <tr>
        <td class="style10">APPLICATION FORM </td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" rowspan="2" valign="top"><strong>RC. 355641 </strong></td>
    <td colspan="4" rowspan="2" valign="top"><span class="style4">FORM FEE: N 700.00 </span></td>
  <td height="15"></td>
    <td colspan="4" rowspan="2" valign="top" class="style4">FORM No: <?php echo $code;?> </td>
  </tr>
  <tr>
    <td height="15"></td>
    <td width="235"></td>
    <td width="46"></td>
  </tr>
  
  <tr>
    <td height="137" colspan="4" valign="top"><table width="126" height="128" border="3" align="center">
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
    <td colspan="8" valign="top"><p><strong>NAME</strong>:............................................................................................................................................</p>
      <p><strong>ADDRESS</strong>:.......................................................................................................................................</p>
      <p><strong>NEXT OF KIN</strong>:................................................<strong>STATE OF ORIGIN</strong>:........................................................</p>
    <p><strong>LGA:</strong>....................................<strong>SEX:</strong>.............................<strong>MARITAL STATUS</strong>................................................</p>      <p><strong>EMAIL</strong>:....................................................<strong>PHONE</strong>...............................................................................   </p></td>
  </tr>
  <tr>
    <td height="151" colspan="13" valign="top"><p class="style9"><strong>ACADEMIC QUALIFICATION:</strong> </p>
      <table width="769" height="84" border="3">
        <!--DWLayoutTable-->
        <tr>
          <td width="167" height="22"><strong>INSTITUTIONS</strong></td>
          <td width="104"><strong>FROM</strong></td>
          <td width="98"><strong>TO</strong></td>
          <td width="379"><strong>QUALIFICATION OBTAINED</strong> </td>
        </tr>
        <tr>
          <td height="27">&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>      <p>(Attach photocopies of credentials)</p></td>
  </tr>
  <tr>
    <td height="16" colspan="8" valign="top"><span class="style5">PREVIOUS KNOWLEDGE OF COMPUTER STUDIES: </span></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="435" colspan="13" valign="top"><table width="765">
      <tr>
        <td width="86"><strong>BEGINNER </strong></td>
        <td width="32"><table width="32" border="3">
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></td>
        <td width="182"><strong>INTERMEDIATE KNOWLEDGE</strong></td>
        <td width="32"><table width="32" border="3">
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></td>
        <td width="409">EXPERT IN:.............................................................................</td>
      </tr>
    </table>
      
      <label><span class="style5">      </span></label>
      <p class="style8">CHOICE OF COURSE </p>
      <table width="765">
        <tr>
          <td width="329"><span class="style5">* <span class="style9">INFORMATION TECHNOLOGY</span></span></td>
          <td width="32"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
          <td width="55"><span class="style5">Diploma</span></td>
          <td width="32"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
          <td width="69"><span class="style5">Certificate</span></td>
          <td width="32"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
          <td width="148"><span class="style5">Proficiency Certificate</span></td>
          <td width="32"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
      </table>
      <table width="765">
        <tr>
          <td width="329"><span class="style5">* <span class="style9">COMPUTER REPAIRS&amp; MAINTENANCE</span></span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="55"><span class="style5">Diploma</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="70"><span class="style5">Certificate</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="147"><span class="style5">Proficiency Certificate</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <table width="765">
        <tr>
          <td width="329"><span class="style5">* <span class="style9">COMPUTER STUDIES/SECT ADMIN</span></span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="55"><span class="style5">Diploma</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="70"><span class="style5">Certificate</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="147"><span class="style5">Proficiency Certificate</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <table width="765">
        <tr>
          <td width="329"><span class="style5">* <span class="style9">HARDWARE AND SOLAR ENERGY TECH</span></span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="55"><span class="style5">Diploma</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="70"><span class="style5">Certificate</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="147"><span class="style5">Proficiency Certificate</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <p class="style5">&nbsp;</p>
      <hr />
      <table width="479">
        <tr>
          <td width="154"><span class="style5"><span class="style9">MODE OF STUDY: </span></span></td>
          <td width="57"><span class="style5">Morning</span></td>
          <td width="32"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
          <td width="69"><span class="style5">Afternoon</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="55"><span class="style5">Evening</span></td>
          <td width="34"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <p class="style5">HOW DID YOU GET TO HEAR ABOUT PACIFIC COMPUTER AND MANAGEMENT COLLEGE?</p>
      <table width="454">
        <tr>
          <td width="94"><span class="style5">Radio Advert </span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="186"><span class="style5">Introduction by our Student </span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="48"><span class="style5">Others</span></td>
          <td width="34"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <p class="style5">CERTIFICATION</p>
      <p class="style5">I..........................................................................hereby certify that the information given by me above is true to the best of my knowledge. </p></td>
  </tr>
  <tr>
    <td width="46" height="12"></td>
    <td width="75"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="4" valign="top"><strong>Signature/Date:</strong>.............................................................</td>
  </tr>
  <tr>
    <td height="33" colspan="13" align="center" valign="top"><hr />
      <p><strong>OFFICIAL USE ONLY</strong></p></td>
  </tr>
  <tr>
    <td height="53">&nbsp;</td>
    <td colspan="11" align="center" valign="top"><table width="330">
      <tr>
        <td width="133"><strong>Applicant Qualified:</strong></td>
        <td width="36"><span class="style5">Yes</span></td>
        <td width="33"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        <td width="24"><span class="style5">No</span></td>
        <td width="80"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
        </table></td>
      </tr>
    </table>
    <p>&nbsp;</p>
      <p><strong>Authorized Signature/Date</strong>:.................................................................... </p></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="849"></td>
    <td colspan="11" valign="top" class="style8"><p>PROGRAMMES</p>
      <table width="712" border="1">
        <tr>
          <td width="429"><span class="style9">Programmes Available </span></td>
          <td width="68"><span class="style9">Duration</span></td>
          <td width="157"><span class="style9">Entry Qualification </span></td>
        </tr>
        <tr>
          <td height="50" valign="top"><p class="style11">Diploma in Information Technology </p>
          <p class="style11">Certificate in Information Technology </p>
          <p class="style11">Certificate in Proficiency in Info. Tech </p>          </td>
          <td valign="top"><p class="style11">6 Months </p>
          <p class="style11">6 Months </p>
          <p class="style11">6 Months </p>          </td>
          <td valign="top"><p class="style11">Minimum of 4 Credits </p>
          <p class="style11">Minimum of 2 Credits </p>
          <p class="style11">Sch. Cert. Attempted </p></td>
        </tr>
        <tr>
          <td height="61" valign="top"><p class="style11">Diploma in Comp.Studies with Sec. Admin </p>
          <p class="style11">Certificate in Comp.Studies with Sec. Admin </p>
          <p class="style11">Certificate of Proficiency in Comp.Studies with Sec. Admin </p></td>
          <td valign="top"><p class="style11">6 Months </p>
          <p class="style11">6 Months </p>
          <p class="style11">6 Months </p></td>
          <td valign="top"><p class="style11">Minimum of 6 Credits </p>
          <p class="style11">Minimum of 2 Credits </p>
          <p class="style11">Sch. Cert Attempted </p></td>
        </tr>
        <tr>
          <td height="72" valign="top"><p class="style11">Diploma in Repairs &amp; Maintenance </p>
          <p class="style11">Certificate in repairs and Maintenance </p>
          <p class="style11">Certificate of Proficiency in repairs &amp; Maintenance </p></td>
          <td valign="top"><p class="style11">6 Months </p>
          <p class="style11">6 Months </p>
          <p class="style11">6 Months </p></td>
          <td valign="top"><p class="style11">Minimum of 4 Credits </p>
          <p class="style11">Minimum of 2 Credits </p>
          <p class="style11">Sch. Cert. Attempted </p></td>
        </tr>
        <tr>
          <td height="72" valign="top"><p class="style11">Diploma in Hardware &amp; Solar Energy Technology </p>
              <p class="style11">Certificate in Hardware &amp; Solar Energy Technology </p>
              <p class="style11">Certificate of Proficiency inHardware &amp; Solar Energy Technology </p></td>
          <td valign="top"><p class="style11">6 Months </p>
              <p class="style11">6 Months </p>
            <p class="style11">6 Months </p></td>
          <td valign="top"><p class="style11">Minimum of 4 Credits </p>
              <p class="style11">Minimum of 2 Credits </p>
            <p class="style11">Sch. Cert. Attempted </p></td>
        </tr>
      </table>      
    <p>&nbsp;</p>
    <table width="658" height="57" border="1">
      <tr>
        <td valign="top"><p class="style9">Note:</p>
          <p class="style11">Completed Forms should be returned with the following:</p>
          <p class="style11">1. Photocopies of receipt for purchase of form</p>
          <p class="style11">2. Photocopies of credentials</p>
          <p class="style11">3. 2 Color passports </p></td>
      </tr>
    </table>    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p align="center" class="style12">Powered by B-Low Solutions, inc </p></td>
    <td></td>
  </tr>
</table>
</body>
</html>
