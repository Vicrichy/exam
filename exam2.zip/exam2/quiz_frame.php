<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>E-TEST :: TESTING ROOM</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=2.0,Transition=21)">
<meta name="Microsoft Theme" content="water 1011, default">
</head>

<frameset rows="*" cols="297,*">
	<frame name="left" scrolling="no" noresize target="rtop" src="new_page_4.php">
		<frame name="rtop" target="rbottom" src="question.php" scrolling="auto">
	<noframes>
	<body>

	<p>This page uses frames, but your browser doesn't support them.</p>
	</body>
	</noframes>
</frameset>

</html>