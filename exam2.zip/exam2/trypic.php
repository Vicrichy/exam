<?php

// getdata.php3 - by Florian Dittmer <dittmer@gmx.net>
// Example php script to demonstrate the direct passing of binary data
// to the user. More infos at http://www.phpbuilder.com
// Syntax: getdata.php3?id=<id>



    // you may have to modify login information for your database server:
    mysql_connect("localhost","root","");

    mysql_select_db("datamix");

    $query = mysql_query("select picture from registration_table where id= 3");
    $result = @mysql_result($query, 0, "picture");

    //$data = @mysql_query($result,0,"first_name");
   
    
    echo $result;
	


?>

