<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 2</title>
</head>

<body bgcolor="#CC99FF">

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
	<tr>
		<td bgcolor="#000000" colspan="4">&nbsp;</td>
	</tr>
	<tr>
		<td width="1%" bgcolor="#000000" rowspan="4">&nbsp;<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p></td>
		<td bgcolor="#000080" colspan="2">
		<p align="center"><b><font size="5" color="#00FF00">MANAGE COURSES</font><font size="5" color="#FFFFFF">
		</font></b></td>
		<td width="3%" bgcolor="#000000" rowspan="4">&nbsp;</td>
	</tr>
	<tr>
		<td height="19" colspan="2"><form name="form2" method="post" action="student_file.php">
  <div align="right"> Specify reg.no 
    <input name="reg_no" type="text" id="reg_no">
    <input type="submit" name="Submit2" value="OPEN STUDENT'S FILE">
  </div>
</form>
      &nbsp;</td>
	</tr>
	<tr>
		
    <td width="21%" height="160" bgcolor="#000080" valign="top"><u><b><a href="create_courses.php"> 
      <font color="#00FF00" size="2">CREATE COURSES &gt;&gt;</font></a></b></u> 
      <p><u><b> <a href="manage_questions.php"><font color="#00FF00" size="2">MANAGE 
        QUESTIONS &gt;&gt;</font></a></b></u><u> </u></p>
		<p></td>
		<td width="75%" height="160">&nbsp;Here, you can effectively create new 
		courses in your institution, upload questions and manage the test 
		questions in the database.<p>&nbsp;These tasks can be performed by 
		clicking any of the links displayed at the left of this screen.</td>
	</tr>
	<tr>
		<td height="237" colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#000000" colspan="4">&nbsp;</td>
	</tr>
</table>

</body>

</html>

<?php
}
?>