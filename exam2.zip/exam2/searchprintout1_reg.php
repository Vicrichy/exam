<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title></title>
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

.style1 {color: #000000}
.style3 {font-size: 24px}
</style>
<bgsound src="file:///C|/Documents%20and%20Settings/MY%20OFFICE/Desktop/scrap/Installing%20E-desk/e-desk1.1/swordraw.wav" loop="1">

</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="101%" height="100%">
	<tr>
		
    <td height="41" colspan="5" bgcolor="#000000"> <div align="right"><font face="Bodoni MT Black" color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </font> <font face="Arial Narrow" color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <b><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;        </font></b></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"> 
      <font color="#FF0000">&lt;&nbsp;GO BACK</font></a></font></div></td>
	</tr>
	<tr>
		
    <td height="45" colspan="2" bgcolor="#FFFFFF"><div align="left"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style1"><span class="style3">Database Report.  </span><font size="4">&nbsp; 
      &nbsp;&nbsp; </font></span></b></div></td>
	<td height="45" bgcolor="#CCCCCC">&nbsp;</td>
	<td height="45" bgcolor="#CCCCCC">&nbsp;</td>
	<td height="45" bgcolor="#CCCCCC">&nbsp;</td>
	</tr>
	<tr>
	  <td width="4%" bgcolor="#000000" valign="top" rowspan="5">&nbsp;	    </td>
	  <td bgcolor="#CCCCCC" valign="top" height="19">&nbsp;</td>
	  <td width="2%" bgcolor="#000000" valign="top" rowspan="5">&nbsp;	    </td>
	  <td width="2%" bgcolor="#808080" valign="top" rowspan="5">&nbsp;	    </td>
  </tr>
	<tr>
	<?php
	// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_day.$dash.$computer_date_month.$dash.$computer_date_year ;
	?>
	  <td bgcolor="#CCCCCC" valign="top" height="19"><strong>REGISTRATION DATA. </strong></td>
  </tr>
	<tr>
		<td width="91%" bgcolor="#CCCCCC" valign="top" height="19">
		<p>Date: <?php echo "$system_date"; ?></p>		</td>
	</tr>
	<tr>
		
    <td width="91%" bgcolor="#FFFFFF" valign="top" height="280"> 
      <?php
	

 $batch_no=$_POST['batch_no'];
 $course=$_POST['course'];

	
include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{

$query =("SELECT UPPER(reg_no)'REG.NO', UPPER(surname)'SURNAME', UPPER(first_name)'FIRST NAME', UPPER(othernames)'OTHERNAMES', UPPER(department)'DEPARTMENT', gender'GENDER', course'COURSE', batch'BATCH' FROM registration_table WHERE course = '$course' and batch = '$batch_no' ORDER BY department, surname ");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($result, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

}
?>    </td>
	</tr>
	<tr>
		<td width="91%" bgcolor="#CCCCCC" valign="top">&nbsp;		</td>
	</tr>
	<tr>
		<td height="26" width="100%" bgcolor="#808080" colspan="5"><FORM>
        <p align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="button" type="button" onClick="window.print()" value="PRINT OUT">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;        </p>
      </FORM>    </td>
	</tr>
	<tr>
		<td height="26" width="4%" bgcolor="#000000">&nbsp;</td>
		<td height="22" width="95%" bgcolor="#000000" colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<font color="#FFFFFF">&nbsp;&nbsp;&nbsp;</font></td>
		<td height="26" width="1%" bgcolor="#000000">&nbsp;</td>
	</tr>
</table>

</body>

</html>