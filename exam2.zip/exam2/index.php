<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>LAUNCH TEST</title>

<script LANGUAGE="JavaScript">
<!--

// JavaScript centering adapted by telophase: telophase@telophase.net
// from code by Kate Ward: http//www.kateandmouse.com
// Full permission is granted for use.

function popUp(URL,popW,popH) {

var w = 480, h = 340;

if (document.all || document.layers) {
   w = screen.availWidth;
   h = screen.availHeight;
}

var topPos = 0, leftPos = (w-popW)/2;


   window.open(URL,'popup','resizable, toolbar=no, location=no, status=no, scrollbars=yes, horizontal scrollbars=yes, scroll=yes, menubar=no, titlebar=no, width=' + popW + ',height=' + popH + ',left=' + leftPos + ',top=' + topPos + ',screenX=' + leftPos + ',screenY=' + topPos);
}
// -->
</script>


<style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
-->
</style></head>

<body>
<?php

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;



include('dbconnect.php');



// DISABLE PREVIOUS DAYS TEST SCHEDULE


// Disable Quiz, Exam or Exam Re-sit.

$delete1 = "DELETE FROM candidate_login_table WHERE test_date != '$system_date'";
$result = mysql_query($delete1);


$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "/";

$ans_date = $computer_date_day.$dash.$computer_date_month.$dash.$computer_date_year ;

$delete2 = "DELETE FROM answered_questions WHERE exam_date != '$ans_date'";
$result2 = mysql_query($delete2);




?>



<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</p>
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
	<tr>
		<td colspan="3">&nbsp;<p align="center">
		<font size="6">PACIFIC E-  TESTER ENGINE </font></p>
		  <p></td>
	</tr>
	<tr>
		<td width="47%" bgcolor="#CC9900">&nbsp;
		  <p align="center">
		<span style="background-color: #FFFFFF"><b><font size="4">&nbsp;&nbsp;&nbsp;&nbsp;
		</font>
		<a href="JavaScript:popUp('registration.php',1015,680)"><font color="#000000" size="4">REGISTRATION</font></a><font size="4">&nbsp;&nbsp;&nbsp;
		</font></b></span><b>&nbsp;</b></p>
		  <p align="center"> <span style="background-color: #FFFFFF"><b><font size="4">&nbsp;&nbsp;&nbsp;&nbsp; </font> <a href="JavaScript:popUp('candidate_login.php',1015,680)"> <font color="#000000" size="4">CANDIDATE LOGIN </font></a><font size="4">&nbsp;&nbsp;&nbsp; </font></b></span><b>&nbsp;</b></p>
		  <p></td>
		<td width="3%">&nbsp;</td>
		<td width="50%" bgcolor="#CC9900">
		<p align="center">&nbsp;<b><span style="background-color: #FFFFFF"><font size="4">&nbsp;
		</font>
		<a href="JavaScript:popUp('controlpanel_login_page.php',1015,680)">
		<font size="4" color="#000000">CONTROL PANEL</font></a><font size="4">&nbsp;
	  </font></span><font size="4">&nbsp;</font></b></td>
	</tr>
	<tr>
		<td colspan="3">&nbsp;</td>
	</tr>
</table>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>

<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<br>
<font color="#000000"><span style="text-decoration: none">
<a href="http://www.weboptionsict.com"></a></span></font></p>

</body>

</html>