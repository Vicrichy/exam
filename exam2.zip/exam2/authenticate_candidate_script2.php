<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
?>
<?php

include('dbconnect.php');
// RETRIEVE CANDIDATE'S FIRST NAME
$query2 =mysql_query("select `fname` from `user` where `fname` = '$_SESSION[fname]'");
$firstname = @mysql_result($query2, 0, "fname");

// EXTRACT SYSTEM DATE
$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";
$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
// SELECT MAX QUESTION SET FOR THE CANDIDATE
$query_max_questions = 5;

//include ('dbconnect.php');
//$check_query = ("select count(question) from `user_question` WHERE `username` = '$_SESSION[username]' //AND `answered` = 'YES'");
//$display = mysql_result($check_query, 0, "count(question)");
//if($display > 0)
//{
// $_SESSION['display_no'] = $display +1;
// header("location:quiz_frame.php");
// exit();
//} 

//else
//{
//$_SESSION['display_no'] = 1;
$vik_query = mysql_query("SELECT count(username) FROM `result` WHERE `username`='$_SESSION[username]'");
$num_rows = @mysql_result($vik_query, 0, "count(username)");
if($num_rows>=1)
{
 ?>
<script type="text/javascript">
alert("Sorry! you have either played or downloaded your game before");
window.location = "user_page.php";
</script> 
 <?php
 }
 else
{ 
$numbers = range(1,7);

shuffle($numbers);
for($i=0;$i<5;$i++)
{
$numberz .= $numbers[$i];
}
$number1 = $numberz{0};
$number2 = $numberz{1};
$number3 = $numberz{2};
$number4 = $numberz{3};
$number5 = $numberz{4};

//Insert 1st question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `question` where `id` = '$number1'");
$now = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM question WHERE question = '$now' AND id= '$number1'");
while($row = mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,question,A,B,C,D,correct,username,page_no)VALUES('$number1','$now','$A','$B','$C','$D','$correct','$_SESSION[username]','1')");

include('dbconnect.php');
mysql_query("INSERT INTO offline(username,correct_1)VALUES('$_SESSION[username]','$correct')");
//Insert 2nd question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `question` where `id` = '$number2'");
$now2 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM question WHERE question = '$now2' AND id= '$number2'");
while($row = mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,question,A,B,C,D,correct,username,page_no)VALUES('$number2','$now2','$A','$B','$C','$D','$correct','$_SESSION[username]','2')");

include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_2` = '$correct' WHERE `username` = '$_SESSION[username]'");
//Insert 3rd question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `question` where `id` = '$number3'");
$now3 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM question WHERE question = '$now3' AND id= '$number3'");
while($row = mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,question,A,B,C,D,correct,username,page_no)VALUES('$number3','$now3','$A','$B','$C','$D','$correct','$_SESSION[username]','3')");

include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_3` = '$correct' WHERE `username` = '$_SESSION[username]'");

//Insert 4th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `question` where `id` = '$number4'");
$now4 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM question WHERE question = '$now4' AND id= '$number4'");
while($row = mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,question,A,B,C,D,correct,username,page_no)VALUES('$number4','$now4','$A','$B','$C','$D','$correct','$_SESSION[username]','4')");

include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_4` = '$correct' WHERE `username` = '$_SESSION[username]'");
//Insert 5th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `question` where `id` = '$number5'");
$now5 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM question WHERE question = '$now5' AND id= '$number5'");
while($row = mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,question,A,B,C,D,correct,username,page_no)VALUES('$number5','$now5','$A','$B','$C','$D','$correct','$_SESSION[username]','5')");

include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_5` = '$correct' WHERE `username` = '$_SESSION[username]'");

include('dbconnect.php');
$query =mysql_query("select count(id) from `user_question` where `username` = '$_SESSION[username]'");
$question_query = @mysql_result($query, 0, "count(id)");
echo $question_query;

if($question_query<5)
{
  include('dbconnect.php');
  mysql_query("DELETE FROM `user_question` WHERE `username`='$_SESSION[username]'");
  header("location:process_game2.php");
  exit();
}
else
{
  header("location:offline_game.php");
}

}
header("location:offline_game.php");
}
?>