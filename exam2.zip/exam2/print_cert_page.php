<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 



<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>DataMix TEST ENGINE</title>
<meta http-equiv="Page-Enter" content="blendTrans(Duration=5.0)">
</head>

<body background="images/bg9.jpg">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
	
  <tr bgcolor="#330000"> 
    <td height="94" colspan="4"> 
      <p align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<form action="logout.php" method="post" name="form1" target="_parent">
  <div align="right">
          <input type="submit" name="Submit" value="Logout">
        </div>
      </form>
      <div align="center"><b><font size="5"><font color="#FF9900" face="Copperplate Gothic Bold"><u>ACCOUNTS 
        UNIT</u></font></font></b></div></td>
	</tr>
	<tr>
		
    <td width="24%" height="760" valign="top" bgcolor="#000000">
<p>&nbsp;</p>
		
      <p>&nbsp;<a href="accounts_expenditure.php"><img border="0" src="images/rec_exp.jpg" width="171" height="31"></a></p>
		
      <p> &nbsp;<a href="sales_report.php"><img border="0" src="images/income_report.jpg" width="171" height="31"></a></p>
		
      <p><a href="retrieve_data_scheduler.php"><img src="images/retrievedata_bt.jpg" width="178" height="31" border="0"></a> 
      </p>
		
      <p><a href="print_cert_page.php"><img src="images/print_cert_butt.jpg" width="178" height="31" border="0"></a> 
      </p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p><br>
&nbsp;</td>
		
    <td width="2%" valign="top" bgcolor="#330000"> 
      <p align="center"></td>
		
    <td width="73%" valign="top"> <table width="100%" border="1">
        <tr>
          <td bgcolor="#660066"><strong><font color="#FFFFFF">PRINT CERTIFICATES</font></strong></td>
        </tr>
      </table>
      <p align="center">&nbsp;</p>
		
      <p align="left"> This section gives you the ability to print a student's 
        certificate. The certificate shows a detailed statement of the student's 
        scores and courses, as well as displays the student's full name and registration 
        number.</p>
      <p align="left">&nbsp;</p>
      <p align="left">This software automatically generates the certificate after 
        you must have specified the student's registration number.</p>
      <form name="form2" method="post" action="generate_cert.php">
        <p> <strong><font size="2">STUDENT'S REG.NUMBER</font></strong> 
          <input name="reg_no" type="text" id="reg_no" size="30">
          <input type="submit" name="Submit2" value="GENERATE CERTIFICATE">
        </p>
        </form>
      <p align="left">&nbsp;</p>
      <p align="left">&nbsp;</p>
      <p align="center">&nbsp;</p>
      <p align="center">&nbsp;</p>
		
      <p>&nbsp;</p>
		<p><p><p><p><p>
      <p>
      <p>
      <p>
      <p>
      <p>
<p><p><p><p></td>
		
    <td width="1%" valign="top" bgcolor="#330000">&nbsp; </td>
	</tr>
	
  <tr bgcolor="#330000"> 
    <td colspan="4"> 
      <p align="center"><b><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></b></td>
	</tr>
</table>

</body>

</html>
<?php
}
?>