-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 03, 2011 at 04:48 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pacific`
--

-- --------------------------------------------------------

--
-- Table structure for table `offline`
--

CREATE TABLE IF NOT EXISTS `offline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `course` varchar(100) NOT NULL,
  `correct_1` varchar(10) NOT NULL,
  `correct_2` varchar(10) NOT NULL,
  `correct_3` varchar(10) NOT NULL,
  `correct_4` varchar(10) NOT NULL,
  `correct_5` varchar(10) NOT NULL,
  `correct_6` varchar(10) NOT NULL,
  `correct_7` varchar(10) NOT NULL,
  `correct_8` varchar(10) NOT NULL,
  `correct_9` varchar(10) NOT NULL,
  `correct_10` varchar(10) NOT NULL,
  `correct_11` varchar(10) NOT NULL,
  `correct_12` varchar(10) NOT NULL,
  `correct_13` varchar(10) NOT NULL,
  `correct_14` varchar(10) NOT NULL,
  `correct_15` varchar(10) NOT NULL,
  `correct_16` varchar(10) NOT NULL,
  `correct_17` varchar(10) NOT NULL,
  `correct_18` varchar(10) NOT NULL,
  `correct_19` varchar(10) NOT NULL,
  `correct_20` varchar(10) NOT NULL,
  `correct_21` varchar(10) NOT NULL,
  `correct_22` varchar(10) NOT NULL,
  `correct_23` varchar(10) NOT NULL,
  `correct_24` varchar(10) NOT NULL,
  `correct_25` varchar(10) NOT NULL,
  `correct_26` varchar(10) NOT NULL,
  `correct_27` varchar(10) NOT NULL,
  `correct_28` varchar(10) NOT NULL,
  `correct_29` varchar(10) NOT NULL,
  `correct_30` varchar(10) NOT NULL,
  `correct_31` varchar(10) NOT NULL,
  `correct_32` varchar(10) NOT NULL,
  `correct_33` varchar(10) NOT NULL,
  `correct_34` varchar(10) NOT NULL,
  `correct_35` varchar(10) NOT NULL,
  `correct_36` varchar(10) NOT NULL,
  `correct_37` varchar(10) NOT NULL,
  `correct_38` varchar(10) NOT NULL,
  `correct_39` varchar(10) NOT NULL,
  `correct_40` varchar(10) NOT NULL,
  `correct_41` varchar(10) NOT NULL,
  `correct_42` varchar(10) NOT NULL,
  `correct_43` varchar(10) NOT NULL,
  `correct_44` varchar(10) NOT NULL,
  `correct_45` varchar(10) NOT NULL,
  `correct_46` varchar(10) NOT NULL,
  `correct_47` varchar(10) NOT NULL,
  `correct_48` varchar(10) NOT NULL,
  `correct_49` varchar(10) NOT NULL,
  `correct_50` varchar(10) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `offline`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
