<?php

$test_type = addslashes($_POST['test_type']);
$code = addslashes($_POST['code']);
$month = addslashes($_POST['month']);
$year = addslashes($_POST['year']);
$no = addslashes($_POST['no']);
$reg_no = $code.'/'.$month.'/'.$year.'/'.$no;
$name = addslashes($_POST['name']);
$dept = addslashes($_POST['department']);
$years = addslashes($_POST['years']);
$batch = addslashes($_POST['batch']);
$day = date("d");
$month = date("m");
$year = date("Y");

$date = "$day-$month-$year";

include('dbconnect.php');


$check = mysql_query("SELECT `reg_no` FROM `registration_table` WHERE `reg_no` = '$reg_no' AND `dept` = '$dept'")or die("THERE WAS AN ERROR1".mysql_error());
$num_rows = @mysql_num_rows($check);

if($num_rows >0)
{
?>
<script type="text/javascript">
alert("Sorry! This Reg No already exists");
window.location = "registration.php";
</script>
<?php
exit();
}
switch($dept)
{
case($dept == 'Comp. Repairs and Maintenance - 1st Semester'):
mysql_query("INSERT INTO broadsheet_repairs(reg_no,name,year,batch)VALUES('$reg_no','$name','$years','$batch')")or die("There was an error2".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm211')")or die("There was an error3".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm212')")or die("There was an error4".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit211')")or die("There was an error5".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit213')")or die("There was an error6".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm214')")or die("There was an error7".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit215')")or die("There was an error8".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm216')")or die("There was an error9".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit218')")or die("There was an error10".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit219')")or die("There was an error11".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit220')")or die("There was an error12".mysql_error());
break;

case($dept == 'Comp. Repairs and Maintenance - 2nd Semester'):
mysql_query("INSERT INTO broadsheet_repairs2(reg_no,name,year,batch)VALUES('$reg_no','$name','$years','$batch')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm221')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm222')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm223')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm224')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm225')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm226')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','drm227')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit230')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit232')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit233')")or die("There was an error".mysql_error());

break;

case($dept == 'Sec.Administration - 1st Semester'):
mysql_query("INSERT INTO broadsheet_sec(reg_no,name,year,batch)VALUES('$reg_no','$name','$years','$batch')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit211')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs212')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit213')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs214')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit215')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit216')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit217')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit218')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs219')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit220')")or die("There was an error".mysql_error());
break;

case($dept == 'Sec.Administration - 2nd Semester'):
mysql_query("INSERT INTO secstudies_second(reg_no,name,year,batch)VALUES('$reg_no','$name','$years','$batch')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs221')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs222')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit223')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit224')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs225')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs226')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs228')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dcs229')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit230')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit231')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit232')")or die("There was an error".mysql_error());
break;

case($dept == 'Information Technology -1st Semester'):
mysql_query("INSERT INTO broadsheet(reg_no,name,year,batch)VALUES('$reg_no','$name','$years','$batch')")or die("There was an error31".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit211')")or die("There was an error32".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit212')")or die("There was an error33".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit213')")or die("There was an error34".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit214')")or die("There was an error35".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit215')")or die("There was an error36".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit216')")or die("There was an error37".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit217')")or die("There was an error38".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit218')")or die("There was an error39".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit219')")or die("There was an error40".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit220')")or die("There was an error41".mysql_error());
break;

case($dept == 'Information Technology -2nd Semester'):
mysql_query("INSERT INTO infotech_second(reg_no,name,year,batch)VALUES('$reg_no','$name','$years','$batch')")or die("There was an error21".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit221')")or die("There was an error22".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit222')")or die("There was an error23".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit223')")or die("There was an error24".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit224')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit225')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit226')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit227')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit230')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit231')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit232')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','dit233')")or die("There was an error".mysql_error());
break;

case($dept == 'GCTP MOCK EXAMS'):
mysql_query("INSERT INTO gctp_mock_exams(reg_no,name,year,batch)VALUES('$reg_no','$name','$years','$batch')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','mos221')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','cbg222')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','pap223')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','oracle224')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','ccna225')")or die("There was an error".mysql_error());
mysql_query("INSERT INTO mycourses(reg_no,course)VALUES('$reg_no','mcitp226')")or die("There was an error".mysql_error());
break;
}

mysql_query("INSERT INTO registration_table(name,reg_no,dept,test_type,year,batch,date)VALUES('$name','$reg_no','$dept','$test_type','$years','$batch','$date')")or die("There was an error".mysql_error());

?>
<script type="text/javascript">
alert("Congrats! You Have Successfully Registered. Now Login to write your exam");
window.location = "index.php";
</script>	