<?php

// DECLARE VARIABLES
$testmode =$_POST['testmode'];
$reg_no =$_POST['reg_no'];
$course =$_POST['course'];
$start_time =$_POST['start_time'];
$duration =$_POST['duration'];
$max_questions =$_POST['max_questions'];
$max_score =$_POST['max_score'];
$ip = getenv("REMOTE_ADDR");
$host = gethostbyaddr ("$ip");

$dash = "-";



// Extract system date

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$test_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// CHECK IF THE COURSE EXISTS
include('dbconnect.php');





// Retrieve candidate's surname

$query =mysql_query("select surname from registration_table where reg_no = '$_SESSION[reg_no]'");
$surname =mysql_result($query, 0, "surname");


// Retrieve candidate's first name

$query2 =mysql_query("select first_name from registration_table where reg_no = '$_SESSION[reg_no]'");
$firstname =mysql_result($query2, 0, "first_name");

$full_name = $surname."&nbsp;".$firstname ;




$query2="Select course from course_list where course = '$course'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) == 0) {
header('Location: course_does_not_exist.php');
mysql_close($link);
} 
else 
{



include('dbconnect.php');


// RETRIEVE THE CANDIDATE'S FORMER SCORE
$query_score = mysql_query("SELECT score FROM test_records WHERE course = '$course' AND reg_no = '$reg_no' AND test_type = '$testmode'");
$former_score = mysql_result($query_score, 0, "score");




// DELETE HIS FORMER RECORDS FROM 'TEST RECORDS TABLE'

$delete = mysql_query("DELETE FROM test_records WHERE course = '$course' AND reg_no = '$reg_no' AND test_type = '$testmode'");





//ACTIVATE A NEW TEST

//Insert to candidate login

$q_insert = "INSERT INTO candidate_login_table
             (test_date, test_set_time, test_type, course, max_time, max_questions, max_score,  test_duration)";

$q_insert .= "VALUES
              ('$test_date', '$start_time', '$testmode', '$course', '$duration', '$max_questions', '$max_score', '$duration')";
			  
			  $resultq = mysql_query($q_insert);
			  
			  
			  
			  
			  

// RECORD THE OPERATION IN THE reschedule_monitor

$r_insert = "INSERT INTO reschedule_monitor
             (action_date, reg_no, full_name, test_type, course, former_score, system_ip, system_name)";
			 
$r_insert .= "VALUES
              ('$test_date', '$reg_no', '$full_name', '$testmode', '$course', '$former_score', '$ip', '$host')";
			  
			  $resultr = mysql_query($r_insert);
			  
			  
			  

// DELETE HIS FORMER SCORE FROM compute_results TABLE
$delete2 = mysql_query("DELETE FROM compute_results WHERE course = '$course' AND reg_no = '$reg_no' AND test_type = '$testmode'");


			  
header('Location: test_activated.html');

			  
}
?>