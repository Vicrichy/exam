<?php

// THE BLOCK OF CODES BELOW, CHECKS FOR THE CORRECT ANSWER TO THE ANSWER CLICKED

//$submit=$_POST['submit'];
$number=$_POST['move_number'];




include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


session_start();

// EXAM DATE

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");

$exam_date = date("d/n/Y");


// DETERMINE THE COURSE CODE
// Determine the course code
if (($_SESSION['test_type']) == 'Exam Re-sit')
{
$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_course = mysql_result($query_cc, 0, "course_code");

$query_coursecode = $query_course."_"."exam";

}
else
{
$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_course = mysql_result($query_cc, 0, "course_code");

$query_coursecode = $query_course."_".$_SESSION['test_type'];
}


// RETRIEVE THE ANSWERED QUESTION
$queryp =mysql_query("select question from $query_coursecode where id = '$number'");
$question =mysql_result($queryp, 0, "question");



// CHECK IF RIGHT
$query3 =mysql_query("select alpha from $query_coursecode where id = '$number' and correct = 'right'");
$alpha_selected =mysql_result($query3, 0, "alpha"); 

if (($alpha_selected) == 'D') { 

// INSERT TO DATABASE
 $query  = "INSERT INTO answered_questions
              ( exam_date , id , reg_no , course , question , comment )";
			
   $query .= " VALUES
             ( '$exam_date' , '$number' , '$_SESSION[reg_no]' , '$_SESSION[course]' , '$question' , 'RIGHT' )";
			 
			 $result = mysql_query($query);

header('Location: question.php');
 mysql_close($link);
} 
else 
{ 

// INSERT INTO DATABASE TO INDICATE WRONG ANSWER
$query2  = "INSERT INTO answered_questions
              ( exam_date , id , reg_no , course , question , comment )";
			
$query2 .= " VALUES
             ( '$exam_date' , '$number' , '$_SESSION[reg_no]' , '$_SESSION[course]' , '$question' , 'WRONG' )";
			 
			 $result = mysql_query($query2);






include ('dbconnect.php');
header('Location: question.php');
}
}

?>
<?php
mysql_close($link);
?>
