<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>E-TEST ::: Registration</title>
<style type="text/css">
<!--
.style3 {
	font-size: 24px;
	color: #FFFFFF;
	font-weight: bold;
}
.style4 {
	color: #00FF00;
	font-weight: bold;
	font-family: "Century Gothic";
}
.style7 {font-size: 10px}
.style8 {font-size: 12px}
body {
	background-color: #000000;
}
-->
</style>
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td height="37" colspan="4" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#999999"><p align="left"><span class="style7"><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"></a></font></span><br />
    </p>    </td>
    <td width="70%" bgcolor="#999999"><span class="style8"><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;GO BACK</font></a></font></span></td>
    <td width="22%" bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#003300"><div align="center"><span class="style3">STUDENTS REGISTRATION LOGIN</span></div></td>
  </tr>
  <tr>
    <td width="4%" bgcolor="#009900">&nbsp;</td>
    <td colspan="2" background="images/bg1.jpg"><p align="center"><br />
      You have to register your data, before the system could allow you to take an exam. Please specify the correct login password. </p>
    <p>&nbsp;</p>
    <table width="29%" border="3" align="center">
      <tr>
        		<td width="21%" height="26" background="images/computer_chip3.jpg" align="center"><b>
		<span style="background-color: #999999">Enter Password</span></b>
                  <form method="POST" action="registration_login.php">
        <!--webbot bot="SaveResults" u-file="C:\Program Files\EasyPHP1-7\www\datamix\_private\form_results.csv" s-format="TEXT/CSV" s-label-fields="TRUE" -->
        <p align="center">
          <input name="password" type="password" id="password" size="30">
          <br>
          <input type="submit" value="Login" name="B1" />
        </p>
                  </form>		</td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>
    <td width="4%" bgcolor="#006600">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#003300">&nbsp;</td>
    <td colspan="2" bgcolor="#003300">&nbsp;</td>
    <td bgcolor="#003300">&nbsp;</td>
  </tr>
</table>
</body>
</html>
