<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>E-TEST ::: Test Login</title>
<style type="text/css">
<!--
.style2 {
	font-family: "Century Gothic";
	font-weight: bold;
}
-->
</style>
</head>

<body bgcolor="#FFFFFF">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("test_type","course","code", "no","name","department");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("TEST TYPE","COURSE","CODE","REG NO","NAME","DEPARTMENT");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="91%" align="center">
<?php

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

include('dbconnect.php');



// DISABLE PREVIOUS DAYS TEST SCHEDULE


// Disable Quiz, Exam or Exam Re-sit.

$delete1 = "DELETE FROM candidate_login_table WHERE test_date != '$system_date'";
$result = mysql_query($delete1);


$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "/";

$ans_date = $computer_date_day.$dash.$computer_date_month.$dash.$computer_date_year ;

$delete2 = "DELETE FROM answered_questions WHERE exam_date != '$ans_date'";
$result2 = mysql_query($delete2);



?>


  <tr bgcolor="#006600"> 
    <td colspan="6" bgcolor="#000000">&nbsp; 
      <p align="center"><br>
    &nbsp;</td>
  </tr>
  <tr> 
    <td valign="top" bgcolor="#CCFF99" colspan="5" height="98">
	<p align="center"><font face="Copperplate Gothic Bold">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>ELECTRONIC 
	EXAMINATION SYSTEM</u></font><br>
	</p>
	<p>     
	<form method="POST" action="choose_course.php" onSubmit="return formCheck(this);">
    
	<p><br>
    <td width="22%" valign="top" bgcolor="#006600" rowspan="12" bordercolor="#008000"> 
      <p align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
        &nbsp;<font face="Verdana" size="2"><span style="font-weight: 700; background-color: #FFFF00">COURSE 
		LIST</span></font><br>
		<iframe name="I1" width="146" height="289" src="course_list_frame.php">
      Your browser does not support inline frames or is currently configured not to display inline frames.</iframe></p>      </td>
  
  <tr> 
    <td valign="top" bgcolor="#000000" colspan="5">
	<font face="Small Fonts" color="#FFFFFF" style="font-size: 11pt">
	<marquee behavior="alternate" scrollamount="5">
	ENTER YOUR  REG NO TO LOGIN
	</marquee></font></td>
  </tr>
  <tr>
    <td width="12%" rowspan="7" valign="top" bgcolor="#000000">&nbsp;</td>
    <td height="21" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td width="32%" height="21" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td height="21" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td width="20%" rowspan="7" valign="top" bgcolor="#000000">&nbsp;</td>
  </tr>
  
  <tr>
    
  <tr>
    <td width="5%" valign="top" bgcolor="#CCFF99" class="style2">Reg No </td>
    <td valign="top" bgcolor="#CCFF99"><label>
      <select name="code" id="code">
        <option>DIT/</option>
        <option>CIT/</option>
        <option>CCSA/</option>
        <option>DCSA/</option>
        <option>DCRM/</option>
        <option>CCRM/</option>
        <option>DSET/</option>
        <option>CSET/</option>
      </select>
      /
      <select name="month" id="month">
        <option>01</option>
        <option>02</option>
        <option>03</option>
        <option>04</option>
        <option>05</option>
        <option>06</option>
        <option>07</option>
        <option>08</option>
        <option>09</option>
        <option>10</option>
        <option>11</option>
        <option>12</option>
      </select>
      /
      <select name="year" id="year">
        <option>12</option>
        <option>13</option>
        <option>14</option>
        <option>15</option>
        <option>16</option>
        <option>17</option>
        <option>18</option>
        <option>19</option>
        <option>20</option>
      </select>
      /
      <input name="no" type="text" id="no" size="4" maxlength="4">
    </label></td>
    <td width="8%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
  </tr>
  <tr>
    <td width="5%" valign="top" bgcolor="#CCFF99" class="style2">&nbsp;</td>
    <td valign="top" bgcolor="#CCFF99"><label></label></td>
    <td width="8%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
  </tr>
  <tr>
    <td width="5%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
    <td valign="top" bgcolor="#CCFF99">&nbsp;</td>
    <td width="8%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td valign="top" bgcolor="#CCCCCC"><input type="submit" value="Login" name="login"></td>
    <td valign="top" bgcolor="#CCCCCC">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#000000" colspan="2"></td>
    <td valign="top" bgcolor="#000000">
    <div align="left"></form>
        </td><td valign="top" bgcolor="#000000">&nbsp;</td>
    <td valign="top" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CCFF99" colspan="5" height="22">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CCFF99" colspan="5"><div align="center">
      <font color="#00FF00"><strong><span style="background-color: #000000">
      <a href="students_registration_login_page.php" style="text-decoration: none"></a></span></strong></font></div></td>
  </tr>
  <tr> 
    <td bgcolor="#000000" valign="bottom" colspan="5">
	<p align="center">&nbsp; 
      <img border="0" src="images/book.gif" width="83" height="47"><font color="#FFFF00"><b>
      <marquee></marquee>
    </b></font></td>
    <td width="23%" valign="bottom" bgcolor="#000000"><font size="2"><font color="#00FF00">
	Powered by</font> <font color="#FFFF00"><br>
	e-NERGY Software Solutions. 08039098042 </font>&nbsp;</font></td>
  </tr>
</table>

</body>

</html>