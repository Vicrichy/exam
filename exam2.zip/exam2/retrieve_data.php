<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST</title>
</head>

<body bgcolor="#CC99FF">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
  <tr bgcolor="#000000"> 
    <td colspan="4"> <p align="right"> <b><font size="2" color="#008000"> <a href="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/help.html"> 
        </a></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;GO 
        BACK</font></a></font></b></p>
      <p align="center"> <font size="5">&nbsp;</font><b><font size="5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <font color="#0000FF" face="Copperplate Gothic Bold"><u>REGISTRATION RECORDS</u></font></font></b></td>
  </tr>
  <tr> 
    <td width="75%" valign="top" bgcolor="#808000" colspan="2"><u> <font color="#FFFFFF"><b>RETRIEVE 
      REGISTRATION RECORDS</b></font></u></td>
    <td width="75%" valign="top">&nbsp; </td>
    <td width="3%" bgcolor="#000000" rowspan="9">&nbsp;</td>
  </tr>
  <tr> 
    <td width="75%" height="95" colspan="3" valign="top" bgcolor="#CC99FF">&nbsp;<font size="2"><b> 
      </b></font> <p><font size="2"><b>&nbsp; </b></font></p>
      <form method="POST" action="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/sh_all_regular_records.php">
        <p align="center"> 
          <input type="submit" value="SHOW ALL STUDENTS REGULAR REGISTRATION RECORDS" name="B1">
        </p>
      </form>
      <p><font size="2"><b><br>
        &nbsp;</b></font></td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="19" bgcolor="#808000" colspan="2">&nbsp; </td>
    <td width="75%" valign="top" height="19" bgcolor="#808000">&nbsp;</td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="19" colspan="3" bgcolor="#000000"> <font color="#FFFF00">&nbsp;SEARCH 
      BY NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SEARCH 
      BY REG. DATE</font></td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="140"> <form method="POST" action="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/searchname_regular.php">
        <p><b>SURNAME</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="surname" size="20">
          <br>
          <b>FIRST NAME</b>&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="first_name" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B2">
        </p>
      </form>
      <p></td>
    <td width="75%" valign="top" height="140" rowspan="5" bgcolor="#000000">&nbsp;</td>
    <td width="75%" valign="top" height="140"><form method="POST" action="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/searchdate_regular.php">
        <p><font color="#000000"><b>SEARCH BYDATE</b></font>&nbsp;&nbsp;&nbsp; 
          <b><font size="2"> 
          <select name="month" id="selectmonth" style="width:49; height:22" size="1">
            <option value="jan">Jan</option>
            <option value="feb">Feb</option>
            <option value="mar">Mar</option>
            <option value="apr">Apr</option>
            <option value="may">May</option>
            <option value="jun">Jun</option>
            <option value="jul">Jul</option>
            <option value="aug">Aug</option>
            <option value="sep">Sep</option>
            <option value="oct">Oct</option>
            <option value="nov">Nov</option>
            <option value="dec">Dec</option>
          </select>
          </font> </b><font size="2"><b> 
          <select name="day" id="selectday" size="1">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
          <select name="year" id="selectyear" size="1">
            <option value="1970">1970</option>
            <option value="1971">1971</option>
            <option value="1972">1972</option>
            <option value="1973">1973</option>
            <option value="1974">1974</option>
            <option value="1975">1975</option>
            <option value="1976">1976</option>
            <option value="1977">1977</option>
            <option value="1978">1978</option>
            <option value="1979">1979</option>
            <option value="1980">1980</option>
            <option value="1981">1981</option>
            <option value="1982">1982</option>
            <option value="1983">1983</option>
            <option value="1984">1984</option>
            <option value="1985">1985</option>
            <option value="1986">1986</option>
            <option value="1987">1987</option>
            <option value="1988">1988</option>
            <option value="1989">1989</option>
            <option value="1990">1990</option>
            <option value="1991">1991</option>
            <option value="1992">1992</option>
            <option value="1993">1993</option>
            <option value="1994">1994</option>
            <option value="1995">1995</option>
            <option value="1996">1996</option>
            <option value="1997">1997</option>
            <option value="1998">1998</option>
            <option value="1999">1999</option>
            <option value="2000">2000</option>
            <option value="2001">2001</option>
            <option value="2002">2002</option>
            <option value="2003">2003</option>
            <option value="2004">2004</option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
            <option value="2028">2028</option>
            <option value="2029">2029</option>
            <option value="2030">2030</option>
            <option value="2031">2031</option>
            <option value="2032">2032</option>
            <option value="2033">2033</option>
            <option value="2034">2034</option>
            <option value="2035">2035</option>
            <option value="2036">2036</option>
            <option value="2037">2037</option>
            <option value="2038">2038</option>
            <option value="2039">2039</option>
            <option value="2040">2040</option>
            <option value="2041">2041</option>
            <option value="2042">2042</option>
            <option value="2043">2043</option>
            <option value="2044">2044</option>
            <option value="2045">2045</option>
            <option value="2046">2046</option>
            <option value="2047">2047</option>
            <option value="2048">2048</option>
            <option value="2049">2049</option>
            <option value="2050">2050</option>
            <option value="2051">2051</option>
            <option value="2052">2052</option>
            <option value="2053">2053</option>
            <option value="2054">2054</option>
            <option value="2055">2055</option>
            <option value="2056">2056</option>
            <option value="2057">2057</option>
            <option value="2058">2058</option>
            <option value="2059">2059</option>
            <option value="2059">2060</option>
            <option value="2061">2061</option>
            <option value="2062">2062</option>
            <option value="2063">2063</option>
            <option value="2064">2064</option>
            <option value="2065">2065</option>
            <option value="2066">2066</option>
            <option value="2067">2067</option>
            <option value="2068">2068</option>
            <option value="2069">2069</option>
            <option value="2070">2070</option>
            <option value="2071">2071</option>
            <option value="2072">2072</option>
            <option value="2073">2073</option>
            <option value="2074">2074</option>
            <option value="2075">2075</option>
            <option value="2076">2076</option>
            <option value="2077">2077</option>
            <option value="2078">2078</option>
            <option value="2079">2079</option>
            <option value="2080">2080</option>
            <option value="2081">2081</option>
            <option value="2082">2082</option>
            <option value="2083">2083</option>
            <option value="2084">2084</option>
            <option value="2085">2085</option>
            <option value="2086">2086</option>
            <option value="2087">2087</option>
            <option value="2088">2088</option>
            <option value="2089">2089</option>
            <option value="2090">2090</option>
          </select>
          </b></font><br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;<br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="140" bgcolor="#000000">&nbsp;<font color="#FFFF00">SEARCH 
      BY REG. NUMBER</font></td>
    <td width="75%" valign="top" height="140" bgcolor="#000000">&nbsp;<font color="#FFFF00">SEARCH 
      BY STATE OF ORIGIN</font></td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="140"> <form method="POST" action="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/searchregno_regular.php">
        <p><b>REG. NUMBER</b>&nbsp;&nbsp; 
          <input type="text" name="reg_no" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
    <td width="75%" valign="top" height="140"><form method="POST" action="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/searchstate_regular.php">
        <p><font color="#C0C0C0"><b>SEARCH STATE</b></font>&nbsp;&nbsp; 
          <select name="state_of_origin" class="smalldropbox" size="1">
            <OPTION selected>--SELECT--</OPTION>
            <OPTION>Non - Nigerian</OPTION>
            <OPTION>Abia</OPTION>
            <OPTION>Abuja</OPTION>
            <OPTION>Adamawa</OPTION>
            <OPTION>Akwa Ibom</OPTION>
            <OPTION>Anambra</OPTION>
            <OPTION>Bauchi</OPTION>
            <OPTION>Bayelsa</OPTION>
            <OPTION>Benue</OPTION>
            <OPTION>Borno</OPTION>
            <OPTION>Cross River</OPTION>
            <OPTION>Delta</OPTION>
            <OPTION>Ebonyi</OPTION>
            <OPTION>Edo</OPTION>
            <OPTION>Ekiti</OPTION>
            <OPTION>Enugu</OPTION>
            <OPTION>Gombe</OPTION>
            <OPTION>Imo</OPTION>
            <OPTION>Jigawa</OPTION>
            <OPTION>Kaduna</OPTION>
            <OPTION>Kano</OPTION>
            <OPTION>Katsina</OPTION>
            <OPTION>Kebbi</OPTION>
            <OPTION>Kogi</OPTION>
            <OPTION>Kwara</OPTION>
            <OPTION>Lagos</OPTION>
            <OPTION>Nassarawa</OPTION>
            <OPTION>Niger</OPTION>
            <OPTION>Ogun</OPTION>
            <OPTION>Ondo</OPTION>
            <OPTION>Osun</OPTION>
            <OPTION>Oyo</OPTION>
            <OPTION>Plateau</OPTION>
            <OPTION>Rivers</OPTION>
            <OPTION>Sokoto</OPTION>
            <OPTION>Taraba</OPTION>
            <OPTION>Yobe</OPTION>
            <OPTION>Zamfara</OPTION>
          </SELECT>
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="140" bgcolor="#000000">&nbsp;<font color="#FFFF00">SEARCH 
      BY DEPARTMENT</font></td>
    <td width="75%" valign="top" height="140" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="140"><form method="POST" action="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/searchdepartment_regular.php">
        <p><b>DEPARTMENT </b>&nbsp;&nbsp; 
          <input type="text" name="department" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
    <td width="75%" valign="top" height="140">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="4" bgcolor="#FFFF00"> <p align="center"></td>
  </tr>
</table>

</body>

</html>