<?php
$year = date("Y");
$month = date("M");
$rand = rand();

echo "$year/$month/REG/$rand";
?>