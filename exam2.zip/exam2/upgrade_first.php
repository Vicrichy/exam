<?php

include('dbconnect.php');

mysql_query("UPDATE `registration_table` SET `semester`='SECOND' WHERE `semester`='FIRST'");

echo "SEMESTER UPGRADED TO SECOND";

echo "<a href=javascript:history.back()> << Return </a>";

?>