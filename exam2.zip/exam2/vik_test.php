<?php 
// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with correct details</p></i></b>";
exit();
} 
else
?> 
<table width="100%" height="601" border="0" cellpadding="0" style="border-collapse: collapse">
	<tr>
		<td width="31" height="38" rowspan="2" bgcolor="#000000">&nbsp;</td>
		<td height="38" colspan="3" valign="middle" bgcolor="#000000"><div align="center"><form action="index.php" method="post" name="form1" target="_parent">
      <div align="right"> <u><b><font color="#CC99FF" size="5" face="Copperplate Gothic Bold">
        <input type="submit" name="Submit" value="Sign out">
      </font></b></u></div>
    </form> <br>
            <span class="style1">&nbsp;<span class="style2">TEST OVER </span></span> </div></td>
		<td width="32" rowspan="2" bgcolor="#000000">&nbsp;</td>
	</tr>
	<tr> 
	  <td height="33" colspan="3" bgcolor="#FFFFFF"><?php
	  if (($_SESSION['test_type']) == 'Quiz')

{
	  if (($score_percent) >= 40)
	  {
	  echo "<H1 align=center><font color = green><b> CONGRATULATIONS, YOU PASSED ! </b></font></h1>";
	  }
	  else
	  {
	   echo "<H1 align=center><font color = red><b> SORRY, YOU FAILED !! </b></font></h1>";
	  }
	  }


	 
	 
	 
	  if (($_SESSION['test_type']) == 'Exam')

{	  
$total_percent = ($total_score/100)* 100 ;



if (($score_percent) >= 40)
	  {
	  echo "<H2 align=center><font color = green><b> CONGRATULATIONS, YOU PASSED ! </b></font></h2>";
	  }
	  else
	  {
	   echo "<H2 align=center><font color = red><b> SORRY, YOU FAILED </b></font></h2>";
	  }

}
	 
	  ?>&nbsp; </td>
  </tr>
	<tr>
		<td width="31" height="467" bgcolor="#000000">&nbsp;</td>
		<td width="124"><p>&nbsp;</p>
		<p><br>
        <font face="Bodoni MT Black" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
		<br>
		</font><br>
&nbsp;</td>
		<td width="427" valign="top" background="images/scroll2.gif" bgcolor="#FFFFFF"><p>&nbsp;</p>
	    <p align="center"> <br>
	    <u><strong>YOUR SCORE DETAILS</strong></u></p>
	    <table width="80%" border="1" align="center">
          <tr bgcolor="#000000">
            <td width="35%" height="43"><span class="style8">Statistics</span></td>
            <td width="23%"><span class="style7">QUIZ</span></td>
            <td width="21%"><span class="style7">EXAM</span></td>
            <td width="21%"><span class="style7">EXAM <br>
            RE-SIT </span></td>
          </tr>
          <tr>
		  <?php
		  ////////////////////////////////////////////
		  // GENERALLY, LETS PICK THE VARIABLES
		  /////////////////////////////////////////////
		  
		  //FOR QUIZ
		  


@$queryx = mysql_query("SELECT score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
@$actual_scorex = mysql_result($queryx, 0, "score");

@$queryx2 = mysql_query("SELECT max_score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
@$max_scorex = mysql_result($queryx2, 0, "max_score");

        
		// FOR EXAM
@$queryy2 = mysql_query("SELECT max_score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
@$max_scorey = mysql_result($queryy2, 0, "max_score");


          // TOTAL GRADE
		  
		 if (($_SESSION['test_type']) == 'Quiz')
{
		 $grade_total = $qgrade;
		 }
		 else
		 {

$queryt = mysql_query("SELECT grade FROM compute_results WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$grade_total = mysql_result($queryt, 0, "grade");
          }

		  
		  ?>
            <td bgcolor="#006600"><span class="style9">Total Questions </span></td>
            <td><strong>
            <?php
			echo "$total_questions";
			?>
            &nbsp;</strong></td>
            <td><?php
			if ((mysql_num_rows($resultcheck)) > 0)
{
			echo "<b>$total_questions_exam</b>";
			}
			?></td>
            <td><span class="style13">
            <?php
		
			if ((mysql_num_rows($resultcheck2)) > 0)
{
echo "<b>$total_questions_resit</b>"; }
			?>
            </span></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style9">No.Attempted</span></td>
            <td><strong><?php echo "$no_attempted"; ?>&nbsp;</strong></td>
            <td><?php 
			if ((mysql_num_rows($resultcheck)) > 0)
{
			echo "$no_attempted_exam";
			}
			 ?></td>
            <td><span class="style14">
            <?php if ((mysql_num_rows($resultcheck2)) > 0)
{
echo "<b>$no_attempted_resit"; } ?>
            </span></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style9">No. Passed </span></td>
            <td><strong><?php echo "$no_passed";  ?>&nbsp;</strong></td>
            <td><span class="style10">
            <?php
			if ((mysql_num_rows($resultcheck)) > 0)
{
			 echo "<b>$no_passed_exam";  
			 
			 }?>
            </span></td>
            <td><span class="style15">
            <?php if ((mysql_num_rows($resultcheck2)) > 0)
{
echo "$no_passed_resit"; 
} ?>
            </span></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style9">No. Failed </span></td>
            <td><strong><?php echo "$no_failed"; ?>&nbsp;</strong></td>
            <td><span class="style11">
            <?php 
			if ((mysql_num_rows($resultcheck)) > 0)
{
			echo "$no_failed_exam"; 
			}?>
            </span></td>
            <td><span class="style16">
            <?php if ((mysql_num_rows($resultcheck2)) > 0)
{
echo "$no_failed_resit"; 
}?>
            </span></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style9">Score</span></td>
            <td><strong>
            <?php 
		
			echo "$actual_scorex"; 
			
			?>
            /<?php echo "$max_scorex"; ?>&nbsp;</strong></td>
            <td><strong>
            <?php
					if ((mysql_num_rows($resultcheck)) > 0)
{
			 echo "$actual_score_exam"; 
			 }?>
            /
            <?php		

 echo "$max_scorey"; ?>
            &nbsp;</strong></td>
            <td><strong>
            <?php if ((mysql_num_rows($resultcheck2)) > 0)
{
 echo "$actual_score_resit"; 
 }?>
            /
            <?php if ((mysql_num_rows($resultcheck2)) > 0)
{
 echo "$max_score_resit"; }?>
            &nbsp;</strong></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style9">Grade</span></td>
            <td><strong><?php echo "$qgrade";?>&nbsp;</strong></td>
            <td><span class="style12">
            <?php
			if ((mysql_num_rows($resultcheck)) > 0)
{
 echo "$qgrade_exam";
 }?>
            </span></td>
            <td><span class="style17">
            <?php if ((mysql_num_rows($resultcheck2)) > 0)
{
echo "$qgrade_resit"; }?>
            </span></td>
          </tr>
        </table>	    
	    <p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>        Your Total Score</strong> = <?php echo "$total_score"; ?><br>
	     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Grade = </strong><?php
		 if (($_SESSION['test_type']) == 'Quiz')
{
		 echo "$qgrade";
} elseif (($_SESSION['test_type']) == 'Exam Re-sit')
   { 
         echo "$qgrade_resit";
	}
    else
      {
	      echo "$qgrade_exam";
	   }
		 ?><br>
          <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Course = </strong><?php
		  echo "$_SESSION[course]";
		  
		  ?></p>
      <p align="left">&nbsp;  </p></td>
		<td width="124">&nbsp;</td>
		<td width="32" bgcolor="#000000">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="31" height="46" bgcolor="#000000">&nbsp;</td>
		
    <td height="46" colspan="3" bgcolor="#000000">  </td>
		<td width="32" bgcolor="#000000">&nbsp;</td>
	</tr>
</table>

</body>

</html>
<?php

?>
<?php

session_destroy();



?>
<?php

?>  

