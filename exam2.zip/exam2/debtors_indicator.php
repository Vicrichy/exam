<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#000000">
<strong><font color="#FF0000">
<?php

include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-" ;

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


$query = ("SELECT SURNAME, FIRST_NAME FROM registration_table WHERE c_date <= '$system_date' and payment_status = 'PARTIAL' ");
$result = mysql_query($query);
if (mysql_num_rows($result) > 0 )
{
header('Location: debtors_indicator2.php');

}
}
?>
</font></strong> 
<p>&nbsp;</p>

</body>
</html>
