<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 2) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 
<?php
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
?>

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST ::: Registration</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=4.0,Transition=10)">

<!-- BASIC CALENDAR HEADER -->
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
.style3 {color: #000000; font-weight: bold; }
.style5 {font-size: 12px}
</style>


<script type="text/javascript" src="basiccalendar.js">


</script>

<!-- BASIC CALENDAR HEADER ENDS -->
<script type="text/JavaScript">
<!--
function MM_popupMsg(msg) { //v1.0
  alert(msg);
}
//-->
</script>
</head>

<body background="images/reg_stuff.jpg">

<script language="JavaScript">


function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("firstname","surname","reg_no","department","batch_no","classroom","trainer","course","gender","pix","phone","Address","e-mail");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("FIRSTNAME","SURNAME","REG.NUMBER","DEPARTMENT","BATCH NUMBER","CLASSROOM","TRAINER","COURSE","GENDER","PICTURE","PHONE","ADDRESS","E-MAIL");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}

function checkAddress() {
if (document.reg.email.value.indexOf("@") == -1) {
alert("Check the e-mail address for accuracy.")
document.reg.email.value="";
document.reg.email.setFocus()
return false
}
return true
}


function checkIt(evt) {
evt = (evt) ? evt : window.event
var charCode = (evt.which) ? evt.which : evt.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57)) {
alert("This field accepts numbers only.")
status = "This field accepts numbers only."
return false
}
status = ""
return true
}
// -->
</script>



<table border="0" cellpadding="0" style="border-collapse: collapse" width="104%">
  <tr> 
    <td height="77" colspan="2" bgcolor="#008000"> <p align="center"><b><font size="5"><font color="#FFFFFF"><u><font face="Copperplate Gothic Bold">STUDENTS 
        REGISTRATION</font></u></font></font></b> 
    </td>
    <td bgcolor="#FFFFFF">&nbsp; </td>
  </tr>
  <tr> 
    <td width="18%" bgcolor="#000000" rowspan="2" valign="top"><p><strong><a href="img_upl.php"></a></strong> <span class="style5"><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"></a></font></span></p>
      <p><strong><a href="additional_payment.php"></a></strong> &nbsp; </p>
      <p>&nbsp;<a href="registration_page.php"></a></p>
      <p> &nbsp;<a href="retrieve_data_scheduler_reg2.php"></a></p>
      <p><a href="modify_reg_data.php"></a>      </p>
      <p>&nbsp;<br>
        <strong><a href="ongoing_classes.php"></a></strong><br>
        &nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><font color="#CCCCCC"><br>
        </font></td>
    <td width="77%" height="25" valign="top" bgcolor="#808000"><span class="style1">STUDENTS REGISTRATION </span></td>
    <td width="5%" bgcolor="#008000" rowspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="77%" valign="top" height="377"><form name="reg" action="insert_registration_script.php" method="POST" enctype="multipart/form-data" onSubmit="return formCheck(this);">
        <!--webbot bot="SaveResults" U-File="fpweb:///_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bordercolorlight="#000099" bordercolordark="#000080">
          
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">First 
              Name</font></span></td>
            <td width="205"><input name="firstname" type="text" id="firstname" size="25" tabindex="1"></td>
            <td width="85" bgcolor="#006600"><span class="style1"><font face="Agency FB">Trainer</font></span></td>
            <td><input name="trainer" type="text" id="trainer" tabindex="11" size="40"></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Surname</font></span></td>
            <td width="205"><input name="surname" type="text" id="surname" size="25" tabindex="2"></td>
            <td width="85" bgcolor="#006600"><span class="style1">Course</span></td>
            <td><input name="course" type="text" id="course" tabindex="12" value="UMITT" size="40"></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Othernames</font></span></td>
            <td><input name="othernames" type="text" id="othernames" size="25" tabindex="3"></td>
            <td bgcolor="#006600"><span class="style1">Gender</span></td>
            <td><select name="gender" id="gender" tabindex="13">
              <option selected></option>
              <option>MALE</option>
              <option>FEMALE</option>
            </select></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Reg. No</font></span></td>
            <td width="205"><input name="reg_no" type="text" id="reg_no" tabindex="4" size="18">
            <br></td>
            <td width="85" bgcolor="#006600"><span class="style1"><font face="Agency FB">Date</font></span></td>
            <td><span class="style3">:&nbsp;
                <?php
			echo "$system_date";
			?>
            </span></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Contact Address</font></span></td>
            <td width="205"><input name="address" type="text" id="address" tabindex="5"></td>
            <td width="85" bgcolor="#006600"><span class="style1"><font face="Agency FB">Picture</font></span></td>
            <td><label>
              <input type="file" name="userfile" tabindex="14">
            </label></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Phone Number</font></span></td>
            <td width="205"><input name="phone" type="text" id="phone" onKeyPress="return checkIt(event)" tabindex="6"></td>
            <td width="85">&nbsp;</td>
            <td><span class="style1"><font face="Agency FB" color="#FF0000">The size of the picture should not be more than 4kb</font></span></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1">E-mail</span></td>
            <td width="205"><input name="email" type="text" id="email" onChange="checkAddress()" tabindex="7"></td>
            <td width="85">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  <tr> 
            <td width="99" bgcolor="#006600"><span class="style1">Department</span></td>
            <td width="205"><select name="department" id="department" tabindex="8">
              <?php 
include('dbconnect.php');


$query3 = "SELECT distinct department FROM departments_table order by department";
$result3 = mysql_query($query3);

echo "<option selected></option>";
while ($row = mysql_fetch_array($result3, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{

echo "<option value>";
echo "$value" . "</br>";
echo "</option>";

}}?>
            </select></td>
            <td width="85">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  <tr> 
            <td width="99" bgcolor="#006600"><span class="style1">Batch No</span></td>
            <td width="205"><select name="batch_no" id="batch_no" tabindex="9" onBlur="MM_popupMsg('I hope the details (name, reg no, department and batch no) you specified are correct.\rPlease be sure. \rThis is your last warning.')">
              <option selected></option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
              <option>6</option>
              <option>7</option>
              <option>8</option>
              <option>9</option>
              <option>10</option>
              <option>11</option>
              <option>12</option>
              <option>13</option>
              <option>14</option>
              <option>15</option>
              <option>16</option>
              <option>17</option>
              <option>18</option>
              <option>19</option>
              <option>20</option>
              <option>21</option>
              <option>22</option>
              <option>23</option>
              <option>24</option>
              <option>25</option>
              <option>26</option>
              <option>27</option>
              <option>28</option>
              <option>29</option>
              <option>30</option>
              <option>31</option>
              <option>32</option>
              <option>33</option>
              <option>34</option>
              <option>35</option>
              <option>36</option>
              <option>37</option>
              <option>38</option>
              <option>39</option>
              <option>40</option>
              <option>41</option>
              <option>42</option>
              <option>43</option>
              <option>44</option>
              <option>45</option>
              <option>46</option>
              <option>47</option>
              <option>48</option>
              <option>49</option>
              <option>50</option>
            </select></td>
            <td width="85">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  <tr> 
            <td width="99" bgcolor="#006600"><span class="style1">Classroom</span></td>
            <td width="205"><input name="classroom" type="text" id="classroom" tabindex="10"></td>
            <td width="85">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        <p align="center"> 
          <input type="submit" value="SUBMIT" name="B1" style="font-weight: 700">
          &nbsp;&nbsp;&nbsp; 
          <input type="reset" name="Reset" value="Reset">
        </p>
      </form>
    &nbsp;All fields are mandatory, except &quot;Othernames&quot;.
      <p><font size="2"><b> 
      </b></font></p></td>
  </tr>
  
  <tr> 
    <td height="19" colspan="2" bgcolor="#008000"> <p align="center"></td>
    <td bgcolor="#FFFF00">&nbsp; </td>
  </tr>
</table>

</body>

</html>
<?php
}
?>