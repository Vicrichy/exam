<?php

session_start();

$name = addslashes($_POST['name']);
$course = addslashes($_POST['course']);
$date = addslashes($_POST['date']);
$venue = addslashes($_POST['venue']);

session_register('$name');
session_register('$course');
session_register('$date');
session_register('$venue');

$_SESSION['name'] = $name;
$_SESSION['course'] = $course;
$_SESSION['date'] = $date;
$_SESSION['venue'] = $venue;

header("location:admission_letter.php");
?>