<?php

$password = addslashes($_POST['password']);
include('dbconnect.php');

$query = mysql_query("SELECT `password` from `finance_password` WHERE `password` = '$password'");

$num_rows = mysql_num_rows($query);

if($num_rows<1)
{
 echo "YOU ARE NOT AUTHORIZED TO VIEW THIS SECTION!!";
 exit;
}
else
{
 header("location:sh_all_receipt_records.php");
}  
?>