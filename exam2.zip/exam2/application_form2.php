<?php
$code = rand();

/*include('dbconnect.php');

$sql =mysql_query("SELECT `form_code` FROM `receipt` WHERE `form_code`='$code'");
$num_rows = mysql_num_rows($sql);
if($num_rows>1)
{
 $code = $code+1;

mysql_query("INSERT INTO receipt SET `form_code`= '$code'");
}*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Pacific Computer::Application Form</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.style1 {
	font-size: 18px;
	font-weight: bold;
}
.style4 {font-size: 14px; font-weight: bold; }
.style5 {
	font-size: 12px;
	font-weight: bold;
}
.style8 {font-size: 16px; font-weight: bold; }
.style9 {font-size: 14px}
.style10 {font-size: 18px}
#Layer1 {
	position:absolute;
	width:41px;
	height:27px;
	z-index:1;
	left: 596px;
	top: 966px;
}
#Layer2 {
	position:absolute;
	width:47px;
	height:26px;
	z-index:2;
	left: 524px;
	top: 966px;
}
-->
</style></head>

<body onload="window.print();">
<table width="767" border="0" align="center" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td colspan="2" rowspan="5" valign="top"><img src="logos.JPG" alt="logo" width="121" height="128" /></td>
    <td height="44" colspan="12" align="center" valign="top"><p class="style1">PACIFIC COMPUTER AND MANAGEMENT COLLEGE NIGERIA LIMITED </p></td>
  </tr>
  <tr>
    <td width="13" height="17"></td>
    <td width="13"></td>
    <td width="14"></td>
    <td width="150"></td>
    <td width="26"></td>
    <td width="47"></td>
    <td width="34"></td>
    <td width="51"></td>
    <td width="30"></td>
    <td width="95"></td>
    <td width="143"></td>
    <td width="32"></td>
  </tr>
  <tr>
    <td height="14"></td>
    <td colspan="9" rowspan="2" valign="top"><span class="style8">SPECIALISED COMPUTER TRAINING PROGRAMME </span></td>
    <td></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="20"></td>
    <td colspan="2" rowspan="3" valign="top"><p><strong>119 Ndidem Usang Iso Road,</strong></p>
    <p><strong>Calabar,</strong><strong>Cross River State</strong></p>      <p>&nbsp;</p></td>
  </tr>
  
  
  <tr>
    <td height="46"></td>
    <td colspan="7" align="center" valign="top" bordercolor="#000000" class="style1" border=4><table width="260" border="2">
      <tr>
        <td class="style10">APPLICATION FORM </td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2" rowspan="2" valign="top"><strong>RC. 355641 </strong></td>
    <td colspan="4" rowspan="2" valign="top"><span class="style4">FORM FEE: N 700.00 </span></td>
  <td height="15"></td>
    <td colspan="4" rowspan="2" valign="top" class="style4">FORM No: <?php echo $code;?> </td>
    <td></td>
  </tr>
  <tr>
    <td height="15"></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  <tr>
    <td height="137" colspan="4" valign="top"><table width="126" height="128" border="3" align="center">
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
    <td colspan="9" valign="top"><p><strong>NAME</strong>:............................................................................................................................................</p>
      <p><strong>ADDRESS</strong>:.......................................................................................................................................</p>
      <p><strong>NEXT OF KIN</strong>:................................................<strong>STATE OF ORIGIN</strong>:........................................................</p>
    <p><strong>LGA:</strong>....................................<strong>SEX:</strong>.............................<strong>MARITAL STATUS</strong>................................................</p>      <p><strong>EMAIL</strong>:....................................................<strong>PHONE</strong>...............................................................................   </p></td>
  </tr>
  <tr>
    <td height="151" colspan="14" valign="top"><p class="style9"><strong>ACADEMIC QUALIFICATION:</strong> </p>
      <table width="769" height="84" border="3">
        <!--DWLayoutTable-->
        <tr>
          <td width="167" height="22"><strong>INSTITUTIONS</strong></td>
          <td width="104"><strong>FROM</strong></td>
          <td width="98"><strong>TO</strong></td>
          <td width="379"><strong>QUALIFICATION OBTAINED</strong> </td>
        </tr>
        <tr>
          <td height="27">&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>      <p>(Attach photocopies of credentials)</p></td>
  </tr>
  <tr>
    <td height="16" colspan="8" valign="top"><span class="style5">PREVIOUS KNOWLEDGE OF COMPUTER STUDIES: </span></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="454" colspan="14" valign="top"><table width="765">
      <tr>
        <td width="86"><strong>BEGINNER </strong></td>
        <td width="32"><table width="32" border="3">
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></td>
        <td width="182"><strong>INTERMEDIATE KNOWLEDGE</strong></td>
        <td width="32"><table width="32" border="3">
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></td>
        <td width="409">EXPERT IN:.............................................................................</td>
      </tr>
    </table>
      
      <label><span class="style5">      </span></label>
      <p class="style8">COURSES AVAILABLE </p>
      <table width="765">
        <tr>
          <td width="329"><span class="style5">*CompTIA A+ </span></td>
          <td width="32"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
          <td width="33">&nbsp;</td>
          <td><span class="style5">*Network + </span></td>
          <td width="32"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
      </table>
      <table width="765">
        <tr>
          <td width="329">&nbsp;</td>
          <td width="32">&nbsp;</td>
          <td width="55">&nbsp;</td>
          <td width="32">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="32">&nbsp;</td>
          <td width="147">&nbsp;</td>
          <td width="32">&nbsp;</td>
        </tr>
      </table>
      <table width="765">
        <tr>
          <td width="329"><span class="style5">*Cisco Wireless </span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="33">&nbsp;</td>
          <td><span class="style5">*Cisco Certified Network Associate (CCNA) </span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <table width="765">
        <tr>
          <td width="329">&nbsp;</td>
          <td width="32">&nbsp;</td>
          <td width="55">&nbsp;</td>
          <td width="32">&nbsp;</td>
          <td width="70">&nbsp;</td>
          <td width="32">&nbsp;</td>
          <td width="147">&nbsp;</td>
          <td width="32">&nbsp;</td>
        </tr>
      </table>
      <table width="765">
        <tr>
          <td width="329"><span class="style5">*Cisco Security </span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="33">&nbsp;</td>
          <td><span class="style5">*Cisco Certified Network Professional(CCNP) </span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <hr />
      <table width="479">
        <tr>
          <td width="154"><span class="style5"><span class="style9">MODE OF STUDY: </span></span></td>
          <td width="57"><span class="style5">Morning</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="69"><span class="style5">Afternoon</span></td>
          <td width="32"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
          <td width="55"><span class="style5">Evening</span></td>
          <td width="34"><table width="32" border="3">
              <tr>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <p class="style5">CERTIFICATION</p>
      <p class="style5">I..........................................................................hereby certify that the information given by me above is true to the best of my knowledge. </p></td>
  </tr>
  <tr>
    <td width="46" height="12"></td>
    <td width="75"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="5" valign="top"><strong>Signature/Date:</strong>.............................................................</td>
  </tr>
  <tr>
    <td height="33" colspan="14" align="center" valign="top"><hr />
      <p><strong>OFFICIAL USE ONLY</strong></p></td>
  </tr>
  <tr>
    <td height="65">&nbsp;</td>
    <td colspan="12" align="center" valign="top"><table width="330">
      <tr>
        <td width="133"><strong>Applicant Qualified:</strong></td>
        <td width="36"><span class="style5">Yes</span></td>
        <td width="33"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        <td width="24"><span class="style5">No</span></td>
        <td width="80"><table width="32" border="3">
            <tr>
              <td>&nbsp;</td>
            </tr>
        </table></td>
      </tr>
    </table>
    <p><strong>Authorized Signature/Date</strong>:.................................................................... </p>    </td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
