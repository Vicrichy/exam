<?php 
// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
?><?php
include('dbconnect.php');
// RETRIEVE CANDIDATE'S FIRST NAME
$query2 =mysql_query("select first_name from registration_table where reg_no = '$_SESSION[reg_no]'");
$firstname =mysql_result($query2, 0, "first_name");
$question_count = 0 ;
// RETRIEVE THE NUMBER OF ANSWERED QUESTIONS (Please also scroll down to line 209 see this same block of codes below)
$query =mysql_query("select count(id) from answered_questions where reg_no = 
'$_SESSION[reg_no]' and course = '$_SESSION[course]'");
$question_query =mysql_result($query, 0, "count(id)") or die("Error");
$question_count = $question_query;
$display_no = $question_query + 1;
?>
<?php
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
$question_count = 0 ;
// RETRIEVE THE NUMBER OF ANSWERED QUESTIONS
$query =mysql_query("select count(id) from answered_questions where reg_no = 
'$_SESSION[reg_no]' and course = '$_SESSION[course]'");
$question_query =mysql_result($query, 0, "count(id)") or die("Error");
$question_count = $question_query  ;
$display_no = $question_query + 1 ;
if (($_SESSION['test_type']) == 'Quiz')
{
// EXTRACT SYSTEM DATE
$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";
$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
// SELECT MAX QUESTION SET FOR THE CANDIDATE
$query2 =mysql_query("select max_questions from candidate_login_table where course = 
'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_questions =mysql_result($query2, 0, "max_questions");
// SELECT MAX TIME SET FOR THE CANDIDATE
$query4 =mysql_query("select test_duration from candidate_login_table where course = 
'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_time =mysql_result($query4, 0, "test_duration");
}
if (($_SESSION['test_type']) == 'Exam')
{
// EXTRACT SYSTEM DATE
$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";
$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
// SELECT MAX QUESTION SET FOR THE CANDIDATE
$query2 =mysql_query("select max_questions from candidate_login_table where course = 
'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam'");
$query_max_questions =mysql_result($query2, 0, "max_questions");
// SELECT MAX TIME SET FOR THE CANDIDATE
$query4 =mysql_query("select test_duration from candidate_login_table where course = 
'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam'");
$query_max_time =mysql_result($query4, 0, "test_duration");
}?>
<?php
if (($question_count) >= ($query_max_questions)) 
	{ 
header('Location:test_over.php');

?>
<?php
}
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST ::: TESTING ROOM</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=2.0,Transition=21)">
<base target="rtop">
<style type="text/css">
<!--
.style1 {font-weight: bold;}
-->
</style>

</head>
<body bgcolor="#CCCCCC" background="images/bg1.jpg">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="">
<tr>
<td height="27" bgcolor="#000000"> 
<div align="left"><font color="#00FF33" size="4" face="Courier New, Courier, 
mono"><strong>ELECTRONIC TESTING ROOM </strong></font></div></td></tr></table>
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" 
height="44%">
<tr bgcolor="#006600"> 
<td height="19" colspan="4"> 
<p align="center"><font face="Bodoni MT Black" color="#FFFFFF"><b> 
QUESTION</b></font></td>
</tr>
<tr>
<td width="6%" bgcolor="#006600" rowspan="3">&nbsp;</td>
<td width="11%" align="center" valign="top" bgcolor="#00FF00"><?php
	echo "<h1>$display_no</h1>";
?><br> </td>
<td valign="top" bgcolor="#CCCCCC"><table>
<tr>
<td width="600"><font size="+2"><b>
<?php
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
//************* GENERATE RANDOM AND NON-REPETITIVE QUESTIONS. (I am using a Do loop to effect this).
do
{
include ('dbconnect.php');
// DETERMINE THE COURSE CODE
if (($_SESSION['test_type']) == 'Exam Re-sit')
{
$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_course = mysql_result($query_cc, 0, "course_code");
$query_coursecode = $query_course."_"."exam";
}
else
{
$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_course = mysql_result($query_cc, 0, "course_code");
$query_coursecode = $query_course."_".$_SESSION['test_type'];
}
// Determine the total number of questions available
$query_c = mysql_query("select count(question) from $query_coursecode where correct = 'right'");
$query_count = mysql_result($query_c, 0, "count(question)");
// Use this total to set the limit and initiate the random engine
mt_srand((double)microtime() * 1000000);
$number = mt_rand(1,$query_count);
//Check if the candidate has previously answered the question
$query_checkp = ("SELECT id FROM answered_questions WHERE reg_no = '$_SESSION[reg_no]' and 
course = '$_SESSION[course]' and id = '$number'");
$checkp = mysql_query($query_checkp);
$no_of_rows = mysql_num_rows($checkp) or die("Error") ;	
// Check if the number is available in the database table
$query_find = "SELECT id FROM $query_coursecode WHERE id = '$number'";
$result_find = mysql_query($query_find);
$no_available = mysql_num_rows($result_find);		 
}while(($no_of_rows > 0) or ($no_available == 0));
//******************************* RANDOM GENERATION ENDS
// SELECT A QUESTION
$query =mysql_query("select question from $query_coursecode where id = '$number'");
$now =mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
}
?>
<br>
<?php
if (($_SESSION['test_type']) == 'Exam Re-sit')
{
// EXTRACT SYSTEM DATE
$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";
$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
// SELECT MAX QUESTION SET FOR THE CANDIDATE
$query2 =mysql_query("select max_questions from candidate_login_table where course = 
'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_questions =mysql_result($query2, 0, "max_questions");
// SELECT MAX TIME SET FOR THE CANDIDATE
$query4 =mysql_query("select test_duration from candidate_login_table where course = 
'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_time =mysql_result($query4, 0, "test_duration");
}
// DETERMINE THE AMOUNT OF TIME (IN MINUTES) SPENT BY THE CANDIDATE IN THIS SESSION
  $spent_time = round((time() - $_SESSION['start']) / 60) ; 
 }
?>

<script language="javascript">
// THIS VALIDATES THE RADIO BUTTONS FOR THE OPTIONS
function valbutton(thisform) {
// place any other field validations that you require here
// validate myradiobuttons
myOption = -1;
for (i=thisform.choice.length-1; i > -1; i--) {
if (thisform.choice[i].checked) {
myOption = i; i = -1;
}
}
if (myOption == -1) {
alert("<?php echo "$firstname"; ?>, please you MUST select an option");
return false;
}
// place any other field validations that you require here
thisform.submit(); // this line submits the form after validation
}
</script>  
 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p></p>      <strong></strong></td>
    <td width="4%" bgcolor="#006600">&nbsp;</td>
	</tr>
	<tr>
	  <td height="19" bgcolor="#006600" colspan="3"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose an option, and click &quot;Submit Answer&quot; button to answer the question. </b></font></td>
  </tr>
	<tr>
	    <td height="19" bgcolor="#006600" colspan="3">
		<form action="submit_answer.php" method="POST" name="myform" id="myform">
	<table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="96%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
	<tr>
		<td width="57" bgcolor="#CCFFFF"><p align="left">
		  <label><strong>A</strong>
		  <input name="choice" type="radio" value="A" id ="a1">
		  </label>
	<?php
 // DETERMINE THE ID for the question
			//$query1 =mysql_query("select id from $query_coursecode where question = '$now'");
            // $move =mysql_result($query1, 0, "id"); 
             ?>
			      <input type="hidden" name="move_number" size="20" value='<?php
	echo "$number";
	?>'>
	   		</td>
		<td width="609" font size="+8">
				<?php
		// THE BLOCK OF CODES BELOW, PRINTS OUT THE OPTIONS FOR EACH INDIVIDUAL 
//QUESTION BESIDE EACH OPTION BUTTON
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'A'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);
echo "<table border = 0>";
//create table body
echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
?></td>
	</tr>
	<tr>
	  <td width="57" height="28" bgcolor="#CCFFFF"><strong>B</strong> 
      <input name="choice" type="radio" value="B" id ="b1"></td>
		<td height="28"><?php
	$query =("select obj from $query_coursecode where id = '$number' and alpha = 'B'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);
echo "<table border = 0>";
//create table body
echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
?>&nbsp;</td>
	</tr>
	<tr>
	  <td width="57" bgcolor="#CCFFFF"><label><strong>C</strong>
	      <input name="choice" type="radio" value="C" id ="c1">
	  </label></td>
		<td><?php
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'C'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);
echo "<table border = 0>";
//create table body
echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
?>&nbsp;&nbsp;</td>
	</tr>
	<tr>
	  <td width="57" bgcolor="#CCFFFF"><p>
	    <span class="style1">
	    <label>D
	    <input name="choice" type="radio" value="D" id ="d1">
	    </label>
      </span>	  </td>
		<td><?php
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'D'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);
echo "<b>\n";
echo "<table border = 0>";
//create table body
echo "<b>\n";
echo "<tr font size=+10>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
echo "<b>\n";
echo "<b>";
while( list ($key, $value) = each($row) )
{
echo "<b>\n";
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
// OPTION PRINTING ENDS
?>&nbsp;&nbsp;</td>
	</tr>
</table>
   <input type="submit" name="Submit" value="SUBMIT ANSWER" onClick="valbutton(myform);return false;" >
&nbsp;
</form></td>
	</tr>
</table>
<p align="center">&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
<?php
}
?>
 