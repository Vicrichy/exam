<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 24px;
}
.style2 {
	color: #00FF00;
	font-weight: bold;
	font-style: italic;
}
.style3 {
	color: #FFFFFF;
	font-weight: bold;
}
.style6 {
	color: #00FF00;
	font-style: italic;
}
.style7 {
	font-size: 24px;
	font-weight: bold;
}
.style9 {color: #00FF00; font-weight: bold; font-style: italic; background-color: #000000; }
-->
</style>



<script language="JavaScript">
<!--
function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("testmode","course","reg_no","operator","this_score","reason");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("TEST MODE","COURSE","REG. NUMBER","OPERATION MODE","ADDED/SUBTRACTED SCORE","REASON");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->

function MM_popupMsg(msg) { //v1.0
  alert(msg);
}
//-->
</script>




<script language="JavaScript">
<!--
function formCheck2(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("testmode","course","date_taken","department","operator","this_score","reason");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("TEST MODE","COURSE","DATE OF TEST","DEPARTMENT","OPERATION MODE","ADDED/SUBTRACTED SCORE","REASON");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->

function MM_popupMsg(msg) { //v1.0
  alert(msg);
}
//-->
</script>





</head>

<body bgcolor="#CC99FF">
<table width="100%" height="311" border="0">
  <tr>
    <td width="2%" height="25" bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000"><div align="center"><span class="style1">UPGRADE/DEGRADE SCORES  </span></div></td>
    <td width="2%" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td rowspan="11" bgcolor="#000000">&nbsp;</td>
    <td width="43%" rowspan="2"><p>This interface allows an administrator to alter a student's score. </p>
      <p>Please NOTE that when you perform this, the operation and date of executing this operation is permanently recorded for monitoring purposes. </p>
      <p>Also NOTE that the students previous scores would be ovewritten by the new one. </p>
    <p>&nbsp;</p></td>
    <td width="1%" rowspan="11" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="0%" rowspan="11" bgcolor="#000000">&nbsp;</td>
    <td width="1%" rowspan="11" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="51%" valign="top" bgcolor="#000000"><span class="style3">VIEW SCHEDULED TESTS </span></td>
    <td rowspan="11" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CC99FF"><form action="show_scheduled_tests.php" method="post" name="form1" id="form1">
      <br />
      <input type="submit" name="Submit32" value="VIEW SCHEDULED TESTS" />
    </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td valign="middle" bgcolor="#CCCCCC"><div align="center" class="style7">SINGLE  CANDIDATE </div></td>
    <td width="51%" valign="top" bgcolor="#000000"><span class="style3">VIEW MONITORING INFO </span></td>
  </tr>
  <tr>
    <td><form id="form1" name="form1" method="post" action="insert_individual_upgrade.php" onsubmit="return formCheck(this);">
      <table width="100%" border="0">
        <tr>
          <td bgcolor="#000000"><span class="style2">TEST MODE </span></td>
        </tr>
        <tr>
          <td><select name="testmode" id="testmode">
              <option selected="selected"></option>
              <option>Quiz</option>
              <option>Exam</option>
              <option>Exam Re-sit</option>
          </select></td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style2">COURSE</span></td>
        </tr>
        <tr>
          <td><input name="course" type="text" id="course" /></td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style2">STUDENT'S REG_NO. </span></td>
        </tr>
        <tr>
          <td><input name="reg_no" type="text" id="reg_no" /></td>
        </tr>
        <tr>
          <td bgcolor="#000000" class="style2">OPERATION MODE </td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><select name="operator" id="operator">
            <option selected></option>
			<option>ADD</option>
            <option>SUBTRACT</option>
          </select>          </td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style2">ADD/SUBTRACT THIS SCORE </span></td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><input name="this_score" type="text" id="this_score" onblur="MM_popupMsg('Please make SURE the details you have entered are correct.\rThis is IRREVERSIBLE.\rYou have been warned!')" /></td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style9">REASON FOR UPGRADE </span></td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><textarea name="reason" cols="30" id="reason"></textarea></td>
        </tr>
        
        <tr>
          <td bgcolor="#000000">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#000000"><input type="submit" name="Submit" value="UPGRADE/DEGRADE" />
              <input type="reset" name="Submit2" value="Reset" /></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </form>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    <p>&nbsp;</p></td>
    <td width="51%" rowspan="8" valign="top" bgcolor="#CC99FF"><form action="show_upgrade_info.php" method="post" name="form1" id="form1">
      <br />
      <input type="submit" name="Submit3" value="VIEW INFO" />
    </form></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC"><span class="style7"><!--- A GROUP OF CANDIDATES  </span></td>
  </tr>
  <tr>
    <td><p><form id="form1" name="form1" method="post" action="insert_individual_upgrade.php" onsubmit="return formCheck2(this)">
      <table width="100%" border="0">
        <tr>
          <td bgcolor="#000000"><span class="style2">TEST MODE </span></td>
        </tr>
        <tr>
          <td><select name="testmode" id="testmode">
              <option selected="selected"></option>
              <option>Quiz</option>
              <option>Exam</option>
              <option>Exam Re-sit</option>
          </select></td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style2">COURSE</span></td>
        </tr>
        <tr>
          <td><input name="course" type="text" id="course" /></td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style2">DATE OF TEST </span></td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><input name="date_taken" type="text" id="date_taken" /></td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style2">DEPARTMENT </span></td>
        </tr>
        <tr>
          <td><select name="department" id="department" tabindex="5">
            <option selected="selected"></option>
            <option>Adult_education</option>
            <option>Accounting</option>
            <option>Architecture</option>
            <option>Banking_and_finance</option>
            <option>Biochemistry</option>
            <option>Biotechnology</option>
            <option>Botany</option>
            <option>Building</option>
            <option>Building_and_quantity_surveying</option>
            <option>Bus_Admin</option>
            <option>Business_education</option>
            <option>Chemical_technology</option>
            <option>civil_engineering</option>
            <option>Computer_science</option>
            <option>Cooperative_economics</option>
            <option>Economics</option>
            <option>Education_english</option>
            <option>Education_igbo</option>
            <option>Electrical_electronics</option>
            <option>Electro_mech</option>
            <option>English</option>
            <option>Environmental_management</option>
            <option>Estate_management</option>
            <option>Geology</option>
            <option>Geology_and_metallurgy</option>
            <option>Geophysics</option>
            <option>Guidance_and_counselling</option>
            <option>HPE</option>
            <option>Health_education</option>
            <option>Industrial_chemistry</option>
            <option>Industrial_physics</option>
            <option>Law</option>
            <option>Lingusitics</option>
            <option>Marketing</option>
            <option>Mass_communication</option>
            <option>Mathematics</option>
            <option>Mechanical_engineering</option>
            <option>Medicine_and_surgery</option>
            <option>Med_lab_Science</option>
            <option>Med_rehabilitation</option>
            <option>Metallurgy_and_mathematics</option>
            <option>Microbiology</option>
            <option>Nursing</option>
            <option>PAE</option>
            <option>Pharmacy</option>
            <option>Physics</option>
            <option>Physics_education</option>
            <option>Physics_electronics</option>
            <option>Political_science</option>
            <option>Production_technology</option>
            <option>Psycology</option>
            <option>Public_administration</option>
            <option>Quantity_surveying</option>
            <option>Radiography</option>
            <option>Science_education</option>
            <option>Sociology</option>
            <option>Statistics</option>
            <option>Survey_geophysics</option>
            <option>Technical_education</option>
            <option>Vocational_education</option>
            <option>Zoology</option>
            <option>Other</option>
          </select></td>
        </tr>
        <tr>
          <td bgcolor="#000000" class="style2">OPERATION MODE </td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><select name="operator" id="operator">
            <option selected></option>
			<option>ADD</option>
            <option>SUBTRACT</option>
          </select>          </td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style2">ADD/SUBTRACT THIS SCORE </span></td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><input name="this_score" type="text" id="this_score" onblur="MM_popupMsg('Please make SURE the details you have entered are correct.\rThis is IRREVERSIBLE.\rYou have been warned!')" /></td>
        </tr>
        <tr>
          <td bgcolor="#000000"><span class="style9">REASON FOR UPGRADE </span></td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><textarea name="reason" cols="30" id="reason"></textarea></td>
        </tr>
        
        <tr>
          <td bgcolor="#000000">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#000000"><input type="submit" name="Submit" value="UPGRADE/DEGRADE" />
              <input type="reset" name="Submit2" value="Reset" /></td> -->
        </tr>
      </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </form>&nbsp;</p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td width="43%">&nbsp;</td>
  </tr>
  <tr>
    <td width="43%">&nbsp;</td>
  </tr>
  <tr>
    <td width="43%">&nbsp;</td>
  </tr>
  <tr>
    <td width="43%">&nbsp;</td>
  </tr>
  <tr>
    <td width="43%">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
  </tr>
</table>
</body>
</html>
