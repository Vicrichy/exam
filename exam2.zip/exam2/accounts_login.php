<?php
$password = $_POST['password'];
if (isset($_POST['password'])) { 
    // form submitted 
    // check for required values 
    if (empty($_POST['password'])) { 
        die ("ERROR: Please enter password!"); 
    } 
    
         
    // open connection 
    include ('dbconnect.php');
	if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
     
    // select database 
    mysql_select_db('datamix');
     
    // create query 
    $query="Select password From finance_password Where password = '$password'";
     
    // execute query 
    $result1 = mysql_query($query) or die ("Error in query: $query. " . mysql_error()); 
     
    // see if any rows were returned 
    if (mysql_num_rows($result1) > 0) { 
        // if a row was returned 
        // authentication was successful 
        // create session and set cookie with username 
        session_start(); 
        $_SESSION['auth'] = 4; 
        setcookie("password", $_POST['password'], time()+(84600*30)); 
        header('Location: accounts_home.php');
    } 
    else { 
        // no result 
        // authentication failed 
       header('Location: access_denied_control.html');
    } 
     
    // free result set memory 
    mysql_free_result($result1); 
     
    // close connection 
    mysql_close($link); 
} 
}
?> 
