<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php
include('dbconnect.php');


// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

?>
<br/>
SYSTEM DATE:
<?php
echo "$system_date";
?>
<br />
<?php
$course = "UMITT";
$test_type = "Quiz";

$query_datex = mysql_query("SELECT test_date FROM candidate_login_table WHERE course = '$course' AND test_type = '$test_type'");
$query_datex1 =mysql_result($query_datex, 0, "test_date");

?>
TEST DATE:
<?php
echo "$query_datex1";
?>
</body>
</html>
