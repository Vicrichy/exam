<?php
session_start();
session_destroy();
header("Location:controlpanel_login_page.php");
?>