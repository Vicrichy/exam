<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Print out ::Page</title>
<style type="text/css">
<!--
.style2 {color: #000000}
.style3 {
	color: #FFFFFF;
	font-weight: bold;
}
.style4 {
	color: #00FF00;
	font-weight: bold;
}
.style5 {color: #FFFFFF}
-->
</style>
</head>

<body bgcolor="#CC99FF">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array( "course_code","course_name","credit_load","course_cost");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array( "COURSE CODE","COURSE NAME","CREDIT LOAD","COURSE COST");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>


<SCRIPT language="JavaScript" type="text/javascript">
function validatePwd(course_code) {

//Initialise variables
var errorMsg = "";
var space  = " ";
fieldname   = course_code; 
fieldvalue  = fieldname.value; 
fieldlength = fieldvalue.length; 
 
//It must not contain a space
if (fieldvalue.indexOf(space) > -1) {
     errorMsg += "\nThere should be no spacing.\n";
}     

//It must start with at least one letter     
if (!(fieldvalue.match(/^[a-zA-Z]+/))) {
     errorMsg += "\nThe course code must start with at least one letter.\n";
}

//If there is aproblem with the form then display an error
     if (errorMsg != ""){
          msg = "______________________________________________________\n\n";
          msg += "An error was detected in the Course code value you specified.\n";
          msg += "______________________________________________________\n";
          errorMsg += alert(msg + errorMsg + "\n\n");
		  //Clear the field if there is a problem
		  fieldname.value = "";
          document.data.cand_emaill_t.focus();
          return false;
     }
     
     return true;
}

</SCRIPT>




<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
	<tr>
		<td bgcolor="#000000" colspan="6">&nbsp;</td>
	</tr>
	<tr>
	  <td width="1%" bgcolor="#000000" rowspan="6">&nbsp;</td>
		<td bgcolor="#000080" colspan="4">
		<p align="center" class="style4"><font size="5">COMPUTER PRINTOUTS</font>		</td>
		<td width="5%" bgcolor="#000000" rowspan="6">&nbsp;</td>
	</tr>
	<tr>
		<td height="19" colspan="4">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="5%" height="160" bgcolor="#000080" valign="top" rowspan="2">&nbsp;</td>
    <td width="1%" bgcolor="#FFFFFF" valign="top" rowspan="2">&nbsp;</td>
		<td height="30" colspan="2" bgcolor="#000066">
		<font color="#000080" face="Arial Black"><b>&nbsp;</b></font></td>
	</tr>
	<tr>
		<td width="2%" height="130" valign="top"><p>&nbsp;</p>
		  <p align="center"><span class="style3"><font size="5">COMPUTER PRINTOUTS</font></span><br>
            <br>
          </p></td>
		<td width="86%" valign="top"><span class="style2">This 
		  enables you to generate formatted reports that could be printed out, and submitted to a third party. These reports are candidates(students) registration records, test results, personal data, which are auto-formatted to remove certain irrelevant or secret data such as students passwords, test duration, etc </span>
          <p class="style2">There are two options: <strong>Registration Records</strong> and <strong>Test Results</strong>. Each of these options has controls that enable you to filter out students data based on their batch number, department, and or course. </p></td>
	</tr>
	<tr>
		
    <td height="117" colspan="4" valign="top" bordercolor="#660000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <table width="100%" border="1">
        <tr>
          <td bgcolor="#000066"><font color="#00FF00"><strong>REGISTRATION RECORDS </strong></font></td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><form name="form1" method="post" action="searchprintout1_all.php">
            <input type="submit" name="Submit3" value="RETRIEVE ALL REGISTRATION RECORDS">
            <br>
            <br>
          </form></td>
        </tr>
        <tr>
          <td bgcolor="#999999"><span class="style5">SEARCH SORTING/FILTERING </span></td>
        </tr>
        <tr>
          <td height="65"><table width="100%" border="0">
            <tr>
              <td width="40%" bgcolor="#FFFFFF"><strong>SORT BY BATCH NO. AND COURSE</strong> </td>
              <td width="1%" bgcolor="#FFFFFF">&nbsp;</td>
              <td width="59%" colspan="2" bgcolor="#FFFFFF"><strong>SORT BY BATCH NO., DEPT AND COURSE</strong></td>
              </tr>
            <tr>
              <td><p>Please specify the necessary details below.</p>
                <form name="form2" method="post" action="searchprintout1_reg.php">
                  <label for="textfield">BATCH NUMBER</label>
                  <select name="batch_no" id="batch_no" tabindex="6">
                    <option selected></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                    <option>24</option>
                    <option>25</option>
                    <option>26</option>
                    <option>27</option>
                    <option>28</option>
                    <option>29</option>
                    <option>30</option>
                    <option>31</option>
                    <option>32</option>
                    <option>33</option>
                    <option>34</option>
                    <option>35</option>
                    <option>36</option>
                    <option>37</option>
                    <option>38</option>
                    <option>39</option>
                    <option>40</option>
                    <option>41</option>
                    <option>42</option>
                    <option>43</option>
                    <option>44</option>
                    <option>45</option>
                    <option>46</option>
                    <option>47</option>
                    <option>48</option>
                    <option>49</option>
                    <option>50</option>
                  </select>
                  <br>
                                <br>
                                <label for="label">COURSE</label>
                                <input name="course" type="text" id="label">
                                <br>
                                <br>
                                <br>
                                <input type="submit" name="Submit" value="SEARCH">
                </form>
                <p>&nbsp; </p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></td>
              <td bgcolor="#FFFFFF">&nbsp;</td>
              <td colspan="2" valign="top"><p>Please specify the necessary details below.</p>
                <form name="form2" method="post" action="searchprintout2_reg.php">
                  <label for="textfield">DEPARTMENT <select name="department" id="department" tabindex="5">
    <?php 
include('dbconnect.php');


$query3 = "SELECT distinct department FROM departments_table order by department";
$result3 = mysql_query($query3);

echo "<option selected></option>";
while ($row = mysql_fetch_array($result3, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{

echo "<option value>";
echo "$value" . "</br>";
echo "</option>";

}}?>

   
  </select><br>
                  <br>
                  BATCH NUMBER</label>
                  <select name="batch_no" id="batch_no" tabindex="6">
                    <option selected></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                    <option>24</option>
                    <option>25</option>
                    <option>26</option>
                    <option>27</option>
                    <option>28</option>
                    <option>29</option>
                    <option>30</option>
                    <option>31</option>
                    <option>32</option>
                    <option>33</option>
                    <option>34</option>
                    <option>35</option>
                    <option>36</option>
                    <option>37</option>
                    <option>38</option>
                    <option>39</option>
                    <option>40</option>
                    <option>41</option>
                    <option>42</option>
                    <option>43</option>
                    <option>44</option>
                    <option>45</option>
                    <option>46</option>
                    <option>47</option>
                    <option>48</option>
                    <option>49</option>
                    <option>50</option>
                  </select>
                  <br>
                  <br>
                  <label for="label2">COURSE</label>
                  <input name="course" type="text" id="label2">
                  <br>
                  <br>
                  <input type="submit" name="Submit2" value="SEARCH">
                </form>                <p>&nbsp; </p></td>
              </tr>
            
            <tr>
              <td colspan="4">&nbsp;</td>
              </tr>
          </table>            </td>
        </tr>
      </table> 
      <table width="100%" border="1">
        <tr>
          <td bgcolor="#000066"><font color="#00FF00"><strong>TEST RESULTS </strong></font></td>
        </tr>
        <tr>
          <td bgcolor="#CC99FF"><form name="form1" method="post" action="searchprintout2_all.php">
            <input type="submit" name="Submit3" value="RETRIEVE ALL TEST RESULTS">
            <br>
            <br>
          </form></td>
        </tr>
        <tr>
          <td bgcolor="#999999"><span class="style5">SEARCH SORTING/FILTERING </span></td>
        </tr>
        <tr>
          <td height="65"><table width="100%" border="0">
            <tr>
              <td width="40%" bgcolor="#FFFFFF"><strong>SORT BY BATCH NO. AND COURSE</strong> </td>
              <td width="1%" bgcolor="#FFFFFF">&nbsp;</td>
              <td width="59%" colspan="2" bgcolor="#FFFFFF"><strong>SORT BY BATCH NO., DEPT AND COURSE</strong></td>
              </tr>
            <tr>
              <td><p>Please specify the necessary details below.</p>
                <form name="form2" method="post" action="searchprintout1_result.php">
                  <label for="textfield">BATCH NUMBER</label>
                  <select name="batch_no" id="batch_no" tabindex="6">
                    <option selected></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                    <option>24</option>
                    <option>25</option>
                    <option>26</option>
                    <option>27</option>
                    <option>28</option>
                    <option>29</option>
                    <option>30</option>
                    <option>31</option>
                    <option>32</option>
                    <option>33</option>
                    <option>34</option>
                    <option>35</option>
                    <option>36</option>
                    <option>37</option>
                    <option>38</option>
                    <option>39</option>
                    <option>40</option>
                    <option>41</option>
                    <option>42</option>
                    <option>43</option>
                    <option>44</option>
                    <option>45</option>
                    <option>46</option>
                    <option>47</option>
                    <option>48</option>
                    <option>49</option>
                    <option>50</option>
                  </select>
                  <br>
                                <br>
                                <label for="label">COURSE</label>
                                <input name="course" type="text" id="label" value="UMITT">
                                <br>
                                <br>
                                <br>
                                <input type="submit" name="Submit" value="SEARCH">
                </form>
                <p>&nbsp; </p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></td>
              <td bgcolor="#FFFFFF">&nbsp;</td>
              <td colspan="2" valign="top"><p>Please specify the necessary details below.</p>
                <form name="form2" method="post" action="searchprintout2_result.php">
                  <label for="textfield">DEPARTMENT <select name="department" id="department" tabindex="5">
    <?php 
include('dbconnect.php');


$query3 = "SELECT distinct department FROM departments_table order by department";
$result3 = mysql_query($query3);

echo "<option selected></option>";
while ($row = mysql_fetch_array($result3, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{

echo "<option value>";
echo "$value" . "</br>";
echo "</option>";

}}?>

   
  </select><br>
                  <br>
                  BATCH NUMBER</label>
                  <select name="batch_no" id="batch_no" tabindex="6">
                    <option selected></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                    <option>24</option>
                    <option>25</option>
                    <option>26</option>
                    <option>27</option>
                    <option>28</option>
                    <option>29</option>
                    <option>30</option>
                    <option>31</option>
                    <option>32</option>
                    <option>33</option>
                    <option>34</option>
                    <option>35</option>
                    <option>36</option>
                    <option>37</option>
                    <option>38</option>
                    <option>39</option>
                    <option>40</option>
                    <option>41</option>
                    <option>42</option>
                    <option>43</option>
                    <option>44</option>
                    <option>45</option>
                    <option>46</option>
                    <option>47</option>
                    <option>48</option>
                    <option>49</option>
                    <option>50</option>
                  </select>
                  <br>
                  <br>
                  <label for="label2">COURSE</label>
                  <input name="course" type="text" id="label2" value="UMITT">
                  <br>
                  <br>
                  <input type="submit" name="Submit2" value="SEARCH">
                </form>                <p>&nbsp; </p></td>
              </tr>
            
            <tr>
              <td colspan="4">&nbsp;</td>
              </tr>
          </table>            </td>
       
	</tr>
	<tr>
	  <td height="29" colspan="4" valign="top" bordercolor="#660000">&nbsp;</td>
  </tr>
	<tr>
		<td bgcolor="#000000" colspan="6">&nbsp;</td>
	</tr>
</table>

</body>

</html>
<?php
}
?>