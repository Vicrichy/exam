<?php
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$computer_time = date("G");

echo "$computer_date_day";
echo "$computer_date_month";
echo "$computer_date_year";
?>
<p>
<?php
echo "$computer_time";
?>
</p>
<P>
<?php
 include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

$query_datex = mysql_query("SELECT test_set_time FROM candidate_login_table WHERE course = 'computer appreciation' AND reg_no = 1001");
$query_datex1 =mysql_result($query_datex, 0, "test_set_time"); 
echo "$query_datex1";
}
?>
</P>