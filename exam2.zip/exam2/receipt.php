<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Pacific Computer Receipt</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Geneva, Arial, Helvetica, sans-serif;
}
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.style2 {
	color: #FFFFFF;
	font-weight: bold;
}
.style3 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style4 {
	font-size: 10px;
	font-weight: bold;
}
.style6 {font-size: 12px}
.style7 {font-size: 10px}
-->
</style></head>

<body onload="window.print();">

<table width="672" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="5" height="31">&nbsp;</td>
    <td colspan="8" align="center" valign="top"><span class="style10 style1 style6">PACIFIC COMPUTER AND MANAGEMENT COLLEGE NIGERIA LIMITED</span></td>
    <td width="79">&nbsp;</td>
  </tr>
  <tr>
    <td height="19"></td>
    <td colspan="8" valign="top"><hr /></td>
    <td></td>
  </tr>
  <tr>
    <td height="117"></td>
    <td width="168" rowspan="3" valign="top"><div align="center">
      <p><img src="logos.JPG" alt="logo" width="121" height="128" /></p>
      <p>&nbsp;</p>
    </div></td>
    <td width="4">&nbsp;</td>
    <td width="80">&nbsp;</td>
    <td width="113">&nbsp;</td>
    <td width="4">&nbsp;</td>
    <td colspan="3" valign="top"><p class="style3">119 Ndidem Usang Iso Road,</p>
      <p class="style3">Calabar, Cross River State</p>
    <p class="style3">087 - 230760 </p>      <p class="style3">&nbsp;</p></td>
    <td></td>
  </tr>
  <tr>
    <td height="24"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="50">&nbsp;</td>
    <td width="165">&nbsp;</td>
    <td width="4">&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="24"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3" valign="top"><span class="style7">NO:</span><span class="style1"><?php echo $_SESSION['code'];?></span></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="19"></td>
    <td colspan="2" valign="top" bgcolor="#000033"><span class="style2">Official Receipt </span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="14"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td valign="top"><span class="style4">Date:</span></td>
    <td colspan="2" rowspan="2" align="center" valign="top"><span class="style1"><?php echo $_SESSION['date'];?></span></td>
    <td></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="19"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="2" valign="top"><hr /></td>
    <td></td>
  </tr>
  <tr>
    <td height="46"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  
  
  
  <tr>
    <td height="19"></td>
    <td rowspan="2" valign="top"><strong>Received From </strong></td>
    <td colspan="8" valign="top"><span class="style1"><?php echo $_SESSION['full_name'];?></span></td>
  </tr>
  <tr>
    <td height="19"></td>
    <td colspan="8" valign="top"><hr /></td>
  </tr>
  <tr>
    <td height="22"></td>
    <td rowspan="2" valign="top"><strong>The Sum Of </strong></td>
    <td colspan="8" valign="top"><span class="style1"><?php echo $_SESSION['amount'];?></span></td>
  </tr>
  <tr>
    <td height="19"></td>
    <td colspan="8" valign="top"><hr /></td>
  </tr>
  <tr>
    <td height="25"></td>
    <td rowspan="2" valign="top"><strong>Being Payment for </strong></td>
    <td colspan="8" valign="top"><span class="style1">Fees Payment for <?php echo $_SESSION['course'];?></span>	</td>
  </tr>
  <tr>
    <td height="19"></td>
    <td colspan="8" valign="top"><hr /></td>
  </tr>
  <tr>
    <td height="27"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
    <td></td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="29"></td>
    <td colspan="3" valign="top">_______________________</td>
    <td>&nbsp;</td>
    <td colspan="3" valign="top">________________________</td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="21"></td>
    <td colspan="3" valign="top"><span class="style7">For Pacific Computers &amp; Mgt. College </span></td>
    <td></td>
    <td colspan="3" valign="top"><span class="style7">Payer's Signature </span></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="21"></td>
    <td colspan="3" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td><form id="form1" name="form1" method="post" action="students_registration_login_page.php">
      <label>
      <input type="submit" name="Submit" value="e-reg" />
      </label>
        </form>
    </td>
    <td colspan="3" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>
