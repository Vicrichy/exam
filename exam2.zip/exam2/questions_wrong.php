<?php

session_start();

echo "These are the questions you failed and the correct answers:
$_SESSION[wrong_1]<br>
$_SESSION[wrong_2]<br>
$_SESSION[wrong_3]<br>
$_SESSION[wrong_4]<br>
$_SESSION[wrong_5]<br>";
?>