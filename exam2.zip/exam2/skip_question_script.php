<?php
$submit=$_POST['skip'];
$number=$_POST['move_number'];


if (isset($_POST['skip'])) {
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

session_start();

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");

$exam_date = date("d/n/Y");


// DETERMINE THE COURSE CODE

$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_coursecode = mysql_result($query_cc, 0, "course_code");


// RETRIEVE THE ANSWERED QUESTION
$queryp =mysql_query("select question from $query_coursecode where id = '$number'");
$question =mysql_result($queryp, 0, "question");

// INSERT TO DATABASE
 $query  = "INSERT INTO answered_questions
              ( exam_date , id , reg_no , course , question , comment )";
			
   $query .= " VALUES
             ( '$exam_date' , '$number' , '$_SESSION[reg_no]' , '$_SESSION[course]' , '$question' , 'SKIPPED' )";
			 
			 $result = mysql_query($query);

header('Location: question.php');
 mysql_close($link);
 }
 }
?>