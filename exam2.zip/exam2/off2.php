<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] == 100 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
?><?php
$max_questions = 5;
include('dbconnect.php');

$query =mysql_query("select count(id) from `user_question` where `username` = 
'$reg_no' and `answered` = 'YES'");
$question_query = @mysql_result($query, 0, "count(id)");
$question_count = $question_query;
$display_no = $question_query + 1;

//$display_no = $_SESSION['display_no'];
if(($display_no) > ($max_questions))
{
 header("location:test_over.php");
}
 
include ('dbconnect.php');

$question_count = 0 ;
// EXTRACT SYSTEM DATE
$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";
$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
// SELECT MAX QUESTION SET FOR THE CANDIDATE
$query_max_questions = 5;
// SELECT MAX TIME SET FOR THE CANDIDATE
$query_max_time = 10;
?>
<html>
<script type="text/javascript">
alert("YOU HAVE 1 HOUR TO ANSWER ALL QUESTIONS");
alert("WARNING: DO NOT CLOSE THIS WINDOW TILL YOU HAVE FINISHED AND SUBMITTED YOUR ANSWERS!!");
</script>
<head>
<script language='javascript'>
//disable right-click
document.oncontextmenu = function(){
window.status = 'Right-click is disabled';
return false;
}

//MSIE6 disable F5 && ctrl+r && ctrl+n
document.onkeydown=function(){
//alert('keycode='+event.keyCode + 'event.ctrlKey='+event.ctrlKey );
switch (event.keyCode) {
case 116 : //F5
event.returnValue=false;
event.keyCode=0;
window.status = 'Refresh is disabled';
return false;
case 78: //n
if (event.ctrlKey) {
event.returnValue=false;
event.keyCode=0;
window.status = 'New window is disabled';
return false;
}
case 82 : //r
if (event.ctrlKey) {
event.returnValue=false;
event.keyCode=0;
window.status = 'Refresh is disabled';
return false;
}
}
}


// diasable back button
window.history.forward(1);
</script> 

<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function Time()
{
 alert("YOUR TIME IS UP!!");
 window.location = "submit.php";
} 
function Times()
{
 alert("YOU HAVE 5 MORE MINUTES");
} 
function Timess()
{
 alert("YOU HAVE 1 MORE MINUTE. ROUND UP YOUR WORK AND CLICK THE SUBMIT BUTTON IN THE NEXT 30 SECONDS!");
} 

</script>
<script type="text/JavaScript">
<!--
setTimeout("Time()",3600000);
setTimeout("Times()",300000);
setTimeout("Timess()",540000);
-->
</script>
<script type="text/javascript">

function Confirm(message,url)
{
 if(confirm(message))location.href = url;
} 
</script>

<script type="text/javascript">
function Confirmation() {
	var answer = confirm("<?php echo "$_SESSION[username]";?>, is this your final answer?")
	if (answer){
		window.location = "pre-submit.php";
	}
	else{
		alert("Please choose another answer!")
	}
}
</script>
<script type="text/javascript">
function saveChanges()
{
var newHtml = document.documentElement.outerHTML;
document.open("text/html","replace");
document.write(newHtml);
document.close();
document.execCommand("saveas", false, "default.htm");
}

//window.onload = saveChanges;
</script>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>E-TEST ENGINE::</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=2.0,Transition=21)">
<base target="rtop">
<style type="text/css">
<!--
.style1 {font-weight: bold;}
.style2 {
	color: #FFFFFF;
	font-weight: bold;
}
body {
	background-color: #000000;
}
-->
input.btn { 
	  color:#050; 
  font: bold 84% 'trebuchet ms',helvetica,sans-serif; 
	  background-color:#fed; 
	  border: 1px solid; 
	  border-color: #696 #363 #363 #696; 
	  filter:progid:DXImageTransform.Microsoft.Gradient 
	  (GradientType=0,StartColorStr='#ffffffff',EndColorStr='#ffeeddaa'); 
	  text-decoration:blink; 
	  cursor:pointer;
	}
input.btnhov { 
border-color: #c63 #930 #930 #c63;	 
}
</style>
<link href="default.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style5 {color: #FFFFFF}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.style6 {
	font-family: "Courier New", Courier, monospace;
	font-weight: bold;
}
.style7 {font-family: "Courier New", Courier, monospace}
body,td,th {
	font-size: 18px;
	color: #FFFFFF;
	font-weight: bold;
}
.style8 {font-size: 12px}
-->
</style>
</head>
<body>

<table width="62%" height="16" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr>
<td width="461" height="12" valign="top" bgcolor="#003333"> 
  <div align="left" class="style2">
    <div align="center">
      <p><font size="4" face="Courier New, Courier, 
mono">Welcome!</font></p>
      <p>&nbsp;</p>
    </div>
  </div></td>
<td width="127" valign="top" bgcolor="#003333"> </td>
</tr>
</table>
<br>
<form method="post" action="submit.php">
<div align="center" class="style6"><font color="#FFFFFF"><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans0');"> QUESTION 1(Click to show question) [+] </span></font></div>
<tr></tr>
<div id="ans0">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr bgcolor="#006600"> 
<td height="19" colspan="3" valign="top" bgcolor="#003333"> 
  <p align="center"></td>
<td colspan="2" valign="top" bgcolor="#003333">&nbsp;
</td>
</tr>
<tr>
<td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
<td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>1</h1>";
?><br> </td>
<td colspan="2" valign="top" bgcolor="#808080"><table>
<tr>
<td width="600"><font size="+2"><b>
<?php

include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '1' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '1' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '1' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer1 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='1' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A1 = $row['A'];
  $B1 = $row['B'];
  $C1 = $row['C'];
  $D1 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A1" type="checkbox" id="A1" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A1;?> <input type="hidden" name="move_number1" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice1" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B1" type="checkbox" id="B1" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B1;?> <input type="hidden" name="move_number1" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice1" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C1" type="checkbox" id="C1" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C1;?> <input type="hidden" name="move_number1" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice1" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D1" type="checkbox" id="D1" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D1;?> <input type="hidden" name="move_number1" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice1" value="D" /> <input type="hidden" name="answer1" value="<?php echo $answer1;?>" /></td>
        </tr>
        <tr>
          <td colspan="4" bgcolor="#003333"><p> <span class="style1">
              <label></label>
          </span></td>
        </tr>
      </table></td>
	</tr>
	<tr>
	  <td height="1"></td>
	  <td></td>
	  <td width="484"></td>
	  <td width="105"></td>
	  <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans1');"> QUESTION 2(Click to show question) [+] </span><br>
  </b></font><br>
</div>
<div id="ans1">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>2</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '2' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '2' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '2' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer2 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='2' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A2 = $row['A'];
  $B2 = $row['B'];
  $C2 = $row['C'];
  $D2 = $row['D'];
}   
?>
          <br>
                 </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="37" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A2" type="checkbox" id="A2" value="A">
        </td>
        <td width="212" bgcolor="#003333" font size="+8"><?php echo $A2?>
          <input type="hidden" name="move_number2" size="20" value='<?php
	echo "2";?>' />
          <input type="hidden" name="choice2" value="A" /></td>
        <td width="48" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B2" type="checkbox" id="B2" value="B">
        </strong></span></td>
        <td width="231" bgcolor="#003333" font size="+8"><?php echo $B2;?> <input type="hidden" name="move_number2" size="20" value='<?php
	echo "2";?>' /> <input type="hidden" name="choice2" value="B" /></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="37" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C2" type="checkbox" id="C2" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C2;?> <input type="hidden" name="move_number24" size="20" value='<?php
	echo "2";?>' /> <input type="hidden" name="choice2" value="C" /></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D2" type="checkbox" id="D2" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D2;?> <input type="hidden" name="move_number2" size="20" value='<?php
	echo "2";?>' /> <input type="hidden" name="choice2" value="D" /> <input name="answer2" type="hidden" id="answer2" value="<?php echo $answer2;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans2');"> QUESTION 3(Click to show question) [+] </span></b></font></div>
<div id="ans2">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>3</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '3' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '3' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '3' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer3 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='3' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A3 = $row['A'];
  $B3 = $row['B'];
  $C3 = $row['C'];
  $D3 = $row['D'];
}   
?>
          <br>

        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="36" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A3" type="checkbox" id="A3" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>' />
  <input type="hidden" name="choice3" value="A" /></td>
        <td width="44" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B3" type="checkbox" id="B3" value="B">
        </strong></span></td>
        <td width="236" bgcolor="#003333" font size="+8"><?php echo $B3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>'>
          <input type="hidden" name="choice3" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="36" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C3" type="checkbox" id="C3" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>'>
          <input type="hidden" name="choice3" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D3" type="checkbox" id="D3" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>'>
          <input type="hidden" name="choice3" value="D"> <input name="answer3" type="hidden" id="answer3" value="<?php echo $answer3;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans3');"> QUESTION 4(Click to show question) [+] </span></b></font></div>
<div id="ans3">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>4</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '4' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '4' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '4' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer4 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='4' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A4 = $row['A'];
  $B4 = $row['B'];
  $C4 = $row['C'];
  $D4 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A4" type="checkbox" id="A4" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A4;?> <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B4" type="checkbox" id="B4" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B4;?>  <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C4" type="checkbox" id="C4" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C4;?> <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D4" type="checkbox" id="D4" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D4;?> <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="D"> <input name="answer4" type="hidden" id="answer4" value="<?php echo $answer4;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans4');"> QUESTION 5(Click to show question) [+] </span></b></font></div>
<div id="ans4">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>5</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '5' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '5' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '5' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer5 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='5' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A5 = $row['A'];
  $B5 = $row['B'];
  $C5 = $row['C'];
  $D5 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="39" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A5" type="checkbox" id="A5" value="A">
        </td>
        <td width="213" bgcolor="#003333" font size="+8"><?php echo $A5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="A"></td>
        <td width="47" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B5" type="checkbox" id="B5" value="B">
        </strong></span></td>
        <td width="233" bgcolor="#003333" font size="+8"><?php echo $B5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="39" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C5" type="checkbox" id="C5" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D5" type="checkbox" id="D5" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="D"> <input name="answer5" type="hidden" id="answer5" value="<?php echo $answer5;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans5');"> QUESTION 6(Click to show question) [+] </span></b></font></div>
  <div id="ans5">
    <table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
      <!--DWLayoutTable-->
      <tr>
        <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
        <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>6</h1>";
?>
            <br>
        </td>
        <td colspan="2" valign="top" bgcolor="#808080"><table>
            <tr>
              <td width="600"><font size="+2"><b>
                <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '6' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '6' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '6' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer6 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='6' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A6 = $row['A'];
  $B6 = $row['B'];
  $C6 = $row['C'];
  $D6 = $row['D'];
}   
?>
                <br>
              </b></font></td>
            </tr>
          </table>
            <p>&nbsp;</p></td>
        <td width="27" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
            <tr>
              <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
                  <label><strong>A</strong></label>
                  </span>
                  <input name="A6" type="checkbox" id="A6" value="A">
              </td>
              <td width="216" bgcolor="#003333" font size="+8"><?php echo $A6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="A"></td>
              <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B
                    <input name="B6" type="checkbox" id="B6" value="B">
              </strong></span></td>
              <td width="238" bgcolor="#003333" font size="+8"><?php echo $B6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="B"></td>
            </tr>
            <tr>
              <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
            </tr>
            <tr>
              <td width="41" bgcolor="#003333"><span class="style5">
                <label><strong>C</strong></label>
                <input name="C6" type="checkbox" id="C6" value="C">
              </span></td>
              <td bgcolor="#003333"><?php echo $C6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="C"></td>
              <td bgcolor="#003333"><span class="style5"><strong>D
                    <input name="D6" type="checkbox" id="D6" value="D">
              </strong></span></td>
              <td bgcolor="#003333"><?php echo $D6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="D">
                  <input name="answer6" type="hidden" id="answer6" value="<?php echo $answer6;?>" /></td>
            </tr>
            <tr>
              <td colspan="4" bgcolor="#003333"><p> <span class="style1">
                  <label></label>
              </span> &nbsp;&nbsp;</td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="1"></td>
        <td></td>
        <td width="484"></td>
        <td width="105"></td>
        <td></td>
      </tr>
    </table>
  </div>
  <div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans6');"> QUESTION 7(Click to show question) [+] </span></b></font></div>
<div id="ans6">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>7</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '7' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '7' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '7' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer7 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='7' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A7 = $row['A'];
  $B7 = $row['B'];
  $C7 = $row['C'];
  $D7 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A7" type="checkbox" id="A7" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A7;?> <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B7" type="checkbox" id="B7" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B7;?>  <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C7" type="checkbox" id="C7" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C7;?> <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D7" type="checkbox" id="D7" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D7;?> <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="D"> 
          <input name="answer7" type="hidden" id="answer7" value="<?php echo $answer7;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans7');"> QUESTION 8(Click to show question) [+] </span></b></font></div>
<div id="ans7">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>8</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '8' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '8' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '8' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer8 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='8' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A8 = $row['A'];
  $B8 = $row['B'];
  $C8 = $row['C'];
  $D8 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A8" type="checkbox" id="A8" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A8;?> <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "8";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B8" type="checkbox" id="B8" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B8;?>  <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "8";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C8" type="checkbox" id="C8" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C8;?> <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "8";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <strong>
              <input name="D8" type="checkbox" id="D8" value="D">
              </strong> </strong></span></td>
        <td bgcolor="#003333"><?php echo $D8;?> <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "8";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="D"> 
          <input name="answer8" type="hidden" id="answer8" value="<?php echo $answer8;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans8');"> QUESTION 9(Click to show question) [+] </span></b></font></div>
<div id="ans8">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>9</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '9' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '9' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '9' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer9 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='9' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A9 = $row['A'];
  $B9 = $row['B'];
  $C9 = $row['C'];
  $D9 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A9" type="checkbox" id="A9" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A9;?> <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B9" type="checkbox" id="B9" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B9;?>  <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C9" type="checkbox" id="C9" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C9;?> <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D9" type="checkbox" id="D9" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D9;?> <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="D"> 
          <input name="answer9" type="hidden" id="answer9" value="<?php echo $answer9;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans9');"> QUESTION 10(Click to show question) [+] </span></b></font></div>
<div id="ans9">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>10</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '10' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '10' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '10' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer10 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='10' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A10 = $row['A'];
  $B10 = $row['B'];
  $C10 = $row['C'];
  $D10 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A10" type="checkbox" id="A10" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A10;?> <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B10" type="checkbox" id="B10" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B10;?>  <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C10" type="checkbox" id="C10" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C10;?> <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D10" type="checkbox" id="D10" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D10;?> <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="D"> 
          <input name="answer10" type="hidden" id="answer10" value="<?php echo $answer10;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;
        <input name="reg_no" type="hidden" id="reg_no" value='<?php
	echo $_SESSION['reg_no'];?>' size="20">
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style6"><font color="#FFFFFF"><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans10');"> QUESTION 11(Click to show question) [+] </span></font></div>
<tr></tr>
<div id="ans10">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr bgcolor="#006600"> 
<td height="19" colspan="3" valign="top" bgcolor="#003333"> 
  <p align="center"></td>
<td colspan="2" valign="top" bgcolor="#003333">&nbsp;
</td>
</tr>
<tr>
<td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
<td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>11</h1>";
?><br> </td>
<td colspan="2" valign="top" bgcolor="#808080"><table>
<tr>
<td width="600"><font size="+2"><b>
<?php

include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '11' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '11' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '11' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer11 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='11' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A11 = $row['A'];
  $B11 = $row['B'];
  $C11 = $row['C'];
  $D11 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A11" type="checkbox" id="A11" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A11;?> <input type="hidden" name="move_number11" size="20" value='<?php
	echo "11";?>' /> <input type="hidden" name="choice11" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B11" type="checkbox" id="B11" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B11;?> <input type="hidden" name="move_number11" size="20" value='<?php
	echo "11";?>' /> <input type="hidden" name="choice11" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C11" type="checkbox" id="C11" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C11;?> <input type="hidden" name="move_number11" size="20" value='<?php
	echo "11";?>' /> <input type="hidden" name="choice11" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D11" type="checkbox" id="D11" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D11;?> <input type="hidden" name="move_number11" size="20" value='<?php
	echo "11";?>' /> <input type="hidden" name="choice11" value="D" /> <input type="hidden" name="answer11" value="<?php echo $answer11;?>" /></td>
        </tr>
        <tr>
          <td colspan="4" bgcolor="#003333"><p> <span class="style1">
              <label></label>
          </span></td>
        </tr>
      </table></td>
	</tr>
	<tr>
	  <td height="1"></td>
	  <td></td>
	  <td width="484"></td>
	  <td width="105"></td>
	  <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans11');"> QUESTION 12(Click to show question) [+] </span><br>
  </b></font><br>
</div>
<div id="ans11">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>12</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php

include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '12' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '12' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '12' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer12 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='12' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A12 = $row['A'];
  $B12 = $row['B'];
  $C12 = $row['C'];
  $D12 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A12" type="checkbox" id="A12" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A12;?> <input type="hidden" name="move_number12" size="20" value='<?php
	echo "12";?>' /> <input type="hidden" name="choice12" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B12" type="checkbox" id="B12" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B12;?> <input type="hidden" name="move_number12" size="20" value='<?php
	echo "12";?>' /> <input type="hidden" name="choice12" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C12" type="checkbox" id="C12" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C12;?> <input type="hidden" name="move_number12" size="20" value='<?php
	echo "12";?>' /> <input type="hidden" name="choice12" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D12" type="checkbox" id="D12" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D12;?> <input type="hidden" name="move_number12" size="20" value='<?php
	echo "12";?>' /> <input type="hidden" name="choice12" value="D" /> <input type="hidden" name="answer12" value="<?php echo $answer12;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans12');"> QUESTION 13(Click to show question) [+] </span></b></font></div>
<div id="ans12">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>13</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '13' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '13' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '13' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer13 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='13' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A13 = $row['A'];
  $B13 = $row['B'];
  $C13 = $row['C'];
  $D13 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A13" type="checkbox" id="A13" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A13;?> <input type="hidden" name="move_number13" size="20" value='<?php
	echo "13";?>' /> <input type="hidden" name="choice13" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B13" type="checkbox" id="B13" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B13;?> <input type="hidden" name="move_number13" size="20" value='<?php
	echo "13";?>' /> <input type="hidden" name="choice13" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C13" type="checkbox" id="C13" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C13;?> <input type="hidden" name="move_number13" size="20" value='<?php
	echo "13";?>' /> <input type="hidden" name="choice13" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D13" type="checkbox" id="D13" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D13;?> <input type="hidden" name="move_number13" size="20" value='<?php
	echo "13";?>' /> <input type="hidden" name="choice13" value="D" /> <input type="hidden" name="answer13" value="<?php echo $answer13;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans13');"> QUESTION 14(Click to show question) [+] </span></b></font></div>
<div id="ans13">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>14</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '14' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '14' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '14' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer14 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='14' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A14 = $row['A'];
  $B14 = $row['B'];
  $C14 = $row['C'];
  $D14 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A14" type="checkbox" id="A14" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A14;?> <input type="hidden" name="move_number14" size="20" value='<?php
	echo "14";?>' /> <input type="hidden" name="choice14" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B14" type="checkbox" id="B14" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B14;?> <input type="hidden" name="move_number14" size="20" value='<?php
	echo "14";?>' /> <input type="hidden" name="choice7" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C14" type="checkbox" id="C14" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C14;?> <input type="hidden" name="move_number14" size="20" value='<?php
	echo "14";?>' /> <input type="hidden" name="choice14" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D14" type="checkbox" id="D14" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D14;?> <input type="hidden" name="move_number14" size="20" value='<?php
	echo "14";?>' /> <input type="hidden" name="choice14" value="D" /> <input type="hidden" name="answer14" value="<?php echo $answer14;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans14');"> QUESTION 15(Click to show question) [+] </span></b></font></div>
<div id="ans14">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>15</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '15' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '15' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '15' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer15 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='15' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A15 = $row['A'];
  $B15 = $row['B'];
  $C15 = $row['C'];
  $D15 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A15" type="checkbox" id="A15" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A15;?> <input type="hidden" name="move_number15" size="20" value='<?php
	echo "15";?>' /> <input type="hidden" name="choice15" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B15" type="checkbox" id="B15" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B15;?> <input type="hidden" name="move_number15" size="20" value='<?php
	echo "15";?>' /> <input type="hidden" name="choice7" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C15" type="checkbox" id="C15" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C15;?> <input type="hidden" name="move_number15" size="20" value='<?php
	echo "15";?>' /> <input type="hidden" name="choice15" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D15" type="checkbox" id="D15" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D15;?> <input type="hidden" name="move_number15" size="20" value='<?php
	echo "15";?>' /> <input type="hidden" name="choice15" value="D" /> <input type="hidden" name="answer15" value="<?php echo $answer15;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans15');"> QUESTION 16(Click to show question) [+] </span></b></font></div>
  <div id="ans15">
    <table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
      <!--DWLayoutTable-->
      <tr>
        <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
        <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>16</h1>";
?>
            <br>
        </td>
        <td colspan="2" valign="top" bgcolor="#808080"><table>
            <tr>
              <td width="600"><font size="+2"><b>
                <?php
include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '16' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '16' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '16' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer16 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='16' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A16 = $row['A'];
  $B16 = $row['B'];
  $C16 = $row['C'];
  $D16 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A16" type="checkbox" id="A16" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A16;?> <input type="hidden" name="move_number16" size="20" value='<?php
	echo "16";?>' /> <input type="hidden" name="choice16" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B16" type="checkbox" id="B16" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B16;?> <input type="hidden" name="move_number16" size="20" value='<?php
	echo "16";?>' /> <input type="hidden" name="choice7" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C16" type="checkbox" id="C16" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C16;?> <input type="hidden" name="move_number16" size="20" value='<?php
	echo "16";?>' /> <input type="hidden" name="choice16" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D16" type="checkbox" id="D16" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D16;?> <input type="hidden" name="move_number16" size="20" value='<?php
	echo "16";?>' /> <input type="hidden" name="choice16" value="D" /> <input type="hidden" name="answer16" value="<?php echo $answer16;?>" /></td>
            </tr>
            <tr>
              <td colspan="4" bgcolor="#003333"><p> <span class="style1">
                  <label></label>
              </span> &nbsp;&nbsp;</td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="1"></td>
        <td></td>
        <td width="484"></td>
        <td width="105"></td>
        <td></td>
      </tr>
    </table>
  </div>
  <div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans16');"> QUESTION 17(Click to show question) [+] </span></b></font></div>
<div id="ans16">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>17</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '17' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '17' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '17' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer17 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='17' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A17 = $row['A'];
  $B17 = $row['B'];
  $C17 = $row['C'];
  $D17 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A17" type="checkbox" id="A17" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A17;?> <input type="hidden" name="move_number17" size="20" value='<?php
	echo "17";?>' /> <input type="hidden" name="choice17" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B17" type="checkbox" id="B17" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B17;?> <input type="hidden" name="move_number17" size="20" value='<?php
	echo "17";?>' /> <input type="hidden" name="choice7" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C17" type="checkbox" id="C17" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C17;?> <input type="hidden" name="move_number17" size="20" value='<?php
	echo "17";?>' /> <input type="hidden" name="choice17" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D17" type="checkbox" id="D17" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D17;?> <input type="hidden" name="move_number17" size="20" value='<?php
	echo "17";?>' /> <input type="hidden" name="choice17" value="D" /> <input type="hidden" name="answer17" value="<?php echo $answer17;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans17');"> QUESTION 18(Click to show question) [+] </span></b></font></div>
<div id="ans17">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>18</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '18' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '18' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '18' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer18 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='18' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A18 = $row['A'];
  $B18 = $row['B'];
  $C18 = $row['C'];
  $D18 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A18" type="checkbox" id="A18" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A18;?> <input type="hidden" name="move_number18" size="20" value='<?php
	echo "18";?>' /> <input type="hidden" name="choice18" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B18" type="checkbox" id="B18" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B18;?> <input type="hidden" name="move_number18" size="20" value='<?php
	echo "18";?>' /> <input type="hidden" name="choice7" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C18" type="checkbox" id="C18" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C18;?> <input type="hidden" name="move_number18" size="20" value='<?php
	echo "18";?>' /> <input type="hidden" name="choice18" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D18" type="checkbox" id="D18" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D18;?> <input type="hidden" name="move_number18" size="20" value='<?php
	echo "18";?>' /> <input type="hidden" name="choice18" value="D" /> <input type="hidden" name="answer18" value="<?php echo $answer18;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans18');"> QUESTION 19(Click to show question) [+] </span></b></font></div>
<div id="ans18">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>19</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '19' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '19' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '19' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer19 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='19' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A19 = $row['A'];
  $B19 = $row['B'];
  $C19 = $row['C'];
  $D19 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A19" type="checkbox" id="A19" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A19;?> <input name="move_number19" type="hidden" id="move_number19" value='<?php
	echo "19";?>' size="20">
          <input name="choice19" type="hidden" id="choice19" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B19" type="checkbox" id="B19" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B19;?>  <input name="move_number19" type="hidden" id="move_number19" value='<?php
	echo "19";?>' size="20">
          <input name="choice19" type="hidden" id="choice19" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C19" type="checkbox" id="C19" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C19;?> <input name="move_number19" type="hidden" id="move_number19" value='<?php
	echo "19";?>' size="20">
          <input name="choice19" type="hidden" id="choice19" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D19" type="checkbox" id="D19" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D19;?> <input name="move_number19" type="hidden" id="move_number19" value='<?php
	echo "19";?>' size="20">
          <input name="choice19" type="hidden" id="choice19" value="D"> 
          <input name="answer19" type="hidden" id="answer19" value="<?php echo $answer9;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans19');"> QUESTION 20(Click to show question) [+] </span></b></font></div>
<div id="ans19">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>20</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '20' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '20' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '20' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer20 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='20' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A20 = $row['A'];
  $B20 = $row['B'];
  $C20 = $row['C'];
  $D20 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A20" type="checkbox" id="A20" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A20;?> <input name="move_number20" type="hidden" id="move_number20" value='<?php
	echo "10";?>' size="20">
          <input name="choice20" type="hidden" id="choice20" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B20" type="checkbox" id="B20" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B20;?>  <input name="move_number20" type="hidden" id="move_number20" value='<?php
	echo "20";?>' size="20">
          <input name="choice20" type="hidden" id="choice20" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C20" type="checkbox" id="C20" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C20;?> <input name="move_number20" type="hidden" id="move_number20" value='<?php
	echo "20";?>' size="20">
          <input name="choice20" type="hidden" id="choice20" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D20" type="checkbox" id="D20" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D20;?> <input name="move_number20" type="hidden" id="move_number20" value='<?php
	echo "20";?>' size="20">
          <input name="choice20" type="hidden" id="choice20" value="D"> 
          <input name="answer20" type="hidden" id="answer20" value="<?php echo $answer20;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;
        <input name="reg_no" type="hidden" id="reg_no" value='<?php
	echo $_SESSION['reg_no'];?>' size="20">
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style6"><font color="#FFFFFF"><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans20');"> QUESTION 21(Click to show question) [+] </span></font></div>
<tr></tr>
<div id="ans20">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr bgcolor="#006600"> 
<td height="19" colspan="3" valign="top" bgcolor="#003333"> 
  <p align="center"></td>
<td colspan="2" valign="top" bgcolor="#003333">&nbsp;
</td>
</tr>
<tr>
<td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
<td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>21</h1>";
?><br> </td>
<td colspan="2" valign="top" bgcolor="#808080"><table>
<tr>
<td width="600"><font size="+2"><b>
<?php

include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '21' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '21' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '21' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer21 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='21' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A21 = $row['A'];
  $B21 = $row['B'];
  $C21 = $row['C'];
  $D21 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A21" type="checkbox" id="A21" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A21;?> <input type="hidden" name="move_number21" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice21" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B21" type="checkbox" id="B21" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B21;?> <input type="hidden" name="move_number21" size="20" value='<?php
	echo "21";?>' /> <input type="hidden" name="choice21" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C21" type="checkbox" id="C21" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C21;?> <input type="hidden" name="move_number21" size="20" value='<?php
	echo "21";?>' /> <input type="hidden" name="choice21" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D21" type="checkbox" id="D21" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D21;?> <input type="hidden" name="move_number21" size="20" value='<?php
	echo "21";?>' /> <input type="hidden" name="choice21" value="D" /> <input type="hidden" name="answer21" value="<?php echo $answer21;?>" /></td>
        </tr>
        <tr>
          <td colspan="4" bgcolor="#003333"><p> <span class="style1">
              <label></label>
          </span></td>
        </tr>
      </table></td>
	</tr>
	<tr>
	  <td height="1"></td>
	  <td></td>
	  <td width="484"></td>
	  <td width="105"></td>
	  <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans21');"> QUESTION 22(Click to show question) [+] </span><br>
  </b></font><br>
</div>
<div id="ans21">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>22</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '22' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '22' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '22' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer22 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='22' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A22 = $row['A'];
  $B22 = $row['B'];
  $C22 = $row['C'];
  $D22 = $row['D'];
}   
?>
          <br>
                 </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="37" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A22" type="checkbox" id="A22" value="A">
        </td>
        <td width="212" bgcolor="#003333" font size="+8"><?php echo $A22?>
          <input type="hidden" name="move_number22" size="20" value='<?php
	echo "22";?>' />
          <input type="hidden" name="choice22" value="A" /></td>
        <td width="48" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B22" type="checkbox" id="B22" value="B">
        </strong></span></td>
        <td width="231" bgcolor="#003333" font size="+8"><?php echo $B22;?> <input type="hidden" name="move_number22" size="20" value='<?php
	echo "22";?>' /> <input type="hidden" name="choice22" value="B" /></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="37" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C22" type="checkbox" id="C22" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C22;?> <input type="hidden" name="move_number22" size="20" value='<?php
	echo "22";?>' /> <input type="hidden" name="choice22" value="C" /></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D22" type="checkbox" id="D22" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D22;?> <input type="hidden" name="move_number22" size="20" value='<?php
	echo "22";?>' /> <input type="hidden" name="choice22" value="D" /> <input name="answer22" type="hidden" id="answer2" value="<?php echo $answer22;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans22');"> QUESTION 23(Click to show question) [+] </span></b></font></div>
<div id="ans22">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>23</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '23' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '23' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '23' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer23 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='23' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A23 = $row['A'];
  $B23 = $row['B'];
  $C23 = $row['C'];
  $D23 = $row['D'];
}   
?>
          <br>

        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="36" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A23" type="checkbox" id="A23" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A23;?> <input type="hidden" name="move_number23" size="20" value='<?php
	echo "23";?>' />
  <input type="hidden" name="choice23" value="A" /></td>
        <td width="44" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B23" type="checkbox" id="B23" value="B">
        </strong></span></td>
        <td width="236" bgcolor="#003333" font size="+8"><?php echo $B23;?> <input type="hidden" name="move_number23" size="20" value='<?php
	echo "23";?>'>
          <input type="hidden" name="choice23" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="36" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C23" type="checkbox" id="C23" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C23;?> <input type="hidden" name="move_number23" size="20" value='<?php
	echo "23";?>'>
          <input type="hidden" name="choice23" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D23" type="checkbox" id="D23" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D23;?> <input type="hidden" name="move_number23" size="20" value='<?php
	echo "23";?>'>
          <input type="hidden" name="choice23" value="D"> <input name="answer23" type="hidden" id="answer23" value="<?php echo $answer23;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans23');"> QUESTION 24(Click to show question) [+] </span></b></font></div>
<div id="ans23">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>24</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '24' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '24' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '24' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer24 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='24' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A24 = $row['A'];
  $B24 = $row['B'];
  $C24 = $row['C'];
  $D24 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A24" type="checkbox" id="A24" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A24;?> <input type="hidden" name="move_number4" size="20" value='<?php
	echo "24";?>'>
          <input type="hidden" name="choice24" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B24" type="checkbox" id="B24" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B24;?>  <input type="hidden" name="move_number24" size="20" value='<?php
	echo "24";?>'>
          <input type="hidden" name="choice24" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C24" type="checkbox" id="C24" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C24;?> <input type="hidden" name="move_number24" size="20" value='<?php
	echo "24";?>'>
          <input type="hidden" name="choice24" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D24" type="checkbox" id="D24" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D24;?> <input type="hidden" name="move_number24" size="20" value='<?php
	echo "24";?>'>
          <input type="hidden" name="choice24" value="D"> <input name="answer24" type="hidden" id="answer24" value="<?php echo $answer24;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans24');"> QUESTION 25(Click to show question) [+] </span></b></font></div>
<div id="ans24">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>25</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '25' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '25' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '25' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer25 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='25' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A25 = $row['A'];
  $B25 = $row['B'];
  $C25 = $row['C'];
  $D25 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="39" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A25" type="checkbox" id="A25" value="A">
        </td>
        <td width="213" bgcolor="#003333" font size="+8"><?php echo $A25;?> <input type="hidden" name="move_number25" size="20" value='<?php
	echo "25";?>'>
          <input type="hidden" name="choice25" value="A"></td>
        <td width="47" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B25" type="checkbox" id="B25" value="B">
        </strong></span></td>
        <td width="233" bgcolor="#003333" font size="+8"><?php echo $B25;?> <input type="hidden" name="move_number25" size="20" value='<?php
	echo "25";?>'>
          <input type="hidden" name="choice25" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="39" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C25" type="checkbox" id="C25" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C25;?> <input type="hidden" name="move_number25" size="20" value='<?php
	echo "25";?>'>
          <input type="hidden" name="choice25" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D25" type="checkbox" id="D25" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D25;?> <input type="hidden" name="move_number25" size="20" value='<?php
	echo "25";?>'>
          <input type="hidden" name="choice25" value="D"> <input name="answer25" type="hidden" id="answer25" value="<?php echo $answer25;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans25');"> QUESTION 26(Click to show question) [+] </span></b></font></div>
  <div id="ans25">
    <table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
      <!--DWLayoutTable-->
      <tr>
        <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
        <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>26</h1>";
?>
            <br>
        </td>
        <td colspan="2" valign="top" bgcolor="#808080"><table>
            <tr>
              <td width="600"><font size="+2"><b>
                <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '26' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '26' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '26' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer26 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='26' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A26 = $row['A'];
  $B26 = $row['B'];
  $C26 = $row['C'];
  $D26 = $row['D'];
}   
?>
                <br>
              </b></font></td>
            </tr>
          </table>
            <p>&nbsp;</p></td>
        <td width="27" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
            <tr>
              <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
                  <label><strong>A</strong></label>
                  </span>
                  <input name="A26" type="checkbox" id="A26" value="A">
              </td>
              <td width="216" bgcolor="#003333" font size="+8"><?php echo $A26;?>
                  <input type="hidden" name="move_number26" size="20" value='<?php
	echo "26";?>'>
                  <input type="hidden" name="choice26" value="A"></td>
              <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B
                    <input name="B26" type="checkbox" id="B26" value="B">
              </strong></span></td>
              <td width="238" bgcolor="#003333" font size="+8"><?php echo $B26;?>
                  <input type="hidden" name="move_number26" size="20" value='<?php
	echo "26";?>'>
                  <input type="hidden" name="choice6" value="B"></td>
            </tr>
            <tr>
              <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
            </tr>
            <tr>
              <td width="41" bgcolor="#003333"><span class="style5">
                <label><strong>C</strong></label>
                <input name="C26" type="checkbox" id="C26" value="C">
              </span></td>
              <td bgcolor="#003333"><?php echo $C26;?>
                  <input type="hidden" name="move_number26" size="20" value='<?php
	echo "26";?>'>
                  <input type="hidden" name="choice26" value="C"></td>
              <td bgcolor="#003333"><span class="style5"><strong>D
                    <input name="D26" type="checkbox" id="D26" value="D">
              </strong></span></td>
              <td bgcolor="#003333"><?php echo $D26;?>
                  <input type="hidden" name="move_number26" size="20" value='<?php
	echo "26";?>'>
                  <input type="hidden" name="choice26" value="D">
                  <input name="answer26" type="hidden" id="answer26" value="<?php echo $answer26;?>" /></td>
            </tr>
            <tr>
              <td colspan="4" bgcolor="#003333"><p> <span class="style1">
                  <label></label>
              </span> &nbsp;&nbsp;</td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="1"></td>
        <td></td>
        <td width="484"></td>
        <td width="105"></td>
        <td></td>
      </tr>
    </table>
  </div>
  <div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans26');"> QUESTION 27(Click to show question) [+] </span></b></font></div>
<div id="ans26">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>27</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '27' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '27' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '27' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer27 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='27' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A27 = $row['A'];
  $B27 = $row['B'];
  $C27 = $row['C'];
  $D27 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A27" type="checkbox" id="A27" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A27;?> <input name="move_number27" type="hidden" id="move_number27" value='<?php
	echo "27";?>' size="20">
          <input name="choice27" type="hidden" id="choice27" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B27" type="checkbox" id="B27" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B27;?>  <input name="move_number27" type="hidden" id="move_number27" value='<?php
	echo "27";?>' size="20">
          <input name="choice27" type="hidden" id="choice27" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C27" type="checkbox" id="C27" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C27;?> <input name="move_number27" type="hidden" id="move_number27" value='<?php
	echo "27";?>' size="20">
          <input name="choice27" type="hidden" id="choice27" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D27" type="checkbox" id="D27" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D27;?> <input name="move_number27" type="hidden" id="move_number27" value='<?php
	echo "27";?>' size="20">
          <input name="choice27" type="hidden" id="choice27" value="D"> 
          <input name="answer27" type="hidden" id="answer27" value="<?php echo $answer27;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans27');"> QUESTION 28(Click to show question) [+] </span></b></font></div>
<div id="ans27">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>28</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '28' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '28' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '28' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer28 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='28' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A28 = $row['A'];
  $B28 = $row['B'];
  $C28 = $row['C'];
  $D28 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A28" type="checkbox" id="A28" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A28;?> <input name="move_number28" type="hidden" id="move_number28" value='<?php
	echo "28";?>' size="20">
          <input name="choice28" type="hidden" id="choice28" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B28" type="checkbox" id="B28" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B28;?>  <input name="move_number28" type="hidden" id="move_number28" value='<?php
	echo "28";?>' size="20">
          <input name="choice28" type="hidden" id="choice28" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C28" type="checkbox" id="C28" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C28;?> <input name="move_number28" type="hidden" id="move_number28" value='<?php
	echo "28";?>' size="20">
          <input name="choice28" type="hidden" id="choice28" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <strong>
              <input name="D28" type="checkbox" id="D28" value="D">
              </strong> </strong></span></td>
        <td bgcolor="#003333"><?php echo $D28;?> <input name="move_number28" type="hidden" id="move_number28" value='<?php
	echo "28";?>' size="20">
          <input name="choice28" type="hidden" id="choice28" value="D"> 
          <input name="answer28" type="hidden" id="answer28" value="<?php echo $answer28;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans28');"> QUESTION 29(Click to show question) [+] </span></b></font></div>
<div id="ans28">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>29</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '29' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '29' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '29' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer29 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='29' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A29 = $row['A'];
  $B29 = $row['B'];
  $C29 = $row['C'];
  $D29 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A29" type="checkbox" id="A29" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A29;?> <input name="move_number29" type="hidden" id="move_number29" value='<?php
	echo "29";?>' size="20">
          <input name="choice29" type="hidden" id="choice29" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B29" type="checkbox" id="B29" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B29;?>  <input name="move_number29" type="hidden" id="move_number29" value='<?php
	echo "29";?>' size="20">
          <input name="choice29" type="hidden" id="choice29" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C29" type="checkbox" id="C29" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C29;?> <input name="move_number29" type="hidden" id="move_number29" value='<?php
	echo "29";?>' size="20">
          <input name="choice29" type="hidden" id="choice29" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D29" type="checkbox" id="D29" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D29;?> <input name="move_number29" type="hidden" id="move_number29" value='<?php
	echo "29";?>' size="20">
          <input name="choice29" type="hidden" id="choice29" value="D"> 
          <input name="answer29" type="hidden" id="answer29" value="<?php echo $answer29;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans29');"> QUESTION 30(Click to show question) [+] </span></b></font></div>
<div id="ans29">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>30</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '30' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '30' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '30' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer30 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='30' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A30 = $row['A'];
  $B30 = $row['B'];
  $C30 = $row['C'];
  $D30 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A30" type="checkbox" id="A30" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A30;?> <input name="move_number30" type="hidden" id="move_number30" value='<?php
	echo "30";?>' size="20">
          <input name="choice30" type="hidden" id="choice30" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B30" type="checkbox" id="B30" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B30;?>  <input name="move_number30" type="hidden" id="move_number30" value='<?php
	echo "30";?>' size="20">
          <input name="choice30" type="hidden" id="choice30" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C30" type="checkbox" id="C30" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C30;?> <input name="move_number30" type="hidden" id="move_number30" value='<?php
	echo "30";?>' size="20">
          <input name="choice30" type="hidden" id="choice30" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D30" type="checkbox" id="D30" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D30;?> <input name="move_number30" type="hidden" id="move_number30" value='<?php
	echo "30";?>' size="20">
          <input name="choice30" type="hidden" id="choice30" value="D"> 
          <input name="answer30" type="hidden" id="answer30" value="<?php echo $answer30;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;
        <input name="reg_no" type="hidden" id="reg_no" value='<?php
	echo $_SESSION['reg_no'];?>' size="20">
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style6"><font color="#FFFFFF"><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans30');"> QUESTION 31(Click to show question) [+] </span></font></div>
<tr></tr>
<div id="ans30">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr bgcolor="#006600"> 
<td height="19" colspan="3" valign="top" bgcolor="#003333"> 
  <p align="center"></td>
<td colspan="2" valign="top" bgcolor="#003333">&nbsp;
</td>
</tr>
<tr>
<td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
<td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>31</h1>";
?><br> </td>
<td colspan="2" valign="top" bgcolor="#808080"><table>
<tr>
<td width="600"><font size="+2"><b>
<?php

include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '31' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '31' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '31' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer31 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='31' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A31 = $row['A'];
  $B31 = $row['B'];
  $C31 = $row['C'];
  $D31 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A31" type="checkbox" id="A31" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A31;?> <input type="hidden" name="move_number31" size="20" value='<?php
	echo "31";?>' /> <input type="hidden" name="choice31" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B31" type="checkbox" id="B31" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B31;?> <input type="hidden" name="move_number31" size="20" value='<?php
	echo "31";?>' /> <input type="hidden" name="choice31" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C31" type="checkbox" id="C31" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C31;?> <input type="hidden" name="move_number31" size="20" value='<?php
	echo "31";?>' /> <input type="hidden" name="choice31" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D31" type="checkbox" id="D31" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D31;?> <input type="hidden" name="move_number31" size="20" value='<?php
	echo "31";?>' /> <input type="hidden" name="choice31" value="D" /> <input type="hidden" name="answer31" value="<?php echo $answer31;?>" /></td>
        </tr>
        <tr>
          <td colspan="4" bgcolor="#003333"><p> <span class="style1">
              <label></label>
          </span></td>
        </tr>
      </table></td>
	</tr>
	<tr>
	  <td height="1"></td>
	  <td></td>
	  <td width="484"></td>
	  <td width="105"></td>
	  <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans31');"> QUESTION 32(Click to show question) [+] </span><br>
  </b></font><br>
</div>
<div id="ans31">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>32</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '32' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '32' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '32' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer32 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='32' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A32 = $row['A'];
  $B32 = $row['B'];
  $C32 = $row['C'];
  $D32 = $row['D'];
}   
?>
          <br>
                 </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="37" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A32" type="checkbox" id="A32" value="A">
        </td>
        <td width="212" bgcolor="#003333" font size="+8"><?php echo $A32?>
          <input type="hidden" name="move_number32" size="20" value='<?php
	echo "32";?>' />
          <input type="hidden" name="choice32" value="A" /></td>
        <td width="48" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B32" type="checkbox" id="B32" value="B">
        </strong></span></td>
        <td width="231" bgcolor="#003333" font size="+8"><?php echo $B32;?> <input type="hidden" name="move_number32" size="20" value='<?php
	echo "32";?>' /> <input type="hidden" name="choice32" value="B" /></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="37" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C32" type="checkbox" id="C32" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C32;?> <input type="hidden" name="move_number32" size="20" value='<?php
	echo "32";?>' /> <input type="hidden" name="choice32" value="C" /></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D32" type="checkbox" id="D32" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D32;?> <input type="hidden" name="move_number32" size="20" value='<?php
	echo "32";?>' /> <input type="hidden" name="choice32" value="D" /> <input name="answer32" type="hidden" id="answer32" value="<?php echo $answer32;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans32');"> QUESTION 33(Click to show question) [+] </span></b></font></div>
<div id="ans32">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>33</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '33' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '33' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '33' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer33 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='33' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A33 = $row['A'];
  $B33 = $row['B'];
  $C33 = $row['C'];
  $D33 = $row['D'];
}   
?>
          <br>

        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="36" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A33" type="checkbox" id="A33" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A33;?> <input type="hidden" name="move_number33" size="20" value='<?php
	echo "33";?>' />
  <input type="hidden" name="choice33" value="A" /></td>
        <td width="44" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B33" type="checkbox" id="B33" value="B">
        </strong></span></td>
        <td width="236" bgcolor="#003333" font size="+8"><?php echo $B33;?> <input type="hidden" name="move_number33" size="20" value='<?php
	echo "33";?>'>
          <input type="hidden" name="choice33" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="36" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C33" type="checkbox" id="C33" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C33;?> <input type="hidden" name="move_number33" size="20" value='<?php
	echo "33";?>'>
          <input type="hidden" name="choice33" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D33" type="checkbox" id="D33" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D33;?> <input type="hidden" name="move_number33" size="20" value='<?php
	echo "33";?>'>
          <input type="hidden" name="choice33" value="D"> <input name="answer33" type="hidden" id="answer33" value="<?php echo $answer33;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans33');"> QUESTION 34(Click to show question) [+] </span></b></font></div>
<div id="ans33">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>34</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '34' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '34' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '34' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer34 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='34' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A34 = $row['A'];
  $B34 = $row['B'];
  $C34 = $row['C'];
  $D34 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A34" type="checkbox" id="A34" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A34;?> <input type="hidden" name="move_number34" size="20" value='<?php
	echo "34";?>'>
          <input type="hidden" name="choice34" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B34" type="checkbox" id="B34" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B34;?>  <input type="hidden" name="move_number34" size="20" value='<?php
	echo "34";?>'>
          <input type="hidden" name="choice34" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C34" type="checkbox" id="C34" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C34;?> <input type="hidden" name="move_number34" size="20" value='<?php
	echo "34";?>'>
          <input type="hidden" name="choice34" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D34" type="checkbox" id="D34" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D34;?> <input type="hidden" name="move_number34" size="20" value='<?php
	echo "34";?>'>
          <input type="hidden" name="choice34" value="D"> <input name="answer34" type="hidden" id="answer34" value="<?php echo $answer34;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans34');"> QUESTION 35(Click to show question) [+] </span></b></font></div>
<div id="ans34">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>35</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '35' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '35' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '35' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer35 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='35' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A35 = $row['A'];
  $B35 = $row['B'];
  $C35 = $row['C'];
  $D35 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="39" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A35" type="checkbox" id="A35" value="A">
        </td>
        <td width="213" bgcolor="#003333" font size="+8"><?php echo $A35;?> <input type="hidden" name="move_number35" size="20" value='<?php
	echo "35";?>'>
          <input type="hidden" name="choice35" value="A"></td>
        <td width="47" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B35" type="checkbox" id="B35" value="B">
        </strong></span></td>
        <td width="233" bgcolor="#003333" font size="+8"><?php echo $B35;?> <input type="hidden" name="move_number35" size="20" value='<?php
	echo "35";?>'>
          <input type="hidden" name="choice35" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="39" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C35" type="checkbox" id="C35" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C35;?> <input type="hidden" name="move_number35" size="20" value='<?php
	echo "35";?>'>
          <input type="hidden" name="choice35" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D35" type="checkbox" id="D35" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D35;?> <input type="hidden" name="move_number35" size="20" value='<?php
	echo "35";?>'>
          <input type="hidden" name="choice35" value="D"> <input name="answer35" type="hidden" id="answer35" value="<?php echo $answer35;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans35');"> QUESTION 36(Click to show question) [+] </span></b></font></div>
  <div id="ans35">
    <table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
      <!--DWLayoutTable-->
      <tr>
        <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
        <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>36</h1>";
?>
            <br>
        </td>
        <td colspan="2" valign="top" bgcolor="#808080"><table>
            <tr>
              <td width="600"><font size="+2"><b>
                <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '36' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '36' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '36' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer36 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='36' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A36 = $row['A'];
  $B36 = $row['B'];
  $C36 = $row['C'];
  $D36 = $row['D'];
}   
?>
                <br>
              </b></font></td>
            </tr>
          </table>
            <p>&nbsp;</p></td>
        <td width="27" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
            <tr>
              <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
                  <label><strong>A</strong></label>
                  </span>
                  <input name="A36" type="checkbox" id="A36" value="A">
              </td>
              <td width="216" bgcolor="#003333" font size="+8"><?php echo $A36;?>
                  <input type="hidden" name="move_number36" size="20" value='<?php
	echo "36";?>'>
                  <input type="hidden" name="choice36" value="A"></td>
              <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B
                    <input name="B36" type="checkbox" id="B36" value="B">
              </strong></span></td>
              <td width="238" bgcolor="#003333" font size="+8"><?php echo $B36;?>
                  <input type="hidden" name="move_number36" size="20" value='<?php
	echo "36";?>'>
                  <input type="hidden" name="choice36" value="B"></td>
            </tr>
            <tr>
              <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
            </tr>
            <tr>
              <td width="41" bgcolor="#003333"><span class="style5">
                <label><strong>C</strong></label>
                <input name="C36" type="checkbox" id="C36" value="C">
              </span></td>
              <td bgcolor="#003333"><?php echo $C36;?>
                  <input type="hidden" name="move_number36" size="20" value='<?php
	echo "36";?>'>
                  <input type="hidden" name="choice36" value="C"></td>
              <td bgcolor="#003333"><span class="style5"><strong>D
                    <input name="D36" type="checkbox" id="D36" value="D">
              </strong></span></td>
              <td bgcolor="#003333"><?php echo $D36;?>
                  <input type="hidden" name="move_number36" size="20" value='<?php
	echo "36";?>'>
                  <input type="hidden" name="choice36" value="D">
                  <input name="answer36" type="hidden" id="answer36" value="<?php echo $answer36;?>" /></td>
            </tr>
            <tr>
              <td colspan="4" bgcolor="#003333"><p> <span class="style1">
                  <label></label>
              </span> &nbsp;&nbsp;</td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="1"></td>
        <td></td>
        <td width="484"></td>
        <td width="105"></td>
        <td></td>
      </tr>
    </table>
  </div>
  <div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans36');"> QUESTION 37(Click to show question) [+] </span></b></font></div>
<div id="ans36">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>37</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '37' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '37' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '37' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer37 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='37' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A37 = $row['A'];
  $B37 = $row['B'];
  $C37 = $row['C'];
  $D37 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A37" type="checkbox" id="A37" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A37;?> <input name="move_number37" type="hidden" id="move_number37" value='<?php
	echo "37";?>' size="20">
          <input name="choice37" type="hidden" id="choice37" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B37" type="checkbox" id="B37" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B37;?>  <input name="move_number37" type="hidden" id="move_number37" value='<?php
	echo "37";?>' size="20">
          <input name="choice37" type="hidden" id="choice37" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C37" type="checkbox" id="C37" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C37;?> <input name="move_number37" type="hidden" id="move_number37" value='<?php
	echo "37";?>' size="20">
          <input name="choice37" type="hidden" id="choice37" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D37" type="checkbox" id="D37" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D37;?> <input name="move_number37" type="hidden" id="move_number37" value='<?php
	echo "37";?>' size="20">
          <input name="choice37" type="hidden" id="choice37" value="D"> 
          <input name="answer37" type="hidden" id="answer37" value="<?php echo $answer37;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans37');"> QUESTION 38(Click to show question) [+] </span></b></font></div>
<div id="ans37">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>38</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '38' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '38' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '38' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer38 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='38' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A38 = $row['A'];
  $B38 = $row['B'];
  $C38 = $row['C'];
  $D38 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A38" type="checkbox" id="A38" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A38;?> <input name="move_number38" type="hidden" id="move_number38" value='<?php
	echo "38";?>' size="20">
          <input name="choice38" type="hidden" id="choice38" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B38" type="checkbox" id="B38" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B38;?>  <input name="move_number38" type="hidden" id="move_number38" value='<?php
	echo "38";?>' size="20">
          <input name="choice38" type="hidden" id="choice38" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C38" type="checkbox" id="C38" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C38;?> <input name="move_number38" type="hidden" id="move_number38" value='<?php
	echo "38";?>' size="20">
          <input name="choice38" type="hidden" id="choice38" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <strong>
              <input name="D38" type="checkbox" id="D38" value="D">
              </strong> </strong></span></td>
        <td bgcolor="#003333"><?php echo $D38;?> <input name="move_number38" type="hidden" id="move_number38" value='<?php
	echo "38";?>' size="20">
          <input name="choice38" type="hidden" id="choice38" value="D"> 
          <input name="answer38" type="hidden" id="answer38" value="<?php echo $answer38;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans38');"> QUESTION 39(Click to show question) [+] </span></b></font></div>
<div id="ans38">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>39</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '39' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '39' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '39' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer39 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='39' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A39 = $row['A'];
  $B39 = $row['B'];
  $C39 = $row['C'];
  $D39 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A39" type="checkbox" id="A39" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A39;?> <input name="move_number39" type="hidden" id="move_number39" value='<?php
	echo "39";?>' size="20">
          <input name="choice39" type="hidden" id="choice39" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B39" type="checkbox" id="B39" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B39;?>  <input name="move_number39" type="hidden" id="move_number39" value='<?php
	echo "39";?>' size="20">
          <input name="choice39" type="hidden" id="choice39" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C39" type="checkbox" id="C39" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C39;?> <input name="move_number39" type="hidden" id="move_number39" value='<?php
	echo "39";?>' size="20">
          <input name="choice39" type="hidden" id="choice39" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D39" type="checkbox" id="D39" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D39;?> <input name="move_number39" type="hidden" id="move_number39" value='<?php
	echo "39";?>' size="20">
          <input name="choice39" type="hidden" id="choice39" value="D"> 
          <input name="answer39" type="hidden" id="answer39" value="<?php echo $answer39;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans39');"> QUESTION 40(Click to show question) [+] </span></b></font></div>
<div id="ans39">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>40</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '40' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '40' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '40' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer40 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='40' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A40 = $row['A'];
  $B40 = $row['B'];
  $C40 = $row['C'];
  $D40 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A40" type="checkbox" id="A40" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A40;?> <input name="move_number40" type="hidden" id="move_number40" value='<?php
	echo "40";?>' size="20">
          <input name="choice40" type="hidden" id="choice40" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B40" type="checkbox" id="B40" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B40;?>  <input name="move_number40" type="hidden" id="move_number40" value='<?php
	echo "40";?>' size="20">
          <input name="choice40" type="hidden" id="choice40" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C40" type="checkbox" id="C40" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C40;?> <input name="move_number40" type="hidden" id="move_number40" value='<?php
	echo "40";?>' size="20">
          <input name="choice40" type="hidden" id="choice40" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D40" type="checkbox" id="D40" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D40;?> <input name="move_number40" type="hidden" id="move_number40" value='<?php
	echo "40";?>' size="20">
          <input name="choice40" type="hidden" id="choice40" value="D"> 
          <input name="answer40" type="hidden" id="answer40" value="<?php echo $answer40;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;
        <input name="reg_no" type="hidden" id="reg_no" value='<?php
	echo $_SESSION['reg_no'];?>' size="20">
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style6"><font color="#FFFFFF"><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans40');"> QUESTION 41(Click to show question) [+] </span></font></div>
<tr></tr>
<div id="ans40">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr bgcolor="#006600"> 
<td height="19" colspan="3" valign="top" bgcolor="#003333"> 
  <p align="center"></td>
<td colspan="2" valign="top" bgcolor="#003333">&nbsp;
</td>
</tr>
<tr>
<td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
<td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>41</h1>";
?><br> </td>
<td colspan="2" valign="top" bgcolor="#808080"><table>
<tr>
<td width="600"><font size="+2"><b>
<?php

include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '41' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '41' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '41' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer41 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='41' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A41 = $row['A'];
  $B41 = $row['B'];
  $C41 = $row['C'];
  $D41 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
          </span>
            <label>
                <input name="A41" type="checkbox" id="A41" value="A">
              </label>
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A41;?> <input type="hidden" name="move_number41" size="20" value='<?php
	echo "41";?>' /> <input type="hidden" name="choice41" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
                <input name="B41" type="checkbox" id="B41" value="B">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B41;?> <input type="hidden" name="move_number41" size="20" value='<?php
	echo "41";?>' /> <input type="hidden" name="choice41" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="C41" type="checkbox" id="C41" value="C">
          </span></td>
          <td bgcolor="#003333"><?php echo $C41;?> <input type="hidden" name="move_number41" size="20" value='<?php
	echo "41";?>' /> <input type="hidden" name="choice41" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
                <input name="D41" type="checkbox" id="D41" value="D">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D41;?> <input type="hidden" name="move_number41" size="20" value='<?php
	echo "41";?>' /> <input type="hidden" name="choice41" value="D" /> <input type="hidden" name="answer41" value="<?php echo $answer41;?>" /></td>
        </tr>
        <tr>
          <td colspan="4" bgcolor="#003333"><p> <span class="style1">
              <label></label>
          </span></td>
        </tr>
      </table></td>
	</tr>
	<tr>
	  <td height="1"></td>
	  <td></td>
	  <td width="484"></td>
	  <td width="105"></td>
	  <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans41');"> QUESTION 42(Click to show question) [+] </span><br>
  </b></font><br>
</div>
<div id="ans41">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>42</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '42' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '42' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '42' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer42 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='42' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A42 = $row['A'];
  $B42 = $row['B'];
  $C42 = $row['C'];
  $D42 = $row['D'];
}   
?>
          <br>
                 </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="37" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A42" type="checkbox" id="A42" value="A">
        </td>
        <td width="212" bgcolor="#003333" font size="+8"><?php echo $A42?>
          <input type="hidden" name="move_number42" size="20" value='<?php
	echo "42";?>' />
          <input type="hidden" name="choice42" value="A" /></td>
        <td width="48" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B42" type="checkbox" id="B42" value="B">
        </strong></span></td>
        <td width="231" bgcolor="#003333" font size="+8"><?php echo $B42;?> <input type="hidden" name="move_number42" size="20" value='<?php
	echo "42";?>' /> <input type="hidden" name="choice42" value="B" /></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="37" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C42" type="checkbox" id="C42" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C42;?> <input type="hidden" name="move_number42" size="20" value='<?php
	echo "42";?>' /> <input type="hidden" name="choice42" value="C" /></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D42" type="checkbox" id="D42" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D42;?> <input type="hidden" name="move_number42" size="20" value='<?php
	echo "42";?>' /> <input type="hidden" name="choice42" value="D" /> <input name="answer42" type="hidden" id="answer42" value="<?php echo $answer42;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans42');"> QUESTION 43(Click to show question) [+] </span></b></font></div>
<div id="ans42">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>43</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '43' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '43' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '43' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer43 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='43' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A43 = $row['A'];
  $B43 = $row['B'];
  $C43 = $row['C'];
  $D43 = $row['D'];
}   
?>
          <br>

        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="36" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A43" type="checkbox" id="A43" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A43;?> <input type="hidden" name="move_number43" size="20" value='<?php
	echo "43";?>' />
  <input type="hidden" name="choice43" value="A" /></td>
        <td width="44" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B43" type="checkbox" id="B43" value="B">
        </strong></span></td>
        <td width="236" bgcolor="#003333" font size="+8"><?php echo $B43;?> <input type="hidden" name="move_number43" size="20" value='<?php
	echo "43";?>'>
          <input type="hidden" name="choice43" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="36" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C43" type="checkbox" id="C43" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C43;?> <input type="hidden" name="move_number43" size="20" value='<?php
	echo "43";?>'>
          <input type="hidden" name="choice43" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D43" type="checkbox" id="D43" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D43;?> <input type="hidden" name="move_number43" size="20" value='<?php
	echo "43";?>'>
          <input type="hidden" name="choice43" value="D"> <input name="answer43" type="hidden" id="answer43" value="<?php echo $answer43;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans43');"> QUESTION 44(Click to show question) [+] </span></b></font></div>
<div id="ans43">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>44</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '44' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '44' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '44' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer44 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='44' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A44 = $row['A'];
  $B44 = $row['B'];
  $C44 = $row['C'];
  $D44 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A44" type="checkbox" id="A44" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A44;?> <input type="hidden" name="move_number44" size="20" value='<?php
	echo "44";?>'>
          <input type="hidden" name="choice44" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B44" type="checkbox" id="B44" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B44;?>  <input type="hidden" name="move_number44" size="20" value='<?php
	echo "44";?>'>
          <input type="hidden" name="choice44" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C44" type="checkbox" id="C44" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C44;?> <input type="hidden" name="move_number44" size="20" value='<?php
	echo "44";?>'>
          <input type="hidden" name="choice44" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D44" type="checkbox" id="D44" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D44;?> <input type="hidden" name="move_number44" size="20" value='<?php
	echo "44";?>'>
          <input type="hidden" name="choice44" value="D"> <input name="answer44" type="hidden" id="answer44" value="<?php echo $answer44;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans44');"> QUESTION 45(Click to show question) [+] </span></b></font></div>
<div id="ans44">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>45</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '45' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '45' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '45' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer45 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='45' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A45 = $row['A'];
  $B45 = $row['B'];
  $C45 = $row['C'];
  $D45 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="39" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A45" type="checkbox" id="A45" value="A">
        </td>
        <td width="213" bgcolor="#003333" font size="+8"><?php echo $A45;?> <input type="hidden" name="move_number45" size="20" value='<?php
	echo "45";?>'>
          <input type="hidden" name="choice45" value="A"></td>
        <td width="47" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B45" type="checkbox" id="B45" value="B">
        </strong></span></td>
        <td width="233" bgcolor="#003333" font size="+8"><?php echo $B45;?> <input type="hidden" name="move_number45" size="20" value='<?php
	echo "45";?>'>
          <input type="hidden" name="choice45" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="39" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C45" type="checkbox" id="C45" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C45;?> <input type="hidden" name="move_number45" size="20" value='<?php
	echo "45";?>'>
          <input type="hidden" name="choice45" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D45" type="checkbox" id="D45" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D45;?> <input type="hidden" name="move_number45" size="20" value='<?php
	echo "45";?>'>
          <input type="hidden" name="choice45" value="D"> <input name="answer45" type="hidden" id="answer45" value="<?php echo $answer45;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans45');"> QUESTION 46(Click to show question) [+] </span></b></font></div>
  <div id="ans45">
    <table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
      <!--DWLayoutTable-->
      <tr>
        <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
        <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>46</h1>";
?>
            <br>
        </td>
        <td colspan="2" valign="top" bgcolor="#808080"><table>
            <tr>
              <td width="600"><font size="+2"><b>
                <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '46' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '46' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '46' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer46 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='46' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A46 = $row['A'];
  $B46 = $row['B'];
  $C46 = $row['C'];
  $D46 = $row['D'];
}   
?>
                <br>
              </b></font></td>
            </tr>
          </table>
            <p>&nbsp;</p></td>
        <td width="27" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
            <tr>
              <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
                  <label><strong>A</strong></label>
                  </span>
                  <input name="A46" type="checkbox" id="A46" value="A">
              </td>
              <td width="216" bgcolor="#003333" font size="+8"><?php echo $A46;?>
                  <input type="hidden" name="move_number46" size="20" value='<?php
	echo "46";?>'>
                  <input type="hidden" name="choice46" value="A"></td>
              <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B
                    <input name="B46" type="checkbox" id="B46" value="B">
              </strong></span></td>
              <td width="238" bgcolor="#003333" font size="+8"><?php echo $B46;?>
                  <input type="hidden" name="move_number46" size="20" value='<?php
	echo "46";?>'>
                  <input type="hidden" name="choice46" value="B"></td>
            </tr>
            <tr>
              <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
            </tr>
            <tr>
              <td width="41" bgcolor="#003333"><span class="style5">
                <label><strong>C</strong></label>
                <input name="C46" type="checkbox" id="C46" value="C">
              </span></td>
              <td bgcolor="#003333"><?php echo $C46;?>
                  <input type="hidden" name="move_number46" size="20" value='<?php
	echo "46";?>'>
                  <input type="hidden" name="choice46" value="C"></td>
              <td bgcolor="#003333"><span class="style5"><strong>D
                    <input name="D46" type="checkbox" id="D46" value="D">
              </strong></span></td>
              <td bgcolor="#003333"><?php echo $D46;?>
                  <input type="hidden" name="move_number46" size="20" value='<?php
	echo "46";?>'>
                  <input type="hidden" name="choice46" value="D">
                  <input name="answer46" type="hidden" id="answer46" value="<?php echo $answer46;?>" /></td>
            </tr>
            <tr>
              <td colspan="4" bgcolor="#003333"><p> <span class="style1">
                  <label></label>
              </span> &nbsp;&nbsp;</td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="1"></td>
        <td></td>
        <td width="484"></td>
        <td width="105"></td>
        <td></td>
      </tr>
    </table>
  </div>
  <div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans46');"> QUESTION 47(Click to show question) [+] </span></b></font></div>
<div id="ans46">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>47</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '47' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '47' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '47' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer47 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='47' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A47 = $row['A'];
  $B47 = $row['B'];
  $C47 = $row['C'];
  $D47 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A47" type="checkbox" id="A47" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A47;?> <input name="move_number47" type="hidden" id="move_number47" value='<?php
	echo "47";?>' size="20">
          <input name="choice47" type="hidden" id="choice47" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B47" type="checkbox" id="B47" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B47;?>  <input name="move_number47" type="hidden" id="move_number47" value='<?php
	echo "47";?>' size="20">
          <input name="choice47" type="hidden" id="choice47" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C47" type="checkbox" id="C47" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C47;?> <input name="move_number47" type="hidden" id="move_number47" value='<?php
	echo "47";?>' size="20">
          <input name="choice47" type="hidden" id="choice47" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D47" type="checkbox" id="D47" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D47;?> <input name="move_number47" type="hidden" id="move_number47" value='<?php
	echo "47";?>' size="20">
          <input name="choice47" type="hidden" id="choice47" value="D"> 
          <input name="answer47" type="hidden" id="answer47" value="<?php echo $answer47;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans47');"> QUESTION 48(Click to show question) [+] </span></b></font></div>
<div id="ans47">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>48</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '48' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '48' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '48' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer48 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='48' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A48 = $row['A'];
  $B48 = $row['B'];
  $C48 = $row['C'];
  $D48 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A48" type="checkbox" id="A48" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A8;?> <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "48";?>' size="20">
          <input name="choice48" type="hidden" id="choice48" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B48" type="checkbox" id="B48" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B48;?>  <input name="move_number48" type="hidden" id="move_number48" value='<?php
	echo "48";?>' size="20">
          <input name="choice48" type="hidden" id="choice48" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C48" type="checkbox" id="C48" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C8;?> <input name="move_number48" type="hidden" id="move_number48" value='<?php
	echo "48";?>' size="20">
          <input name="choice48" type="hidden" id="choice48" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <strong>
              <input name="D48" type="checkbox" id="D48" value="D">
              </strong> </strong></span></td>
        <td bgcolor="#003333"><?php echo $D48;?> <input name="move_number48" type="hidden" id="move_number48" value='<?php
	echo "48";?>' size="20">
          <input name="choice48" type="hidden" id="choice48" value="D"> 
          <input name="answer48" type="hidden" id="answer48" value="<?php echo $answer48;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans48');"> QUESTION 49(Click to show question) [+] </span></b></font></div>
<div id="ans48">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>49</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '49' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '49' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '49' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer49 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='49' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A49 = $row['A'];
  $B49 = $row['B'];
  $C49 = $row['C'];
  $D49 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A49" type="checkbox" id="A49" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A49;?> <input name="move_number49" type="hidden" id="move_number49" value='<?php
	echo "49";?>' size="20">
          <input name="choice49" type="hidden" id="choice49" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B49" type="checkbox" id="B49" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B49;?>  <input name="move_number49" type="hidden" id="move_number49" value='<?php
	echo "49";?>' size="20">
          <input name="choice49" type="hidden" id="choice49" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C49" type="checkbox" id="C49" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C49;?> <input name="move_number49" type="hidden" id="move_number49" value='<?php
	echo "49";?>' size="20">
          <input name="choice49" type="hidden" id="choice49" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D49" type="checkbox" id="D49" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D49;?> <input name="move_number49" type="hidden" id="move_number49" value='<?php
	echo "49";?>' size="20">
          <input name="choice49" type="hidden" id="choice49" value="D"> 
          <input name="answer49" type="hidden" id="answer49" value="<?php echo $answer49;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans49');"> QUESTION 50(Click to show question) [+] </span></b></font></div>
<div id="ans49">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>50</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '50' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '50' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '50' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer50 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='50' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A50 = $row['A'];
  $B50 = $row['B'];
  $C50 = $row['C'];
  $D50 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
            <input name="A50" type="checkbox" id="A50" value="A">
        </td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A50;?> <input name="move_number50" type="hidden" id="move_number50" value='<?php
	echo "50";?>' size="20">
          <input name="choice50" type="hidden" id="choice50" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
              <input name="B50" type="checkbox" id="B50" value="B">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B50;?>  <input name="move_number50" type="hidden" id="move_number50" value='<?php
	echo "50";?>' size="20">
          <input name="choice50" type="hidden" id="choice50" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <input name="C50" type="checkbox" id="C50" value="C">
        </span></td>
        <td bgcolor="#003333"><?php echo $C50;?> <input name="move_number50" type="hidden" id="move_number50" value='<?php
	echo "50";?>' size="20">
          <input name="choice50" type="hidden" id="choice50" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
              <input name="D50" type="checkbox" id="D50" value="D">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D50;?> <input name="move_number50" type="hidden" id="move_number50" value='<?php
	echo "50";?>' size="20">
          <input name="choice50" type="hidden" id="choice50" value="D"> 
          <input name="answer50" type="hidden" id="answer50" value="<?php echo $answer50;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;
        <input name="reg_no" type="hidden" id="reg_no" value='<?php
	echo $_SESSION['reg_no'];?>' size="20">
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4">
      <label></label>
      <div align="center">
      <label>
        <input type="submit" name="Submit2" value="Submit">
      </label>
</form>
      <table width="719">
        <tr>
          <td align="center"><span class="style8">Powered by e-NERGY Software Solutions. 08039098042</span> </td>
        </tr>
      </table>
      </td>
      </tr>
<tr>
    
</table>

</body>
</html>
<?php
$_SESSION['display_no'] = $display_no;
}
?> 