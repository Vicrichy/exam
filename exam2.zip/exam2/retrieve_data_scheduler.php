<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST</title></head>

<body bgcolor="#CC99FF">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
  <tr bgcolor="#000000"> 
    <td colspan="4"> <p align="right"> <b><font size="2" color="#008000"> <a href="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/help.html"> 
        </a></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;GO 
        BACK</font></a></font></b></p>
      <p align="center"> <font size="5">&nbsp;</font><b><font size="5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <font color="#0000FF" face="Copperplate Gothic Bold"><u>RETRIEVE DATA</u></font></font></b></td>
  </tr>
  <tr> 
    <td colspan="2" valign="top" bgcolor="#808000"><u> <font color="#FFFFFF"> </font></u></td>
    <td width="3%" valign="top">&nbsp; </td>
    <td width="3%" bgcolor="#000000" rowspan="6">&nbsp;</td>
  </tr>
  <tr> 
    <td height="48" colspan="2" valign="top" bgcolor="#0033CC"><p><a href="form.php"><font size="2"><b><u><font color="#00FF00">ADMISSION LETTER &gt;&gt;</font></u>&nbsp;</b></font></a></p>
      <ul>
        <li><a href="application_form2.php"><font size="2"><b><u><font color="#00FF00">Specialised Computer Training Programme &gt;&gt;</font></u>&nbsp;</b></font></a></li>
      </ul>
      <p><a href="application_form.php"><font size="2"><b><u><font color="#00FF00">APPLICATION FORM&gt;&gt; </font></u></b></font></a></p>
      <p><a href="finance_popup.php"><font size="2"><b><u><font color="#00FF00">RECEIPTS &gt;&gt;</font></u>&nbsp;</b></font></a></p>
      <p><font size="2"><b><a href="retrieve_data_scheduler_reg.php"><u><font color="#00FF00">         REGISTRATION 
        RECORDS &gt;&gt;</font></u></a></b></font>      </p>
      <p> <font size="2"><b><a href="test_results.php">&nbsp;<u><font color="#00FF00">TEST 
        RESULTS &gt;&gt;</font></u></a></b></font></p>
      <p><font size="2"><b><a href="retrieve_data_scheduledtests.php">&nbsp;<u><font color="#00FF00">SCHEDULED 
    TESTS &gt;&gt;</font></u></a></b></font></p>
      <p><font size="2"><b><a href="upgrade_semester.php">&nbsp;<u><font color="#00FF00">UPGRADE SEMESTER  &gt;&gt;</font></u></a></b></font></p></td>
    <td width="3%" height="48" valign="top" bgcolor="#CC99FF">&nbsp;</td>
  </tr>
  <tr> 
    <td height="47" colspan="3" valign="top" bgcolor="#CC99FF"><div align="right"><form name="form2" method="post" action="student_file.php">
  <div align="right"> <strong>Specify reg.no</strong> 
    <input name="reg_no" type="text" id="reg_no">
    <input type="submit" name="Submit2" value="OPEN STUDENT'S FILE">
  </div>
</form></div></td>
  </tr>
  <tr> 
    <td width="3%" height="242" rowspan="3" valign="top" bordercolor="#0000FF" bgcolor="#0000FF">&nbsp; 
    </td>
    <td width="91%" valign="top" bgcolor="#0000FF"> <p>&nbsp;</p></td>
    <td width="3%" height="242" rowspan="3" valign="top" bgcolor="#0000FF">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CC99FF">&nbsp;</td>
  </tr>
  <tr> 
    <td valign="top"><p> This is the data retrieval/data mining section. This 
        interface provides the user with links to certain screens for performing 
        specific data retrieval operations.</p>
      <p>Please click any of the links above.</p>
      <p>&nbsp;</p>
      
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
  <tr> 
    <td colspan="4" bgcolor="#000000"> <p align="center"><b> <font color="#000000" size="2">Technology 
        by WebOptions ICT (www.weboptionsict.com/08069802185)</font></b></td>
  </tr>
</table>

</body>

</html>