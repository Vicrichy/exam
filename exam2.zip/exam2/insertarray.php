<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

<p>
  <?php
include('dbconnect.php');



// HERE'S THE ARRAY, WITH THE VALUES
$insert_values = array("Adult education", "Accounting", "Architecture", "Asian and african_studies","Banking and finance", "Biochemistry", "Biotechnology", "Botany", "Building","Building and quantity_surveying", "Bus Admin"
, "Business education", "Chemical engineering", "Chemical technology","civil engineering" ,"Computer science","Cooperative economics","Economics","Education english","Education igbo","Electrical electronics","Electro mech","English","Environmental management","Estate management","Geology","Geology and metallurgy","Geophysics","Guidance and counselling","HPE","Health education","Industrial chemistry","Industrial physics","Law","Lingusitics","Marketing","Mass communication","Mathematics","Mechanical engineering","Medicine and surgery","Med lab Science","Med rehabilitation","Metallurgy and mathematics","Microbiology","Nursing","PAE","Pharmacy","Philosophy","Physics","Physics education","Physics electronics","Political science","Production technology","Psycology","Public administration","Quantity surveying","Radiography","Science education","Sociology","Statistics","Survey geophysics","Technical education","Vocational education","Zoology", "Theatre arts");





// INSERT THE VALUES INTO THE DATABASE
for($i = 0; $i<count($insert_values); $i++)
{
include('dbconnect.php');



$query = "INSERT INTO departments_table
          (department)";
$query .= "VALUES
          ('$insert_values[$i]')";
		  
//$result = mysql_query($query);
}


?>
JJJJJJJJ
<br />
<?php
$show = count($insert_values);
echo "$show";
?>

<?php
// RETRIEVE THE VALUES FROM THE DATABASE AND DISPLAY ON THE PAGE

$query2 = "SELECT department FROM departments_table";
$result2 = mysql_query($query2);

while ($row = mysql_fetch_array($result2, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "$value" . "</br>";
}}

?>
</p>
<p>

<?php // LOAD THE DATABASE TABLE DATA INTO THE DROP DOWN BOX  ?>
 
 
 
  <select name="department" id="department" tabindex="5">
    <?php 
$query3 = "SELECT distinct department FROM departments_table order by department";
$result3 = mysql_query($query3);

echo "<option selected></option>";
while ($row = mysql_fetch_array($result3, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{

echo "<option value>";
echo "$value" . "</br>";
echo "</option>";

}}?>

   
  </select>
  
</p>
</body>
</html>
