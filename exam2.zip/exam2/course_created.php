<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>DATAMIX Test Engine [ERROR!]</title>
<meta http-equiv="Page-Enter" content="blendTrans(Duration=4.0)">
</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="100%">
	
  <tr bgcolor="#333333"> 
    <td height="41" colspan="3">&nbsp;</td>
  </tr>
	<tr>
		<td height="27" colspan="3" bgcolor="#808080">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="20%" bgcolor="#333333">&nbsp;</td>
		
    <td width="62%" bgcolor="#000000" valign="top"> &nbsp; <p align="center"><font face="Arial Black" size="1">&nbsp;&nbsp;&nbsp; 
        </font><font color="#00FF00" size="1" face="Arial Black" style="font-size: 45pt"> 
        COURSE CREATED</font></p>
      <p align="center"><font color="#FFFFFF" face="Arial Black" size="5">&nbsp;&nbsp;&nbsp;</font><font color="#FFFFFF" face="Arial Black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        THE <font color="#FFFF00">COURSE </font>HAS BEEN CREATED.</font><font color="#FFFFFF" face="Arial Black" size="5">&nbsp;&nbsp;<br>
        <br>
        </font><b><i><font face="Arial Black" size="5" color="#00FFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></i></b></p>
		<p align="center"><font face="Arial Black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#FF0000"> </font>
		<a href="javascript:history.back()">[ RETRY ]</a></font></td>
		
    <td width="18%" bgcolor="#333333">&nbsp;</td>
	</tr>
	<tr>
		<td height="26" width="100%" bgcolor="#808080" colspan="3">&nbsp;</td>
	</tr>
	
  <tr bgcolor="#333333"> 
    <td height="26" width="100%" colspan="3"><div align="center"></div></td>
	</tr>
</table>

</body>

</html>
