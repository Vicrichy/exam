<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>scheduler middle</title>
</head>

<body bgcolor="#FFFFFF">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("testmode","reg_no","course","day","month","year","start_time","duration","max_questions", "max_score");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("TEST MODE","REG.NUMBER","COURSE","DAY","MONTH","YEAR","TEST START TIME","TEST DURATION","NO.OF QUESTIONS", "MAXIMUM SCORE");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<script language="JavaScript">

function formCheck2(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("date","test_mode","course2");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("DATE","TEST MODE","COURSE");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>




<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="97%">
  <tr> 
    <td colspan="3" bgcolor="#000000"> <p align="center"><font face="Copperplate Gothic Bold" color="#FFFFFF"> 
        <b>ACTIVATE TODAY'S TEST <br>
        &nbsp;</b></font></td>
  </tr>
  <tr> 
    <td width="47%" rowspan="3"><br>
      Before a test can be taken in any day, the administrator has to activate it. After that day, the test automatically de-activates. <br>
        <br>
      To activate test for today, please fill in the correct values in the form below. <br>
      <p>Please ensure that you fill in the values cautiously.</p>
        <form method="POST" action="insert_testschedule_script.php" onSubmit="return formCheck(this);">
          <!--webbot bot="SaveResults" U-File="file:///C:/Documents and Settings/MY OFFICE/My Documents/FILE CABINET/MY WORKS/weboptionsict.com/_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
          <p><b><font color="#FFFFFF"><span style="background-color: #000000"> 1) 
            TEST TYPE </span></font></b></p>
          <p>
            <select name="testmode" id="testmode">
              <option>Exam</option>
            </select>
          </p>
          <p><font color="#FFFFFF"> <span style="font-weight: 700; background-color: #000000">2)&nbsp;&nbsp; 
            COURSE&nbsp;&nbsp;&nbsp;</span></font></p>
          <p>
            <select name="select" id="select">
              <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
            </select>
          </p>
          <p><font color="#FFFFFF"><b><span style="background-color: #000000">3) 
          TEST START TIME (12 Hour format) &nbsp;&nbsp;&nbsp; </span></b></font></p>
          <p><font size="2"><b><font color="#CCCCCC"> 
            <select name="start_time" id="selectmonth0" style="width:49; height:22">
              <option selected></option>
              <option value="1">1 am</option>
              <option value="2">2 am</option>
              <option value="3">3 am</option>
              <option value="4">4 am</option>
              <option value="5">5 am</option>
              <option value="6">6 am</option>
              <option value="7">7 am</option>
              <option value="8">8 am</option>
              <option value="9">9 am</option>
              <option value="10">10 am</option>
              <option value="11">11 am</option>
              <option value="12">12 noon</option>
              <option value="13">1 pm</option>
              <option value="14">2 pm</option>
              <option value="15">3 pm</option>
              <option value="16">4 pm</option>
              <option value="17">5 pm</option>
              <option value="18">6 pm</option>
              <option value="19">7 pm</option>
              <option value="20">8 pm</option>
              <option value="21">9 pm</option>
              <option value="22">10 pm</option>
              <option value="23">11 pm</option>
              <option value="24">12 am</option>
          </select>
            </font></b></font></p>
          <p><font color="#FFFFFF"><b><span style="background-color: #000000"> 4) 
            TEST DURATION&nbsp;&nbsp;(Minutes)&nbsp; </span></b></font></p>
          <p> 
            <input name="duration" type="text" id="duration" size="3">
            minutes</p>
          <p><font color="#FFFFFF"> <span style="font-weight: 700; background-color: #000000">5) 
            NUMBER OF QUESTIONS&nbsp;&nbsp;&nbsp;&nbsp; </span></font></p>
          <p> 
            <input name="max_questions" type="text" id="max_questions" size="6">
          </p>
          <p><font color="#FFFFFF"><span style="font-weight: 700; background-color: #000000">6) 
            MAXIMUM SCORE &nbsp;&nbsp;&nbsp;&nbsp; </span></font></p>
          <p>
            <input name="max_score" type="text" id="max_score" size="6">
            marks</p>
          <p> 
            <input name="submit" type="submit" id="submit" value="ACTIVATE TEST">
            <input type="reset" value="Reset" name="B2">
          </p>
    </form></td><td width="2%" bgcolor="#000000" rowspan="4">&nbsp;</td>
    <td width="50%" valign="top"><form name="form2" method="post" action="student_file.php">
  <div align="right"> Specify reg.no 
    <input name="reg_no" type="text" id="reg_no">
    <input type="submit" name="Submit2" value="OPEN STUDENT'S FILE">
  </div>
</form>&nbsp;</td>
  </tr>
  <tr> 
    <td valign="top" bgcolor="#000000"><font color="#00FF00">View Scheduled/Activated Tests</font></td>
  </tr>
  <tr>
    <td valign="top" height="458"><form name="form1" method="post" action="show_scheduled_tests.php">
        <br>
        <input type="submit" name="Submit" value="VIEW RECORDS">
      </form>
      <table width="100%" border="1">
        <tr>
          <td bgcolor="#000000"><font color="#00FF00">De-activate / Disable an activated Test</font></td>
        </tr>
      </table>
      <form name="form2" method="post" action="delete_scheduled_test.php" onSubmit="return formCheck2(this);">
        <p align="right">SPECIFY DATE
            <input name="date" type="text" id="date">
          <br>
          TEST MODE
          <select name="test_mode" id="test_mode">
            <option selected></option>
            <option>Quiz</option>
            <option>Exam</option>
            <option>Exam Re-sit</option>
          </select>
          <br>
          COURSE
          <input name="course" type="text" id="course" size="31"> 
          <br>
          <br>
          <input type="submit" name="Submit2" value="DELETE / CANCEL TEST">
        </p>
        <p>&nbsp;</p>
      </form>
      <p>&nbsp;</p></td>
  </tr>
  <tr> 
    <td width="47%">&nbsp;</td>
    <td width="50%" valign="top">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
    <td width="50%">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</body>

</html>

<?php
}
?>