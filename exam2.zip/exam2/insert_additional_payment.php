<?php
$reg_no =$_POST['reg_no'];
$course =$_POST['course'];
$amount_paid =$_POST['amount_paid'];
$receipt_no =$_POST['receipt_no'];
$comment =$_POST['comment'];





if (isset($_POST['submit'])) {
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');


// DETERMINE THE DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");



// CHECK IF THE COURSE EXISTS

$query2="Select course from course_list where course = '$course'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) == 0) {
header('Location: course_does_not_exist.php');
mysql_close($link);
} 
else 
{

// CHECK IF THE USERNAME PREVIOUSLY EXISTS
include ('dbconnect.php');

$query1="Select username from registration_table where username = '$username' and (surname != '$surname' and first_name != '$first_name')";
$result1=mysql_query($query1);

if (mysql_num_rows($result1) > 0) {
header('Location: username_already_exists.php');
mysql_close($link);
} 
else 
{






// DETERMINE THE COURSE AMOUNT
include ('dbconnect.php');
$query3 =mysql_query("select course_amount from course_list where course = '$course'");
$query_course_amount =mysql_result($query3, 0, "course_amount");




include ('dbconnect.php');

//SURNAME
$query_surname = mysql_query("SELECT surname FROM registration_table WHERE reg_no = '$reg_no'");
$surname = mysql_result($query_surname, 0, "surname");

//FIRST NAME
$query_first = mysql_query("SELECT first_name FROM registration_table WHERE reg_no = '$reg_no'");
$first_name = mysql_result($query_first, 0, "first_name");

//MIDDLE NAME
$query_middle = mysql_query("SELECT middle_name FROM registration_table WHERE reg_no = '$reg_no'");
$middle_name = mysql_result($query_middle, 0, "middle_name");


// SELECT THE PREVIOUS PAYMENT SUM

$query_previous = mysql_query("SELECT amount_paid FROM registration_table WHERE reg_no = '$reg_no' AND course = '$course'");
$previous_pay = mysql_result($query_previous, 0, "amount_paid");

// CALCULATE THE NEW PAY

$new_pay = $previous_pay + $amount_paid ;

// UPDATE THE TABLE TO REFLECT THE ADDITIONAL PAYMENT SUM


$query_add = ("UPDATE registration_table SET amount_paid = '$new_pay' WHERE reg_no = '$reg_no' and course = '$course'");
$result2 = mysql_query($query_add);
 


//DETERMINE THE SUM OF THE STIPULATED COURSE FEES

$query_calc = mysql_query("SELECT sum(course_amount) FROM registration_table WHERE reg_no = '$reg_no'");
$course_total = mysql_result($query_calc, 0, "sum(course_amount)");
			 
			 
// UPDATE THE TABLE TO FEED IN THE VALUE OF THE TOTAL SUM OF THE STIPULATED COURSES

$query_update = ("UPDATE registration_table SET total_course_amt = '$course_total' WHERE reg_no = '$reg_no'");
$result2 = mysql_query($query_update);
			 			 
// DETERMINE THE BALANCE

$query_paid = mysql_query("SELECT sum(amount_paid) FROM registration_table WHERE reg_no = '$reg_no'");
$amount_paid = mysql_result($query_paid, 0, "sum(amount_paid)");

$balance = $course_total - $amount_paid ;


// UPDATE THE TABLE TO FEED IN THE VALUE OF THE BALANCE OWED US BY THE STUDENT

$query_balance = ("UPDATE registration_table SET balance = '$balance' WHERE reg_no = '$reg_no'");
$result3 = mysql_query($query_balance);



/////////// DETERMINE IF FEES ARE COMPLETED OR NOT////////////////

// Find out amount student has paid
$query_paid2 = mysql_query("SELECT sum(amount_paid) FROM registration_table WHERE reg_no = '$reg_no'");
$amount_paid2 = mysql_result($query_paid2, 0, "sum(amount_paid)");


// INDICATE IF PAYMENT IS COMPLETE OR PARTIAL

if (($course_total) == ($amount_paid2)) { 

$query_upd = ("UPDATE registration_table SET payment_status = 'COMPLETE' WHERE reg_no ='$reg_no'");
$result4 = mysql_query($query_upd); 
}
else
{
$query_upd2 = ("UPDATE registration_table SET payment_status = 'PARTIAL' WHERE reg_no ='$reg_no'");
$result5 = mysql_query($query_upd2); 
}






// INSERT INTO PAYMENT HISTORY TABLE

$query2x = "INSERT INTO payment_history
          (day, month, year, surname, middle_name, first_name, reg_no, course, amount_paid, receipt_no, comment)";

$query2x .= "VALUES
          ('$computer_date_day', '$computer_date_month', '$computer_date_year', '$surname', '$middle_name', '$first_name', '$reg_no', '$course', '$amount_paid', '$receipt_no', '$comment')";

$resultx = mysql_query($query2x);


header('Location: record_saved.html');
}
}
}
}
	 
?> 