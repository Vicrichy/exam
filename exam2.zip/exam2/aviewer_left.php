<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 9) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 

<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST</title>
</head>

<body background="images/blissless_1024.jpg">
<p>
<a target="main" title="Use this to activate a day's test, and view test information" href="schedule_test.php"></a> 
  <br>
    <a target="main" title="Create new courses, delete courses, upload and manage test questions." href="manage_courses.php"></a> 
  <br>
    <a target="main" title="Generate computer printouts and extract database data such as test results, registration records, student file, etc" href="retrieve_data_scheduler.php"><img src="images/retrievedata_bt.jpg" width="138" height="28" border="0"></a> 
  <br>
    <a target="main" title="Modify the various login passwords" href="manage_passwords.php"></a><a href="manage_passwords.php" target="main"></a></p>
<p><a href="computer_printout_page.php" target="main" title="Generate computer printouts of database records to be viewed by a third party."><img src="images/computer_printout_butt.jpg" width="138" height="28" border="0"></a></p>
</body>

</html>
<?php
}
?>