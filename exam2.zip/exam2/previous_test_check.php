<?php
if (($test_type) == 'Quiz')
{

include('dbconnect.php');



$queryx1="SELECT reg_no FROM registration_table WHERE reg_no = '$reg_no' and course = '$course' and quiz = 'Yes'";
$resultx1=mysql_query($queryx1);

if (mysql_num_rows($resultx1) > 0) {
header('Location: test_previously_taken_error.php');
mysql_close($link);
} 
}


elseif (($test_type) == 'Exam')
{

include('dbconnect.php');



$queryx1="SELECT reg_no FROM registration_table WHERE reg_no = '$reg_no' and course = '$course' and exam = 'Yes' ";
$resultx1=mysql_query($queryx1);

if (mysql_num_rows($resultx1) > 0) {
header('Location: test_previously_taken_error.php');
mysql_close($link);
} 
}

elseif (($test_type) == 'Exam Re-sit')
{

include('dbconnect.php');



$queryx1="SELECT reg_no FROM registration_table WHERE reg_no = '$reg_no' and course = '$course' and exam_resit = 'Yes'";
$resultx1=mysql_query($queryx1);

if (mysql_num_rows($resultx1) > 0) {
header('Location: test_previously_taken_error.php');
mysql_close($link);
} 
}
else
{
?>