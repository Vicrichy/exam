 <?php


$course=$_POST['course'];
$question_text=$_POST['question_text'];
$option_a=$_POST['option_a'];
$option_b=$_POST['option_b'];
$option_c=$_POST['option_c'];
$option_d=$_POST['option_d'];
$correct_option=$_POST['select'];



include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');


// CHECK IF THE COURSE EXISTS

$query2="Select course from course_list where course = '$course'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) == 0 ) {
header('Location: course_does_not_exist.php');
mysql_close($link);
} 
else 
{



// DETERMINE THE COURSE CODE FROM THE SPECIFIED COURSE NAME
$queryx =mysql_query("select course_code from course_list where course = '$course'");
$query_coursecode =mysql_result($queryx, 0, "course_code");


// INSERT THE QUESTION

$query = "INSERT INTO $query_coursecode
               (question)";

$query .= "VALUES
        ('$question_text')";
				
$result = mysql_query($query);




// RETRIEVE THE ID OF THE QUESTION INSERTED
$query1 =mysql_query("select id from $query_coursecode order by id desc limit 1");
$lastid =mysql_result($query1, 0, "id");


// RETRIEVE THE QUESTION INSERTED
$queryv =mysql_query("select question from $query_coursecode order by id desc limit 1");
$lastquestion =mysql_result($queryv, 0, "question");


 // DETERMINE THE COURSE CODE FROM THE SPECIFIED COURSE NAME
$queryx =mysql_query("select course_code from course_list where course = '$course'");
$query_coursecode =mysql_result($queryx, 0, "course_code");


 
 // INSERT OPTION A  
$query2x = "INSERT INTO $query_coursecode
               (id, question, obj, alpha, correct)";

$query2x .= "VALUES
          ('$lastid', '$lastquestion', '$option_a', 'A', '',)";
				
$result = mysql_query($query2x);




 // INSERT OPTION B
$query3 = "INSERT INTO $query_coursecode
               (id, question, obj, alpha)";

$query3 .= "VALUES
          ('$lastid', '$lastquestion', '$option_b', 'B')";
				
$result = mysql_query($query3);


 // INSERT OPTION C
$query4 = "INSERT INTO $query_coursecode
               (id, question, obj, alpha)";

$query4 .= "VALUES
          ('$lastid', '$lastquestion', '$option_c', 'C')";
				
$result = mysql_query($query4);



 // INSERT OPTION D
$query5 = "INSERT INTO $query_coursecode
               (id, question, obj, alpha)";

$query5 .= "VALUES
          ('$lastid', '$lastquestion', '$option_d', 'D')";
				
$result = mysql_query($query5);



// SPECIFY THE CORRECT OPTION
$query6 = ("UPDATE $query_coursecode SET correct = 'right' WHERE alpha = '$correct_option' AND id = '$lastid'");  
$result = mysql_query($query6);


// REMOVE THE QUESTION INSERTED IN THE FIRST STATEMENT, BECAUSE IT HAS NO OPTION
$query7 = ("DELETE FROM $query_coursecode WHERE obj = 'NONE'");
$result = mysql_query($query7);

header ('Location : saved.htm');

header('Location: saved.htm');
mysql_close($link);
}
}
 ?> 