<?php
$link = @mysql_connect('localhost', 'root', '');
//$link = @mysql_connect('localhost', 'afrihub_etest', 'afrihub_db3'); -- this is the SuperDBA login
//$link = @mysql_connect('localhost', 'etest', 'etest_pass');

mysql_select_db('pacific');
?>