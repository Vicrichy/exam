<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 2) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 
<?php
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
?>

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST ::: Registration</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=4.0,Transition=10)">

<!-- BASIC CALENDAR HEADER -->
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
.style5 {font-size: 12px}
</style>


<script type="text/javascript" src="basiccalendar.js">


</script>

<!-- BASIC CALENDAR HEADER ENDS -->
</head>

<body background="images/reg_stuff.jpg">

<script language="JavaScript">


function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("firstname","surname","reg_no","department","batch_no","classroom","trainer","course","gender","userfile","phone","Address","email");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("FIRSTNAME","SURNAME","REG.NUMBER","DEPARTMENT","BATCH NUMBER","CLASSROOM","TRAINER","COURSE","GENDER","And Submit Picture","PHONE","ADDRESS","E-MAIL");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}

function checkAddress() {
if (document.reg.email.value.indexOf("@") == -1) {
alert("Check the e-mail address for accuracy. e.g. info@afrihub.com")
document.reg.email.value="";
document.reg.email.setFocus()
return false
}
return true
}


function checkIt(evt) {
evt = (evt) ? evt : window.event
var charCode = (evt.which) ? evt.which : evt.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57)) {
alert("This field accepts numbers only.")
status = "This field accepts numbers only."
return false
}
status = ""
return true
}
// -->
</script>



<table border="0" cellpadding="0" style="border-collapse: collapse" width="104%">
  <tr> 
    <td height="77" colspan="2" bgcolor="#008000"> <p align="center"><b><font size="5"><font color="#FFFFFF"><u><font face="Copperplate Gothic Bold">STUDENTS 
        REGISTRATION</font></u></font></font></b> 
    </td>
    <td bgcolor="#FFFFFF">&nbsp; </td>
  </tr>
  <tr> 
    <td width="18%" bgcolor="#000000" rowspan="2" valign="top"><p><strong><a href="img_upl.php"></a></strong> <span class="style5"><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"></a></font></span></p>
      <p><strong><a href="additional_payment.php"></a></strong> &nbsp; </p>
      <p>&nbsp;<a href="registration_page.php"></a></p>
      <p> &nbsp;<a href="retrieve_data_scheduler_reg2.php"></a></p>
      <p><a href="modify_reg_data.php"></a>      </p>
      <p>&nbsp;<br>
        <strong><a href="ongoing_classes.php"></a></strong><br>
        &nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><font color="#CCCCCC"><br>
        </font></td>
    <td width="77%" height="25" valign="top" bgcolor="#808000"><span class="style1">STUDENTS REGISTRATION </span></td>
    <td width="5%" bgcolor="#008000" rowspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="77%" valign="top" height="377"><form name="reg" action="insert_registration_script.php" method="POST" enctype="multipart/form-data" onSubmit="return formCheck(this);">
        <!--webbot bot="SaveResults" U-File="fpweb:///_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bordercolorlight="#000099" bordercolordark="#000080">
          
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">First 
              Name</font></span></td>
            <td width="205"><input name="firstname" type="text" id="firstname" size="25" tabindex="1"></td>
            <td width="85" bgcolor="#006600"><span class="style1">Course</span></td>
            <td><select name="course" id="course" tabindex="13">
              <option>COMPUTER INFORMATION TECHNOLOGY</option>
              <option>COMPUTER STUDIES AND SEC. ADMINISTRATION</option>
              <option>COMPUTER HARDWARE REPAIRS AND MAINTENANCE</option>
              <option>EXECUTIVE DIPLOMA</option>
              <option>UMITT</option>
                                                </select></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Surname</font></span></td>
            <td width="205"><input name="surname" type="text" id="surname" size="25" tabindex="2"></td>
            <td bgcolor="#006600"><span class="style1">Gender</span></td>
            <td><select name="gender" id="gender" tabindex="13">
              <option selected></option>
              <option>MALE</option>
              <option>FEMALE</option>
            </select></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Othernames</font></span></td>
            <td><input name="othernames" type="text" id="othernames" size="25" tabindex="3"></td>
            <td width="85" bgcolor="#006600"><span class="style1"><font face="Agency FB">Date</font></span></td>
            <td><strong>:<?php
			echo "$system_date";
			?></strong></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Reg. No</font></span></td>
            <td width="205"><input name="reg_no" type="text" id="reg_no" tabindex="4" value="<?php
$year = date("Y");
$month = date("M");
$rand = rand();

echo "$year/$month/REG/$rand";
?>">
            <br></td>
            <td width="85" bgcolor="#006600"><span class="style1"><font face="Agency FB">Picture</font></span></td>
            <td><input type="file" name="userfile" id="userfile" tabindex="14"></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Contact Address</font></span></td>
            <td width="205"><input name="address" type="text" id="address" tabindex="5"></td>
            <td width="85" bgcolor="#006600"><span class="style1"><font face="Agency FB">Amount</font></span></td>
            <td><label>
              <input name="amount" type="text" id="amount">
            </label></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600"><span class="style1"><font face="Agency FB">Phone Number</font></span></td>
            <td width="205"><input name="phone" type="text" id="phone" onKeyPress="return checkIt(event)" tabindex="6"></td>
            <td width="99" bgcolor="#006600"><font face="Agency FB" class="style1">Semester</font></td>
            <td><label>
            <select name="semester" id="semester" tabindex="13">
              <option>FIRST</option>
              <option>SECOND</option>
                                    </select>
            </label></td>
          </tr>
          <tr> 
            <td width="99" bgcolor="#006600">&nbsp;</td>
            <td width="205">&nbsp;</td>
            <td width="85">&nbsp;</td>
            <td><span class="style1"><font face="Agency FB" color="#FF0000">The size of the picture must not be more than </font></span><strong><font face="Agency FB" color="#FF0000">40</font></strong><span class="style1"><font face="Agency FB" color="#FF0000">kb of type jpg </font></span></td>
          </tr>
		  <tr>          </tr>
		  <tr> 
            <td width="99" bgcolor="#006600">&nbsp;</td>
            <td width="205">&nbsp;</td>
            <td width="85">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  <tr> 
            <td width="99" bgcolor="#006600">&nbsp;</td>
            <td width="205">&nbsp;</td>
            <td width="85">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        <p align="center"> 
          <input type="submit" value="SUBMIT" name="B1" style="font-weight: 700">
          &nbsp;&nbsp;&nbsp; 
          <input type="reset" name="Reset" value="Reset">
        </p>
      </form>
    &nbsp;All fields are mandatory, except &quot;Othernames&quot;.
      <p><font size="2"><b> 
      </b></font></p></td>
  </tr>
  
  <tr> 
    <td height="19" colspan="2" bgcolor="#008000"> <p align="center"></td>
    <td bgcolor="#FFFF00">&nbsp; </td>
  </tr>
</table>

</body>

</html>
<?php
}
?>