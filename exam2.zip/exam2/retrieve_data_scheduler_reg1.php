<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST</title>
<style type="text/css">
<!--
.style1 {
	color: #003399;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
</head>

<body bgcolor="#CC99FF">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
  <tr bgcolor="#000000"> 
    <td colspan="5"> <p align="right"> <b><font size="2" color="#008000"> <a href="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/help.html"> 
        </a></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;GO 
        BACK</font></a></font></b></p>
      <p align="center"> <font size="5">&nbsp;</font><b><font size="5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <font color="#0000FF" face="Copperplate Gothic Bold"><u>REGISTRATION RECORDS</u></font></font></b></td>
  </tr>
  <tr> 
    <td width="49%" valign="top" bgcolor="#808000" colspan="3"><u> <font color="#FFFFFF"><b>RETRIEVE 
      REGISTRATION RECORDS</b></font></u></td>
    <td width="50%" valign="top">&nbsp; </td>
    <td width="1%" bgcolor="#000000" rowspan="10">&nbsp;</td>
  </tr>
  <tr> 
    <td width="369" height="48" colspan="2" valign="top" bgcolor="#0033CC">&nbsp;<font size="2"><b><u><font color="#00FF00"><a href="form.php"><font color="#00FF00">ADMISSION LETTER &gt;&gt;</font></a></font></u></b></font>
      <p><font size="2"><b>&nbsp;<u><font color="#00FF00"><a href="retrieve_data_scheduler_reg.php"><font color="#00FF00">REGISTRATION RECORDS &gt;&gt;</font></a></font></u></b></font></p>
      <p>
	<font size="2"><b>&nbsp;<u><font color="#00FF00"><a href="test_results.php"><font color="#00FF00">TEST RESULTS &gt;&gt;</font></a></font></u></b></font></p>
	  <p><font size="2"><b><a href="retrieve_data_scheduledtests.php">&nbsp;<u><font color="#00FF00"><font color="#00FF00">SCHEDULED 
        TESTS &gt;&gt;</font></font></u></a><br>
	&nbsp; </b></font></p></td>
    <td width="37%" height="48" colspan="2" valign="top" bgcolor="#CC99FF">&nbsp;</td>
  </tr>
  <tr> 
    <td width="75%" height="47" colspan="4" valign="top" bgcolor="#CC99FF">&nbsp;
      <form method="POST" action="sh_all_registration_records.php">
        <p align="center"> 
          <input type="submit" value="SHOW ALL STUDENTS REGULAR REGISTRATION RECORDS" name="B1">
        </p>
      </form></td>
  </tr>
  <tr> 
    <td width="49%" valign="top" height="19" bgcolor="#0033CC" colspan="3">&nbsp; </td>
    <td width="50%" valign="top" height="19" bgcolor="#0033CC">&nbsp;</td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="19" colspan="4" bgcolor="#000000"> <font color="#FFFF00">&nbsp;SEARCH 
      BY NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SEARCH 
      BY REG. DATE</font></td>
  </tr>
  <tr> 
    <td width="47%" valign="top" height="140"> <form method="POST" action="searchname_registration.php">
        <p><b>SURNAME</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="surname" size="20">
          <br>
          <b>FIRST NAME</b>&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="first_name" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B2">
        </p>
      </form>
      <p></td>
    <td width="2%" valign="top" height="140" rowspan="5" bgcolor="#000000" colspan="2">&nbsp;</td>
    <td width="50%" valign="top" height="140"><form method="POST" action="searchdate_registration.php">
        <p><font color="#000000"><b>DATE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font>
          <input name="date" type="text" id="date">
          <span class="style1">yyyy-mm-dd</span><br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;<br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
  </tr>
  <tr> 
    <td width="47%" valign="top" height="38" bgcolor="#000000">&nbsp;<font color="#FFFF00">SEARCH 
      BY REG. NUMBER</font></td>
    <td width="50%" valign="top" height="38" bgcolor="#000000">&nbsp;<font color="#FFFF00">SEARCH 
      BY COURSE</font></td>
  </tr>
  <tr> 
    <td width="47%" valign="top" height="120"> <form method="POST" action="searchregno_registration.php">
        <p><b>REG. NUMBER</b>&nbsp;&nbsp; 
          <input type="text" name="reg_no" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form>
	  J</td>
    <td width="50%" height="-3" valign="top"><form method="POST" action="searchcourse_registration.php">
        <p><b>COURSE</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="course" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
  </tr>
  <tr>
    <td height="35" valign="top" bgcolor="#000000"><font color="#FFFF00">SEARCH 
    BY DEPARTMENT </font></td>
    <td width="50%" height="-1" valign="top" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" height="242"><form method="POST" action="searchdepartment_registration.php">
      <p align="left"><b>DEPARTMENT</b>&nbsp;&nbsp;
        <select name="department" id="department" tabindex="5">
    <?php 
include('dbconnect.php');


$query3 = "SELECT distinct department FROM departments_table order by department";
$result3 = mysql_query($query3);

echo "<option selected></option>";
while ($row = mysql_fetch_array($result3, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{

echo "<option value>";
echo "$value" . "</br>";
echo "</option>";

}}?>

   
  </select>
        <br>
        <input type="submit" value="SEARCH" name="B32">
      </p>
    </form></td>
    <td width="50%" height="242" valign="top">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="5" bgcolor="#000000"> <p align="center"></td>
  </tr>
</table>

</body>

</html>