<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>DataMix TEST ENGINE</title>
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

</style>
<bgsound src="swordraw.wav" loop="1">

<meta http-equiv="Page-Enter" content="revealTrans(Duration=5.0,Transition=3)">

</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="101%" height="100%">
  <tr> 
    <td height="41" colspan="12" bgcolor="#000000"> <font face="Bodoni MT Black" color="#FFFFFF">&nbsp;      TEST ENGINE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </font> <font face="Arial Narrow" color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <b><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </font></b></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"> 
      <font color="#FF0000">&lt;&nbsp;RETURN</font></a></font></td>
  </tr>
  <tr> 
    <td height="27" colspan="12" bgcolor="#808080"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <font size="4"> DATABASE OUTPUT</font></b></td>
  </tr>
  <tr> 
    <td width="1%" bgcolor="#000000" valign="top" rowspan="5">&nbsp; </td>
    <td height="19" colspan="8" valign="top" bgcolor="#CCCCCC"> <p align="center"><font size="4" face="Copperplate Gothic Bold"><u><b>INCOME 
        REPORT</b></u>&nbsp;&nbsp;&nbsp;&nbsp; date: 
        <?php 
$month=$_POST['month'];
$day=$_POST['day'];
$year=$_POST['year'];
		?>
        DATE: <font size = "+1"><?php echo "$day";  ?>/<?php echo "$month";  ?>/<?php echo "$year";  ?> </font> &nbsp;&nbsp; 
         </font></p></td>
    <td width="5%" bgcolor="#000000" valign="top" rowspan="5">&nbsp; </td>
    <td width="2%" bgcolor="#808080" valign="top" rowspan="5">&nbsp; </td>
  </tr>
  <tr> 
    <td height="225" colspan="8" valign="top" bgcolor="#FFFFFF"> 
      <p> 
        <?php
$month=$_POST['month'];
$day=$_POST['day'];
$year=$_POST['year'];

		
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

// QUERIES FOR SUM OF SCHOOL FEES
$query =mysql_query("select sum(amount_paid) from registration_table where reg_month = '$month'  and reg_day >= '$day' and reg_year >= '$year'");
$total_fees =mysql_result($query, 0, "sum(amount_paid)"); 



// TOTAL SUM OF EXPENDITURES
$query_exp =mysql_query("select sum(amount) from account_records where month = '$month'  and day >= '$day' and year >= '$year'");
$total_exp =mysql_result($query_exp, 0, "sum(amount)"); 

// PROFFIT

$proffit = $total_fees - $total_exp ;

?>
        <font face="Terminal" color="#000000"><strong><br>
        </strong></font></p>
      <table width="100%" border="1">
        <tr> 
          <td bgcolor="#000000"><font color="#0099FF"><strong>INCOME</strong></font></td>
          <td bgcolor="#000000"><font color="#0066FF"><strong>EXPENDITURE</strong></font></td>
        </tr>
        <tr> 
          <td height="89" valign="middle"> 
            <p>&nbsp;</p>
            <p>TRAINING<br>
              FEES =N<?php echo "$total_fees"; ?></p>
            <p>&nbsp;</p></td>
          <td valign="middle">TOTAL SUM OF<br>
            EXPENDITURES =N<?php echo "$total_exp"; ?></td>
        </tr>
        <tr> 
          <td height="23">&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <p> <b> </b><u><b><br>
        </b></u><font color="#000000"> </font></p>
      </td>
  </tr>
  <tr> 
    <td height="44" colspan="8" valign="top" bgcolor="#CCCCCC">&nbsp;<strong>PROFFIT 
      = N<?php echo "$proffit"; ?></strong></td>
  </tr>
  <tr> 
    <td height="26" colspan="8" valign="top" bgcolor="#00FFFF">
<p><font size="3" face="Verdana, Arial, Helvetica, sans-serif"> The above is a 
        statement of the calculated income, expenditures and proffit for your 
        organisation. <br>
        </font></p>
      </td>
  </tr>
  <tr> 
    <td colspan="8" valign="top" bgcolor="#CCCCCC">&nbsp; </td>
  </tr>
  <tr> 
    <td height="26" bgcolor="#808080" colspan="12"><FORM>
        <p align="center"> 
          <input name="button" type="button" onClick="window.print()" value="PRINT OUT">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        </p>
      </FORM>
      &nbsp;</td>
  </tr>
  <tr> 
    <td height="26" width="1%" bgcolor="#000000">&nbsp;</td>
    <td height="26" bgcolor="#000000" colspan="10">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <font color="#FFFFFF">&nbsp;&nbsp;&nbsp; <font color="#999999">Technology 
      by</font>&nbsp; </font> <font color="#00FF00">B-Low Solutions, Inc &nbsp; ( 
      </font> <font color="#999999">08039098042</font><font color="#00FF00">)</font></td>
    <td height="26" width="5%" bgcolor="#000000">&nbsp;</td>
  </tr>
</table>

</body>

</html>
<?php
}
?>