<?php
// THIS CODE CHECKS IF THE SPECIFIED REG.NO DOES NOT EXIST
  $reg_no = $_POST['reg_no'];
  
if (isset($_POST['reg_no'])) {
 include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


$queryx1="SELECT reg_no FROM registration_table WHERE reg_no = '$reg_no'";
$resultx1=mysql_query($queryx1);

if (mysql_num_rows($resultx1) == 0) {
header('Location: reg_does_not_exist.php');
mysql_close($link);
} 
else 
{

session_start();
$_SESSION['reg_no'] = $_POST['reg_no'];
session_register('reg_no'); 


//******************** EXTRACT THE REQUIRED DATA




// RETRIEVE CANDIDATE'S SURNAME

$query =mysql_query("select surname from registration_table where reg_no = '$reg_no'");
$surname =mysql_result($query, 0, "surname");


// RETRIEVE CANDIDATE'S FIRST NAME

$query2 =mysql_query("select first_name from registration_table where reg_no = '$reg_no'");
$firstname =mysql_result($query2, 0, "first_name");


// RETRIEVE CANDIDATE'S OTHERNAME

$query3 =mysql_query("select othernames from registration_table where reg_no = '$reg_no'");
$othernames =mysql_result($query3, 0, "othernames");


$fullname = $surname."&nbsp;".$othernames."&nbsp;".$firstname;



// RETRIEVE CANDIDATE'S REG NUMBER

$query4 =mysql_query("select reg_no from registration_table where reg_no = '$reg_no'");
$reg_no =mysql_result($query4, 0, "reg_no");



// RETRIEVE CANDIDATE'S BATCH NO

$query5 =mysql_query("select batch from registration_table where reg_no = '$reg_no'");
$batch_no =mysql_result($query5, 0, "batch");


// RETRIEVE CANDIDATE'S TRAINER

$query6 =mysql_query("select trainer from registration_table where reg_no = '$reg_no'");
$trainer =mysql_result($query6, 0, "trainer");



// RETRIEVE CANDIDATE'S COURSE

$query7 =mysql_query("select course from registration_table where reg_no = '$reg_no'");
$course =mysql_result($query7, 0, "course");


// RETRIEVE CANDIDATE'S GENDER

$query8 =mysql_query("select gender from registration_table where reg_no = '$reg_no'");
$sex =mysql_result($query8, 0, "gender");


// RETRIEVE CANDIDATE'S REG DATE

$query9 =mysql_query("select reg_date from registration_table where reg_no = '$reg_no'");
$reg_date =mysql_result($query9, 0, "reg_date");


// RETRIEVE CANDIDATE'S PASSWORD

$query10 =mysql_query("select password from registration_table where reg_no = '$reg_no'");
$password =mysql_result($query10, 0, "password");








// RETRIEVE CANDIDATE'S DEPARTMENT

$query2a =mysql_query("select department from registration_table where reg_no = '$reg_no'");
$department =mysql_result($query2a, 0, "department");


// RETRIEVE CANDIDATE'S CLASSROOM

$query2b =mysql_query("select classroom from registration_table where reg_no = '$reg_no'");
$classroom =mysql_result($query2b, 0, "classroom");






?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>E-TEST ::: Student File</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style1 {	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
</head>

<body background = "images/reg_stuff.jpg">
<table width="98%" height="836" border="1">
  <tr> 
    <td height="28" colspan="5" bgcolor="#003300"><p align="center"><strong><font color="#FFFFFF" size="5">B-Low Solutions, Inc </font></strong></p>
      <p align="right"><b><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;back</font></a></font></b></p></td>
  </tr>
  <tr> 
    <td height="37" colspan="5" bgcolor="#00FF00"><div align="center"><strong><font size="5">STUDENT 
        FILE </font></strong></div></td>
  </tr>
  <tr> 
    <td width="1%" rowspan="4" bgcolor="#003300"> <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    <p>&nbsp;</p></td>
    <td width="15%" height="31" valign="top" bgcolor="#CCCCCC"><strong>PICTURE</strong></td>
    <td colspan="2" bgcolor="#000000"><strong><font color="#FFFFFF">REGISTRATION 
      DATA</font></strong></td>
    <td width="1%" rowspan="4" bgcolor="#003300">&nbsp;</td>
  </tr>
  <tr> 
    <td height="289" valign="top" bgcolor="#00FF00"> 
      <p>&nbsp; </p>
      <p>&nbsp;
	  <?php
	  $reg_no = $_POST['reg_no'];
	  //echo "<img src = 'pix/$reg_no.jpg' height = '200' width = '200'>";
	  echo "No picture available";
	  ?>
	  </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp; </p></td>
    <td colspan="2" rowspan="2" valign="top" bgcolor="#FFFFFF"><h2><?php echo "$fullname"; ?></h2>
      </p>
      <form method="POST" action="modify_students_data_script.php" onSubmit="return formCheck(this);">
        <input type="hidden" name="move_reg" value="$reg_no">
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bordercolorlight="#000099" bordercolordark="#000080">
          <tr>
            <td width="97" bgcolor="#006600"><span class="style1"><font face="Agency FB">First 
              Name</font></span></td>
            <td width="179" bgcolor="#B9BBC5"><input name="firstname" type="text" id="firstname" tabindex="1" value="<?php echo "$firstname"; ?>" size="25" disabled="disabled"></td>
            <td width="103" bgcolor="#006600"><span class="style1"><font face="Agency FB">Trainer</font></span></td>
            <td width="210" bgcolor="#CCCCCC"><input name="trainer" type="text" id="trainer" tabindex="7" value="<?php echo "$trainer"; ?>" size="35"></td>
          </tr>
          <tr>
            <td width="97" bgcolor="#006600"><span class="style1"><font face="Agency FB">Surname</font></span></td>
            <td width="179" bgcolor="#B9BBC5"><input name="surname" type="text" id="surname" tabindex="2" value="<?php echo "$surname"; ?>" size="25"></td>
            <td width="103" bgcolor="#006600"><span class="style1">Course</span></td>
            <td bgcolor="#B9BBC5"><input name="course" type="text" id="course" value="<?php echo "$course"; ?>" size="30" tabindex="8"></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Othernames</font></span></td>
            <td bgcolor="#B9BBC5"><input name="othernames" type="text" id="othernames" tabindex="3" value="<?php echo "$othernames"; ?>" size="25"></td>
            <td bgcolor="#006600"><span class="style1">Gender</span></td>
            <td bgcolor="#B9BBC5"><input name="gender" type="text" id="gender" value="<?php echo "$sex"; ?>" size="30" tabindex="8"></td>
          </tr>
          <tr>
            <td width="97" bgcolor="#006600"><span class="style1"><font face="Agency FB">Reg. No</font></span></td>
            <td width="179" bgcolor="#B9BBC5"><input name="reg_no" type="text" id="reg_no" tabindex="3" value="<?php echo "$reg_no"; ?>" size="25"></td>
            <td width="103" bgcolor="#006600"><span class="style1"><font face="Agency FB">Reg Date </font></span></td>
            <td bgcolor="#B9BBC5"><input name="reg_date" type="text" id="reg_date" tabindex="3" value="<?php echo "$reg_date"; ?>" size="25"></td>
          </tr>
          <tr>
            <td width="97" bgcolor="#006600"><span class="style1"><font face="Agency FB">Department</font></span></td>
            <td width="179" bgcolor="#B9BBC5"><input name="department" type="text" id="department" tabindex="3" value="<?php echo "$department"; ?>" size="25"></td>
            <td width="103" bgcolor="#006600"><span class="style1">Password</span></td>
            <td bgcolor="#B9BBC5"><input name="password" type="text" id="password" tabindex="3" value="<?php echo "$password"; ?>" size="25"></td>
          </tr>
          <tr>
            <td width="97" bgcolor="#006600"><span class="style1"><font face="Agency FB">Batch No </font></span></td>
            <td width="179" bgcolor="#B9BBC5"><input name="batch_no" type="text" id="batch_no" tabindex="3" value="<?php echo "$batch_no"; ?>" size="25"></td>
            <td width="103" bgcolor="#006600">&nbsp;</td>
            <td bgcolor="#B9BBC5">&nbsp;</td>
          </tr>
          <tr>
            <td width="97" bgcolor="#006600"><span class="style1">Classroom</span></td>
            <td width="179" bgcolor="#B9BBC5"><input name="classroom" type="text" id="classroom" tabindex="3" value="<?php echo "$classroom"; ?>" size="25"></td>
            <td width="103" bgcolor="#006600">&nbsp;</td>
            <td bgcolor="#B9BBC5">&nbsp;</td>
          </tr>
        </table>
        <p align="left">
          <input type="submit" value="SAVE CHANGE" name="B1" style="font-weight: 700">
          &nbsp;&nbsp;&nbsp;
          <input type="reset" name="Reset" value="Reset">
        </p>
      </form>
      </p>
      <p>&nbsp;</p>
      <table width="100%" border="0">
        <tr>
          <td bgcolor="#000000"><strong><font color="#FFFFFF">TEST RESULTS </font></strong></td>
        </tr>
      </table>
      <p>
	  <?php
	  $queryv = ("SELECT TEST_TYPE, TEST_DATE, COURSE, MAX_QUESTIONS, NO_RIGHT 'NO. PASSED', SCORE 'TEST_SCORE', MAX_SCORE, GRADE FROM test_records WHERE reg_no = '$reg_no'");
	  
	$resultv = mysql_query($queryv)
or die (mysql_error());
$num_fields = mysql_num_fields($resultv);

if(mysql_num_rows($resultv) == 0)
{
echo "No results recorded";
}
else
{
//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($resultv, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($resultv, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
}
	  
	  
	  
	  ?>
	  
	  </p>
      <p>&nbsp;</p>
      <table width="100%" border="0">
        <tr>
          <td bgcolor="#000000"><strong><font color="#FFFFFF">COMPUTED RESULT </font></strong></td>
        </tr>
      </table></p>
      <p>
        <?php
	  $queryy = ("SELECT COURSE 'COURSE', TOTAL 'TOTAL SCORE', GRADE 'FINAL GRADE' FROM compute_results WHERE reg_no = '$reg_no'");
$resulty = mysql_query($queryy)
or die (mysql_error());
$num_fields = mysql_num_fields($resulty);

if(mysql_num_rows($resulty) == 0)
{
echo "Student has not taken Exam, so the total result is not yet computed";
}
else
{	  

//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($resulty, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($resulty, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
}
	  
	  
	  
	  ?>
      </p>
      <p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td height="358" valign="top" bgcolor="#00FF00"><p><strong>COURSE(S) REGISTERED</strong></p>
      <p>
        <?php
	  $queryv = ("SELECT COURSE  FROM registration_table WHERE reg_no = '$reg_no' order by COURSE");
	$resultv = mysql_query($queryv)
or die (mysql_error());
$num_fields = mysql_num_fields($resultv);


echo "<table border = 0>";


//create table body

echo "<tr>";
while ($row = mysql_fetch_array($resultv, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

	  
//session_destroy();	  
	}}}  
	  ?>
    </p></td>
  </tr>
  <tr> 
    <td height="23" valign="top" bgcolor="#003300">&nbsp;</td>
    <td width="29%" bgcolor="#003300">&nbsp;</td>
    <td width="54%" bgcolor="#003300">&nbsp;</td>
  </tr>
</table>
<p><FORM>
        <p align="center">
          <input name="button" type="button" onClick="window.print()" value="PRINT OUT">
  </p>
      </FORM>&nbsp;</p></body>
</html>
