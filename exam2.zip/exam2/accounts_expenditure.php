<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>DataMix TEST ENGINE</title>
<meta http-equiv="Page-Enter" content="blendTrans(Duration=5.0)">
</head>

<body background="images/bg9.jpg">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("month","day","year","pv_number", "particulars","description","amount");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("MONTH","DAY","YEAR","ITEM", "SHIFT","QUANTITY RECEIVED","REFERENCE NUMBER");
	// dialog message
	var alertMsg = "Please complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>


<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
  <tr bgcolor="#330000"> 
    <td colspan="4"> 
      <p align="left"><form action="logout.php" method="post" name="form1" target="_parent">
  <div align="right">
          <input type="submit" name="Submit" value="Logout">
        </div>
      </form>
        
      <div align="center"><b><font size="5"><font color="#FF9900" face="Copperplate Gothic Bold"><u>ACCOUNTS 
        UNIT</u></font></font></b></div></td>
  </tr>
  <tr> 
    <td width="19%" rowspan="3" valign="top" bgcolor="#000000"><p>&nbsp;</p>
      <p><a href="accounts_expenditure.php"><img border="0" src="images/rec_exp.jpg" width="171" height="31"></a></p>
      <p> <a href="sales_report.php"><img border="0" src="images/income_report.jpg" width="171" height="31"></a></p>
      <p><a href="retrieve_data_scheduler.php"><img src="images/retrievedata_bt.jpg" width="178" height="31" border="0"></a></p>
      <p><a href="print_cert_page.php"><img src="images/print_cert_butt.jpg" width="178" height="31" border="0"></a></p>
      <p>&nbsp; </p>
      <table width="88%" border="1" cellpadding="0" cellspacing="0" bordercolorlight="#000080" bordercolordark="#00FFFF" style="border-collapse: collapse" dwcopytype="CopyTableRow">
        <tr bgcolor="#666666"> 
          <td colspan="5" bordercolor="#00FFFF"><font color="#FFFFFF" size="2">LISTED 
            ITEMS</font></td>
        </tr>
        <tr bgcolor="#000000"> 
          <td width="2%" rowspan="3">&nbsp;</td>
          <td width="3%" rowspan="3">&nbsp;</td>
          <td height="24" width="87%"> <font color="#000080"><font color="#FFFFFF" size="2">&nbsp;Below 
            are the accounting items. Accounting records must be saved using one 
            of these items, else it will not save.</font> </font></td>
          <td width="2%" rowspan="3">&nbsp;</td>
          <td width="6%" rowspan="3">&nbsp;</td>
        </tr>
        <tr> 
          <td height="42" width="87%" bgcolor="#00FFFF"> 
            <?php 
 
  
//most sites have magic quotes on
//but if they do not, this code simulates magic quotes
if( !get_magic_quotes_gpc() )
{
    if( is_array($_POST) )
        $_POST = array_map('addslashes', $_POST);
}



include ('dbconnect.php');

if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
    mysql_select_db('datamix');
	
 $query = "SELECT item FROM account_items";
			  //echo $query . "<br>\n";
          	
			$result = mysql_query($query);
			
$num_fields = mysql_num_fields($result);

//create table body
echo "<table border = 1>";

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
}
	          mysql_close($link); 	  

?>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#000000" width="87%">&nbsp;</td>
        </tr>
      </table></p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><br>
        &nbsp;</td>
    <td width="2%" rowspan="3" valign="top" bgcolor="#330000"> <p align="center"></td>
    <td width="77%" height="426" valign="top"> 
      <form name="checkin_form" method="POST" action="insert_accounts_expenditure.php" onSubmit="return formCheck(this);">
        <font face="Copperplate Gothic Bold"> 
        <p> </font> 
        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
          <tr> 
            <td bgcolor="#000000"><b> <font color="#FFFFFF"> 
              <marquee>
              Record the expenditure below 
              </marquee>
              </font></b></td>
          </tr>
          <tr> 
            <td bgcolor="#800000"><font color="#FFFFFF"><b>EXPENDITURE </b></font></td>
          </tr>
        </table>
        <p> <b> <font color="#000000" face="Verdana">DATE</font></b><font face="Verdana">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          </font> </font><em> <font face="Arial, Helvetica, sans-serif" color="#FF0000" size="1"> 
          <b><font face="Verdana"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font>
          <select name="day" id="day">
            <option selected></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
          &nbsp;</b>
          <select name="month" id="month" style="width:49; height:22">
            <option selected></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
          </select>
          <select name="year" id="select2">
            <option selected></option>
            <option value="2000">2000</option>
            <option value="2001">2001</option>
            <option value="2002">2002</option>
            <option value="2003">2003</option>
            <option value="2004">2004</option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
            <option value="2028">2028</option>
            <option value="2029">2029</option>
            <option value="2030">2030</option>
            <option value="2031">2031</option>
            <option value="2032">2032</option>
            <option value="2033">2033</option>
            <option value="2034">2034</option>
            <option value="2035">2035</option>
            <option value="2036">2036</option>
            <option value="2037">2037</option>
            <option value="2038">2038</option>
            <option value="2039">2039</option>
            <option value="2040">2040</option>
            <option value="2041">2041</option>
            <option value="2042">2042</option>
            <option value="2043">2043</option>
            <option value="2044">2044</option>
            <option value="2045">2045</option>
            <option value="2046">2046</option>
            <option value="2047">2047</option>
            <option value="2048">2048</option>
            <option value="2049">2049</option>
            <option value="2050">2050</option>
            <option value="2051">2051</option>
            <option value="2052">2052</option>
            <option value="2053">2053</option>
            <option value="2054">2054</option>
            <option value="2055">2055</option>
            <option value="2056">2056</option>
            <option value="2057">2057</option>
            <option value="2058">2058</option>
            <option value="2059">2059</option>
            <option value="2059">2060</option>
            <option value="2061">2061</option>
            <option value="2062">2062</option>
            <option value="2063">2063</option>
            <option value="2064">2064</option>
            <option value="2065">2065</option>
            <option value="2066">2066</option>
            <option value="2067">2067</option>
            <option value="2068">2068</option>
            <option value="2069">2069</option>
            <option value="2070">2070</option>
            <option value="2071">2071</option>
            <option value="2072">2072</option>
            <option value="2073">2073</option>
            <option value="2074">2074</option>
            <option value="2075">2075</option>
            <option value="2076">2076</option>
            <option value="2077">2077</option>
            <option value="2078">2078</option>
            <option value="2079">2079</option>
            <option value="2080">2080</option>
            <option value="2081">2081</option>
            <option value="2082">2082</option>
            <option value="2083">2083</option>
            <option value="2084">2084</option>
            <option value="2085">2085</option>
            <option value="2086">2086</option>
            <option value="2087">2087</option>
            <option value="2088">2088</option>
            <option value="2089">2089</option>
            <option value="2090">2090</option>
          </select>
          &nbsp;</font></em><font face="Arial, Helvetica, sans-serif"><b><font face="Arial, Helvetica, sans-serif" color="#FF0000" size="1"> 
          </font></b> </font><b></p>
        </b></font>
          <font color="#FF0000" face="Copperplate Gothic Bold">
        <p> 
		<strong> <font color="#000000" face="Verdana" size="3">
		PV. 
		NUMBER</font></strong><b><font face="Verdana">&nbsp; 
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input name="pv_number" size="12" style="font-weight: 700"> 
          </font> 
          </b>
        </p><font face="Verdana">
        <p><b>&nbsp;</b></font><b><font color="#000000" face="Verdana">PARTICULARS</font></b></font></em><b><font color="#FF0000" face="Copperplate Gothic Bold">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</font><font face="Verdana">
		&nbsp;<!--webbot bot="Validation" s-data-type="String" b-allow-letters="TRUE" b-allow-whitespace="TRUE" --><input name="particulars" size="19" style="font-weight: 700"></font></em></font></b><em><b><font face="Verdana">
		</font>
          </b>
          <font size="1" color="#FF0000" face="Verdana">(the person the money 
          was paid to)</font></p><font face="Verdana">
        <p><b>&nbsp;</b></font><b><font color="#000000" face="Verdana">DESCRIPTION</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </b>
          </em> <b> </font>
          <em>
          <font face="Verdana">
		<!--webbot bot="Validation" s-data-type="Integer" s-number-separators="," -->
		<input name="description" size="20" style="font-weight: 700">
        </p>
        </font></em></b><font face="Copperplate Gothic Bold">
        <em>
        <p> <b> <font color="#000000" face="Verdana">AMOUNT</font></b>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input name="amount" type="text" id="amount" size="20"></b></em></font><b><b><em>
          <font face="Verdana"> </font> <font face="Copperplate Gothic Bold"> 
          &nbsp;</font><font face="Verdana">Naira&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        </p></font>
        <font face="Copperplate Gothic Bold"> 
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;&nbsp; 
          <input type="submit" value="SAVE" name="submit">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="reset" value="RESET" name="reset">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        </p>
      </form></p>
      </td>
    <td width="2%" rowspan="3" valign="top" bgcolor="#330000">&nbsp; </td>
  </tr>
  <tr>
    <td valign="top" bordercolor="#330000" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top"><p><form name="form4" method="post" action="sh_all_account_expenditure_records.php">
        <p><strong>VIEW ACCOUNTING RECORDS</strong></p>
        <p> 
          <input type="submit" name="Submit5" value="VIEW EXPENDITURE RECORDS">
        </p>
      </form></p>
      <table width="100%" border="0">
        <tr>
          <td bgcolor="#000000"><font color="#FFFFFF">SPECIFIC SEARCH</font></td>
        </tr>
        <tr>
          <td bgcolor="#666666">&nbsp;</td>
        </tr>
      </table> 
      <table width="100%" border="0">
        <tr> 
          <td width="31%" valign="top"><p>SEARCH BY DATE</p>
            <p><form name="form2" method="post" action="searchdate_account.php">
        <p> 
          
			 <select name="day" id="day">
            <option selected></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
                <select name="month" id="month" style="width:49; height:22">
            <option selected></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
          </select>
          <select name="year" id="select2">
            <option selected></option>
            <option value="2000">2000</option>
            <option value="2001">2001</option>
            <option value="2002">2002</option>
            <option value="2003">2003</option>
            <option value="2004">2004</option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
            <option value="2028">2028</option>
            <option value="2029">2029</option>
            <option value="2030">2030</option>
            <option value="2031">2031</option>
            <option value="2032">2032</option>
            <option value="2033">2033</option>
            <option value="2034">2034</option>
            <option value="2035">2035</option>
            <option value="2036">2036</option>
            <option value="2037">2037</option>
            <option value="2038">2038</option>
            <option value="2039">2039</option>
            <option value="2040">2040</option>
            <option value="2041">2041</option>
            <option value="2042">2042</option>
            <option value="2043">2043</option>
            <option value="2044">2044</option>
            <option value="2045">2045</option>
            <option value="2046">2046</option>
            <option value="2047">2047</option>
            <option value="2048">2048</option>
            <option value="2049">2049</option>
            <option value="2050">2050</option>
            <option value="2051">2051</option>
            <option value="2052">2052</option>
            <option value="2053">2053</option>
            <option value="2054">2054</option>
            <option value="2055">2055</option>
            <option value="2056">2056</option>
            <option value="2057">2057</option>
            <option value="2058">2058</option>
            <option value="2059">2059</option>
            <option value="2059">2060</option>
            <option value="2061">2061</option>
            <option value="2062">2062</option>
            <option value="2063">2063</option>
            <option value="2064">2064</option>
            <option value="2065">2065</option>
            <option value="2066">2066</option>
            <option value="2067">2067</option>
            <option value="2068">2068</option>
            <option value="2069">2069</option>
            <option value="2070">2070</option>
            <option value="2071">2071</option>
            <option value="2072">2072</option>
            <option value="2073">2073</option>
            <option value="2074">2074</option>
            <option value="2075">2075</option>
            <option value="2076">2076</option>
            <option value="2077">2077</option>
            <option value="2078">2078</option>
            <option value="2079">2079</option>
            <option value="2080">2080</option>
            <option value="2081">2081</option>
            <option value="2082">2082</option>
            <option value="2083">2083</option>
            <option value="2084">2084</option>
            <option value="2085">2085</option>
            <option value="2086">2086</option>
            <option value="2087">2087</option>
            <option value="2088">2088</option>
            <option value="2089">2089</option>
            <option value="2090">2090</option>
          </select>
  
          <br>
              </p>
        <p>
          <input type="submit" name="Submit3" value="SEARCH">
          <br>
        </p>
      </form><br>
            </p></td>
          <td width="2%" bgcolor="#666666">
<p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p></td>
          <td width="33%" valign="top"><p>SEARCH BY DESCRIPTION</p>
            <form action="searchdescription_account.php" method="post" name="form3" id="form3">
        <input name="description" type="text" id="description">
        </p>
        <p>
          <input type="submit" name="Submit3" value="SEARCH">
          <br>
        </p>
      </form>&nbsp;</p></td>
          <td width="2%" bgcolor="#666666">&nbsp;</td>
          <td width="32%" valign="top"><p>SEARCH BY PV. NUMBER.</p>
            <form action="search_pv_no_account.php" method="post" name="form4" id="form4">
        <p>
          <input name="pv_no" type="text" id="pv_no">
        </p>
        <p>
          <input type="submit" name="Submit3" value="SEARCH">
          <br>
        </p>
      </form>&nbsp;</p></td>
        </tr>
      </table>
      <table width="100%" border="0">
        <tr> 
          <td colspan="3" bgcolor="#000000">&nbsp;</td>
        </tr>
        <tr> 
          <td colspan="3" bgcolor="#666666">&nbsp;</td>
        </tr>
        <tr> 
          <td width="47%" height="241">
<p>DELETE ACCOUNT RECORD</p>
            <form name="form1" method="post" action="delete_account_record.php">
              <div align="left"></div>
              <p align="left"><font size="2">Date: 
                <select name="day" id="day">
            <option selected></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
                <select name="month" id="month" style="width:49; height:22">
            <option selected></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
          </select>
          <select name="year" id="select2">
            <option selected></option>
            <option value="2000">2000</option>
            <option value="2001">2001</option>
            <option value="2002">2002</option>
            <option value="2003">2003</option>
            <option value="2004">2004</option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
            <option value="2028">2028</option>
            <option value="2029">2029</option>
            <option value="2030">2030</option>
            <option value="2031">2031</option>
            <option value="2032">2032</option>
            <option value="2033">2033</option>
            <option value="2034">2034</option>
            <option value="2035">2035</option>
            <option value="2036">2036</option>
            <option value="2037">2037</option>
            <option value="2038">2038</option>
            <option value="2039">2039</option>
            <option value="2040">2040</option>
            <option value="2041">2041</option>
            <option value="2042">2042</option>
            <option value="2043">2043</option>
            <option value="2044">2044</option>
            <option value="2045">2045</option>
            <option value="2046">2046</option>
            <option value="2047">2047</option>
            <option value="2048">2048</option>
            <option value="2049">2049</option>
            <option value="2050">2050</option>
            <option value="2051">2051</option>
            <option value="2052">2052</option>
            <option value="2053">2053</option>
            <option value="2054">2054</option>
            <option value="2055">2055</option>
            <option value="2056">2056</option>
            <option value="2057">2057</option>
            <option value="2058">2058</option>
            <option value="2059">2059</option>
            <option value="2059">2060</option>
            <option value="2061">2061</option>
            <option value="2062">2062</option>
            <option value="2063">2063</option>
            <option value="2064">2064</option>
            <option value="2065">2065</option>
            <option value="2066">2066</option>
            <option value="2067">2067</option>
            <option value="2068">2068</option>
            <option value="2069">2069</option>
            <option value="2070">2070</option>
            <option value="2071">2071</option>
            <option value="2072">2072</option>
            <option value="2073">2073</option>
            <option value="2074">2074</option>
            <option value="2075">2075</option>
            <option value="2076">2076</option>
            <option value="2077">2077</option>
            <option value="2078">2078</option>
            <option value="2079">2079</option>
            <option value="2080">2080</option>
            <option value="2081">2081</option>
            <option value="2082">2082</option>
            <option value="2083">2083</option>
            <option value="2084">2084</option>
            <option value="2085">2085</option>
            <option value="2086">2086</option>
            <option value="2087">2087</option>
            <option value="2088">2088</option>
            <option value="2089">2089</option>
            <option value="2090">2090</option>
          </select>   </font></p>
              <p><font size="2">PV.no</font><font size="2">: 
                <input name="pv_no" type="text" id="pv_no" size="12">
                </font></p>
              <p> 
                <input type="submit" name="Submit" value="DELETE">
                <input type="reset" name="Submit2" value="RESET">
              </p>
            </form></p>
            <p>&nbsp;</p></td>
          <td width="2%">&nbsp;</td>
          <td width="51%" valign="top">
<form method="POST" action="create_new_accountable_item.php">
              <!--webbot bot="SaveResults" U-File="fpweb:///_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
              CREATE NEW ACCOUNTABLE ITEM 
              <div align="left"><font face="Verdana" size="2"> <br>
                <br>
                ITEM NAME&nbsp;&nbsp;&nbsp;&nbsp; </font> &nbsp; 
                <input type="text" name="new" size="20">
              </div>
        <p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="Create Item" name="B16">
          &nbsp;&nbsp;&nbsp; 
          <input type="reset" value="Reset" name="B17">
        </p>
      </form>&nbsp;</td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
  
  <tr bgcolor="#330000"> 
    <td colspan="4"> <p align="center"><b><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <font color="#FFFF00">Technology by </font><font color="#FFFFFF">B-Low Solutions, Inc </font> <font color="#FFFF00">(08039098042)</font></font></b></td>
  </tr>
</table>

</body>

</html>