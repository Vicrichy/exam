<?php

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

// DECLARE THE VARIABLES.

$course=$_POST['course'];
//$course_type =$_POST['course_type'];
$question_text=$_POST['question_text'];
$option_a=$_POST['option_a'];
$option_b=$_POST['option_b'];
$option_c=$_POST['option_c'];
$option_d=$_POST['option_d'];
$correct_option=$_POST['correct_option'];

include('dbconnect.php');

// CHECK IF THE COURSE EXISTS

$query2="Select course from course_list where course = '$course'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) == 0 ) {
header('Location: course_does_not_exist.php');
mysql_close($link);
} 
else 
{
$query_cc = mysql_query("SELECT course from course_list where course = '$course'");
$query_course = mysql_result($query_cc, 0, "course");

$query_coursecode = $query_course;


mysql_query("INSERT INTO $query_coursecode(question,A,B,C,D,correct)VALUES('$question_text','$option_a','$option_b','$option_c','$option_d','$correct_option')");

?>
<html>
<script type="text/javascript">
var answer = confirm("Do you wish to insert another question?")
	if (answer){
		window.location = "manage_questions.php";
	}
	else{
		window.location = "manage_courses.php";
	}
</script>
<?php
}
}
?> 