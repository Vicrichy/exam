<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="966" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="247" height="70">&nbsp;</td>
    <td width="488">&nbsp;</td>
    <td width="231">&nbsp;</td>
  </tr>
  <tr>
    <td height="183">&nbsp;</td>
    <td valign="top"><p class="style1">Please Enter Finance Password to view receipts </p>
      <form id="form1" name="form1" method="post" action="process_finance.php">
        <table width="270" align="center">
          <tr>
            <td width="98">Password</td>
            <td width="216"><label>
              <input name="password" type="text" id="password" />
            </label></td>
          </tr>
          <tr>
            <td colspan="2"><label>
              <input type="submit" name="Submit" value="Submit" />
            </label></td>
          </tr>
        </table>
      </form>      <p class="style1">&nbsp;</p></td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
