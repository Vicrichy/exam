<?php

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

$course_code =$_POST['course_code'];
$course_name =$_POST['course_name'];
//$credit_load =$_POST['credit_load'];
//$course_cost =$_POST['course_cost'];


// CHECK IF THE COURSE EXISTS
include('dbconnect.php');
$query2="Select course from course_list where course = '$course_code'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) > 0 ) {
header('Location: course_already_exists.php');
mysql_close($link);
} 
else 
{
include('dbconnect.php');

mysql_query("INSERT INTO course_list(course,course_code)VALUES('$course_code','$course_name')");

$sql = "CREATE TABLE $course_code ( id int(20) NOT NULL auto_increment, question text NOT NULL default '', A text NOT NULL default '',B text NOT NULL default '',C text NOT NULL default '',D text NOT NULL default '',correct text NOT NULL default '',KEY id (id)) TYPE=MyISAM AUTO_INCREMENT=1 ;";

 $result = mysql_query($sql);
?>

<html>
<script type="text/javascript">
var answer = confirm("Do you wish to create another course?")
	if (answer){
		window.location = "create_courses.php";
	}
	else{
		window.location = "manage_courses.php";
	}
</script>
<?php
}
}

?>