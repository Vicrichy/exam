<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] == 100 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
?><?php
$max_questions = 5;
include('dbconnect.php');

$query =mysql_query("select count(id) from `user_question` where `username` = 
'$reg_no' and `answered` = 'YES'");
$question_query = @mysql_result($query, 0, "count(id)");
$question_count = $question_query;
$display_no = $question_query + 1;

//$display_no = $_SESSION['display_no'];
if(($display_no) > ($max_questions))
{
 header("location:test_over.php");
}
 
include ('dbconnect.php');

$question_count = 0 ;
// EXTRACT SYSTEM DATE
$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";
$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
// SELECT MAX QUESTION SET FOR THE CANDIDATE
$query_max_questions = 5;
// SELECT MAX TIME SET FOR THE CANDIDATE
$query_max_time = 10;
?>
<html>
<script type="text/javascript">
alert("YOU HAVE 10 MINUTES TO ANSWER ALL QUESTIONS");
alert("WARNING: DO NOT CLOSE THIS WINDOW TILL YOU HAVE FINISHED AND SUBMITTED YOUR ANSWERS!!");
</script>
<head>
<script language='javascript'>
//disable right-click
document.oncontextmenu = function(){
window.status = 'Right-click is disabled';
return false;
}

//MSIE6 disable F5 && ctrl+r && ctrl+n
document.onkeydown=function(){
//alert('keycode='+event.keyCode + 'event.ctrlKey='+event.ctrlKey );
switch (event.keyCode) {
case 116 : //F5
event.returnValue=false;
event.keyCode=0;
window.status = 'Refresh is disabled';
return false;
case 78: //n
if (event.ctrlKey) {
event.returnValue=false;
event.keyCode=0;
window.status = 'New window is disabled';
return false;
}
case 82 : //r
if (event.ctrlKey) {
event.returnValue=false;
event.keyCode=0;
window.status = 'Refresh is disabled';
return false;
}
}
}


// diasable back button
window.history.forward(1);
</script> 

<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function Time()
{
 alert("YOUR TIME IS UP!!");
 window.location = "submit.php";
} 
function Times()
{
 alert("YOU HAVE 5 MORE MINUTES");
} 
function Timess()
{
 alert("YOU HAVE 1 MORE MINUTE. ROUND UP YOUR WORK AND CLICK THE SUBMIT BUTTON IN THE NEXT 30 SECONDS!");
} 

</script>
<script type="text/JavaScript">
<!--
setTimeout("Time()",600000);
setTimeout("Times()",300000);
setTimeout("Timess()",540000);
-->
</script>
<script type="text/javascript">

function Confirm(message,url)
{
 if(confirm(message))location.href = url;
} 
</script>

<script type="text/javascript">
function Confirmation() {
	var answer = confirm("<?php echo "$_SESSION[username]";?>, is this your final answer?")
	if (answer){
		window.location = "pre-submit.php";
	}
	else{
		alert("Please choose another answer!")
	}
}
</script>
<script type="text/javascript">
function saveChanges()
{
var newHtml = document.documentElement.outerHTML;
document.open("text/html","replace");
document.write(newHtml);
document.close();
document.execCommand("saveas", false, "default.htm");
}

//window.onload = saveChanges;
</script>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>E-TEST ENGINE::</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=2.0,Transition=21)">
<base target="rtop">
<style type="text/css">
<!--
.style1 {font-weight: bold;}
.style2 {
	color: #FFFFFF;
	font-weight: bold;
}
body {
	background-color: #000000;
}
-->
input.btn { 
	  color:#050; 
  font: bold 84% 'trebuchet ms',helvetica,sans-serif; 
	  background-color:#fed; 
	  border: 1px solid; 
	  border-color: #696 #363 #363 #696; 
	  filter:progid:DXImageTransform.Microsoft.Gradient 
	  (GradientType=0,StartColorStr='#ffffffff',EndColorStr='#ffeeddaa'); 
	  text-decoration:blink; 
	  cursor:pointer;
	}
input.btnhov { 
border-color: #c63 #930 #930 #c63;	 
}
</style>
<link href="default.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style5 {color: #FFFFFF}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.style6 {
	font-family: "Courier New", Courier, monospace;
	font-weight: bold;
}
.style7 {font-family: "Courier New", Courier, monospace}
body,td,th {
	font-size: 18px;
	color: #FFFFFF;
	font-weight: bold;
}
.style8 {font-size: 12px}
-->
</style>
</head>
<body>

<table width="62%" height="16" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr>
<td width="461" height="12" valign="top" bgcolor="#003333"> 
  <div align="left" class="style2">
    <div align="center">
      <p><font size="4" face="Courier New, Courier, 
mono">Welcome!</font></p>
      <p>&nbsp;</p>
    </div>
  </div></td>
<td width="127" valign="top" bgcolor="#003333"> </td>
</tr>
</table>
<br>
<form method="post" action="submit.php">
<div align="center" class="style6"><font color="#FFFFFF"><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans0');"> QUESTION 1(Click to show question) [+] </span></font></div>
<tr></tr>
<div id="ans0">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
<tr bgcolor="#006600"> 
<td height="19" colspan="3" valign="top" bgcolor="#003333"> 
  <p align="center"></td>
<td colspan="2" valign="top" bgcolor="#003333">&nbsp;
</td>
</tr>
<tr>
<td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
<td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>1</h1>";
?><br> </td>
<td colspan="2" valign="top" bgcolor="#808080"><table>
<tr>
<td width="600"><font size="+2"><b>
<?php

include('dbconnect.php');
// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '1' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '1' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '1' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer1 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='1' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A1 = $row['A'];
  $B1 = $row['B'];
  $C1 = $row['C'];
  $D1 = $row['D'];
}   
?>
<br>

 </b></font></td>
      </tr>
    </table>
      <p>&nbsp;</p>    </td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
	<tr>
	  <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
	<tr>
      <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
        <tr>
          <td width="38" bgcolor="#003333"><p align="left"> <span class="style5">
            <label><strong>A</strong></label>
            </span>
            
              <input name="question_1" type="radio" value="A1">
          </td>
          <td width="212" bgcolor="#003333" font size="+8"><?php echo $A1;?> <input type="hidden" name="move_number6" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice6" value="A" /></td>
          <td width="41" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
            <input name="question_1" type="radio" value="B1">
          </strong></span></td>
          <td width="237" bgcolor="#003333" font size="+8"><?php echo $B1;?> <input type="hidden" name="move_number7" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice7" value="B" /></td>
        </tr>
        <tr>
          <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
        </tr>
        <tr>
          <td width="38" bgcolor="#003333"><span class="style5">
            <label><strong>C</strong></label>
            <input name="question_1" type="radio" value="C1">
          </span></td>
          <td bgcolor="#003333"><?php echo $C1;?> <input type="hidden" name="move_number8" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice8" value="C" /></td>
          <td bgcolor="#003333"><span class="style5"><strong>D 
            <input name="question_1" type="radio" value="D1">
          </strong></span></td>
          <td bgcolor="#003333"><?php echo $D1;?> <input type="hidden" name="move_number" size="20" value='<?php
	echo "1";?>' /> <input type="hidden" name="choice" value="D" /> <input type="hidden" name="answer1" value="<?php echo $answer1;?>" /></td>
        </tr>
        <tr>
          <td colspan="4" bgcolor="#003333"><p> <span class="style1">
              <label></label>
          </span></td>
        </tr>
      </table></td>
	</tr>
	<tr>
	  <td height="1"></td>
	  <td></td>
	  <td width="484"></td>
	  <td width="105"></td>
	  <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans1');"> QUESTION 2(Click to show question) [+] </span><br>
  </b></font><br>
</div>
<div id="ans1">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>2</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '2' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '2' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '2' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer2 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='2' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A2 = $row['A'];
  $B2 = $row['B'];
  $C2 = $row['C'];
  $D2 = $row['D'];
}   
?>
          <br>
                 </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="37" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
             
            <label>
            <input name="question_2" type="radio" value="A2">
            </label>
        </td>
        <td width="212" bgcolor="#003333" font size="+8"><?php echo $A2?>
          <input type="hidden" name="move_number22" size="20" value='<?php
	echo "2";?>' />
          <input type="hidden" name="choice22" value="A" /></td>
        <td width="48" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_2" type="radio" value="B2">
        </strong></span></td>
        <td width="231" bgcolor="#003333" font size="+8"><?php echo $B2;?> <input type="hidden" name="move_number23" size="20" value='<?php
	echo "2";?>' /> <input type="hidden" name="choice23" value="B" /></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="37" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_2" type="radio" value="C2">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C2;?> <input type="hidden" name="move_number24" size="20" value='<?php
	echo "2";?>' /> <input type="hidden" name="choice24" value="C" /></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_2" type="radio" value="D2">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D2;?> <input type="hidden" name="move_number2" size="20" value='<?php
	echo "2";?>' /> <input type="hidden" name="choice2" value="D" /> <input name="answer2" type="hidden" id="answer2" value="<?php echo $answer2;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans2');"> QUESTION 3(Click to show question) [+] </span></b></font></div>
<div id="ans2">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>3</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '3' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '3' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '3' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer3 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='3' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A3 = $row['A'];
  $B3 = $row['B'];
  $C3 = $row['C'];
  $D3 = $row['D'];
}   
?>
          <br>

        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="36" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span>
           
            <strong>
            <input name="question_3" type="radio" value="A3">
            </strong></td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>' />
  <input type="hidden" name="choice3" value="A" /></td>
        <td width="44" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_3" type="radio" value="B3">
        </strong></span></td>
        <td width="236" bgcolor="#003333" font size="+8"><?php echo $B3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>'>
          <input type="hidden" name="choice3" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="36" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_3" type="radio" value="C3">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>'>
          <input type="hidden" name="choice3" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_3" type="radio" value="D3">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D3;?> <input type="hidden" name="move_number3" size="20" value='<?php
	echo "3";?>'>
          <input type="hidden" name="choice3" value="D"> <input name="answer3" type="hidden" id="answer3" value="<?php echo $answer3;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans3');"> QUESTION 4(Click to show question) [+] </span></b></font></div>
<div id="ans3">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>4</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '4' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '4' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '4' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer4 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='4' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A4 = $row['A'];
  $B4 = $row['B'];
  $C4 = $row['C'];
  $D4 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span><strong>
          <input name="question_4" type="radio" value="A4">
          </strong></td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A4;?> <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_4" type="radio" value="B4">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B4;?>  <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_4" type="radio" value="C4">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C4;?> <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_4" type="radio" value="D4">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D4;?> <input type="hidden" name="move_number4" size="20" value='<?php
	echo "4";?>'>
          <input type="hidden" name="choice4" value="D"> <input name="answer4" type="hidden" id="answer4" value="<?php echo $answer4;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans4');"> QUESTION 5(Click to show question) [+] </span></b></font></div>
<div id="ans4">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>5</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '5' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '5' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '5' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer5 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='5' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A5 = $row['A'];
  $B5 = $row['B'];
  $C5 = $row['C'];
  $D5 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="39" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span><strong>
          <input name="question_5" type="radio" value="A5">
          </strong></td>
        <td width="213" bgcolor="#003333" font size="+8"><?php echo $A5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="A"></td>
        <td width="47" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_5" type="radio" value="B5">
        </strong></span></td>
        <td width="233" bgcolor="#003333" font size="+8"><?php echo $B5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="39" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_5" type="radio" value="C5">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_5" type="radio" value="D5">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D5;?> <input type="hidden" name="move_number5" size="20" value='<?php
	echo "5";?>'>
          <input type="hidden" name="choice5" value="D"> <input name="answer5" type="hidden" id="answer5" value="<?php echo $answer5;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<br>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans5');"> QUESTION 6(Click to show question) [+] </span></b></font></div>
  <div id="ans5">
    <table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
      <!--DWLayoutTable-->
      <tr>
        <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
        <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>6</h1>";
?>
            <br>
        </td>
        <td colspan="2" valign="top" bgcolor="#808080"><table>
            <tr>
              <td width="600"><font size="+2"><b>
                <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '6' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '6' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '6' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer6 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='6' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A6 = $row['A'];
  $B6 = $row['B'];
  $C6 = $row['C'];
  $D6 = $row['D'];
}   
?>
                <br>
              </b></font></td>
            </tr>
          </table>
            <p>&nbsp;</p></td>
        <td width="27" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
      </tr>
      <tr>
        <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
            <tr>
              <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
                  <label><strong>A</strong></label>
                  </span><strong>
                  <input name="question_6" type="radio" value="A6">
              </strong></td>
              <td width="216" bgcolor="#003333" font size="+8"><?php echo $A6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="A"></td>
              <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B
                <input name="question_6" type="radio" value="B6">
              </strong></span></td>
              <td width="238" bgcolor="#003333" font size="+8"><?php echo $B6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="B"></td>
            </tr>
            <tr>
              <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
            </tr>
            <tr>
              <td width="41" bgcolor="#003333"><span class="style5">
                <label><strong>C</strong></label>
                <strong>
                <input name="question_6" type="radio" value="C6">
              </strong></span></td>
              <td bgcolor="#003333"><?php echo $C6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="C"></td>
              <td bgcolor="#003333"><span class="style5"><strong>D
                <input name="question_6" type="radio" value="D6">
              </strong></span></td>
              <td bgcolor="#003333"><?php echo $D6;?>
                  <input type="hidden" name="move_number6" size="20" value='<?php
	echo "6";?>'>
                  <input type="hidden" name="choice6" value="D">
                  <input name="answer6" type="hidden" id="answer6" value="<?php echo $answer6;?>" /></td>
            </tr>
            <tr>
              <td colspan="4" bgcolor="#003333"><p> <span class="style1">
                  <label></label>
              </span> &nbsp;&nbsp;</td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="1"></td>
        <td></td>
        <td width="484"></td>
        <td width="105"></td>
        <td></td>
      </tr>
    </table>
  </div>
  <div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans6');"> QUESTION 7(Click to show question) [+] </span></b></font></div>
<div id="ans6">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>7</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '7' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '7' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '7' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer7 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='7' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A7 = $row['A'];
  $B7 = $row['B'];
  $C7 = $row['C'];
  $D7 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span><strong>
          <input name="question_7" type="radio" value="A7">
          </strong></td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A7;?> <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_7" type="radio" value="B7">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B7;?>  <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_7" type="radio" value="C7">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C7;?> <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_7" type="radio" value="D7">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D7;?> <input name="move_number7" type="hidden" id="move_number7" value='<?php
	echo "7";?>' size="20">
          <input name="choice7" type="hidden" id="choice7" value="D"> 
          <input name="answer7" type="hidden" id="answer7" value="<?php echo $answer7;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans7');"> QUESTION 8(Click to show question) [+] </span></b></font></div>
<div id="ans7">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>8</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '8' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '8' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '8' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer8 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='8' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A8 = $row['A'];
  $B8 = $row['B'];
  $C8 = $row['C'];
  $D8 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span><strong>
          <input name="question_8" type="radio" value="A8">
          </strong></td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A8;?> <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "8";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_8" type="radio" value="B8">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B8;?>  <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "8";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_8" type="radio" value="C8">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C8;?> <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "8";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_8" type="radio" value="D8">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D8;?> <input name="move_number8" type="hidden" id="move_number8" value='<?php
	echo "4";?>' size="20">
          <input name="choice8" type="hidden" id="choice8" value="D"> 
          <input name="answer8" type="hidden" id="answer8" value="<?php echo $answer8;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans8');"> QUESTION 9(Click to show question) [+] </span></b></font></div>
<div id="ans8">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>9</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '9' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '9' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '9' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer9 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='9' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A9 = $row['A'];
  $B9 = $row['B'];
  $C9 = $row['C'];
  $D9 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span><strong>
          <input name="question_9" type="radio" value="A9">
          </strong></td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A9;?> <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_9" type="radio" value="B9">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B9;?>  <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_9" type="radio" value="C9">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C9;?> <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_9" type="radio" value="D9">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D9;?> <input name="move_number9" type="hidden" id="move_number9" value='<?php
	echo "9";?>' size="20">
          <input name="choice9" type="hidden" id="choice9" value="D"> 
          <input name="answer9" type="hidden" id="answer9" value="<?php echo $answer9;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
<div align="center" class="style7"><font color="#FFFFFF"><b><span style="cursor: hand; cursor: pointer" onClick="toggleInfo('ans9');"> QUESTION 10(Click to show question) [+] </span></b></font></div>
<div id="ans9">
<table width="62%" 
height="44%" border="0" align="center" cellpadding="0" style="border-collapse: collapse">
  <!--DWLayoutTable-->
  <tr>
    <td width="42" rowspan="3" bgcolor="#003333">&nbsp;</td>
    <td width="80" align="center" valign="top" bgcolor="#808080"><?php
echo "<h1>10</h1>";
?>
        <br>    </td>
    <td colspan="2" valign="top" bgcolor="#808080"><table>
      <tr>
        <td width="600"><font size="+2"><b>
          <?php
include ('dbconnect.php');


// SELECT A QUESTION
$query =mysql_query("select `question` from user_question where `page_no` = '10' AND`username`='$_SESSION[reg_no]'");
$now = @mysql_result($query, 0, "question"); 
echo "$now";
//echo "$number";
$query_vik =mysql_query("select `correct` from user_question where `page_no` = '10' AND`username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$viky = @mysql_result($query_vik, 0, "correct");

$query_lilian = mysql_query("SELECT `$viky` from `user_question` where `page_no` = '10' AND `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$answer10 = @mysql_result($query_lilian, 0, "$viky");
//$_SESSION['chosen_option'] = $viky;

$query_wifey = mysql_query("SELECT * FROM user_question where `page_no`='10' AND `username`='$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
while($row = mysql_fetch_array($query_wifey) )
{
  $A10 = $row['A'];
  $B10 = $row['B'];
  $C10 = $row['C'];
  $D10 = $row['D'];
}   
?>
          <br>
          
        </b></font></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
    <td width="27" bgcolor="#003333">&nbsp;</td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><font face="Bodoni MT Black" color="#FFFFFF"><b>Choose Your Answer </b></font></td>
  </tr>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4"><table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 
width="97%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 
bgcolor="white">
      <tr>
        <td width="41" bgcolor="#003333"><p align="left"> <span class="style5">
          <label><strong>A</strong></label>
          </span><strong>
          <input name="question_10" type="radio" value="A10">
          </strong></td>
        <td width="216" bgcolor="#003333" font size="+8"><?php echo $A10;?> <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="A"></td>
        <td width="43" bgcolor="#003333" font size="+8"><span class="style5"><strong>B 
          <input name="question_10" type="radio" value="B10">
        </strong></span></td>
        <td width="238" bgcolor="#003333" font size="+8"><?php echo $B10;?>  <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="B"></td>
      </tr>
      <tr>
        <td height="28" colspan="4" bgcolor="#003333">&nbsp;</td>
      </tr>
      <tr>
        <td width="41" bgcolor="#003333"><span class="style5">
          <label><strong>C</strong></label>
          <strong>
          <input name="question_10" type="radio" value="C10">
          </strong></span></td>
        <td bgcolor="#003333"><?php echo $C10;?> <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="C"></td>
        <td bgcolor="#003333"><span class="style5"><strong>D 
          <input name="question_10" type="radio" value="D10">
        </strong></span></td>
        <td bgcolor="#003333"><?php echo $D10;?> <input name="move_number10" type="hidden" id="move_number10" value='<?php
	echo "10";?>' size="20">
          <input name="choice10" type="hidden" id="choice10" value="D"> 
          <input name="answer10" type="hidden" id="answer10" value="<?php echo $answer10;?>" /></td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#003333"><p> <span class="style1">
          <label></label>
        </span> &nbsp;&nbsp;
        <input name="reg_no" type="hidden" id="reg_no" value='<?php
	echo $_SESSION['reg_no'];?>' size="20">
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td width="484"></td>
    <td width="105"></td>
    <td></td>
  </tr>
</table>
</div>
  <tr>
    <td height="19" bgcolor="#003333" colspan="4">
      <label></label>
      <div align="center">
      <label>
        <input type="submit" name="Submit2" value="Submit">
      </label>
</form>
      <table width="719">
        <tr>
          <td align="center"><span class="style8">Powered by e-NERGY Software Solutions. 08039098042</span> </td>
        </tr>
      </table>
      </td>
      </tr>
<tr>
    
</table>

</body>
</html>
<?php
$_SESSION['display_no'] = $display_no;
}
?> 