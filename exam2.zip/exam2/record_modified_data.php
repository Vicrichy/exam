<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Record Modified</title>
<script LANGUAGE="JavaScript">
<!--

// JavaScript centering adapted by telophase: telophase@telophase.net
// from code by Kate Ward: http//www.kateandmouse.com
// Full permission is granted for use.

function popUp(URL,popW,popH) {

var w = 480, h = 340;

if (document.all || document.layers) {
   w = screen.availWidth;
   h = screen.availHeight;
}

var topPos = 0, leftPos = (w-popW)/2;


   window.open(URL,'popup','resizable, toolbar=no, location=no, status=no, scrollbars=yes, horizontal scrollbars=yes, scroll=yes, menubar=no, titlebar=no, width=' + popW + ',height=' + popH + ',left=' + leftPos + ',top=' + topPos + ',screenX=' + leftPos + ',screenY=' + topPos);
}
// -->
</script>

<style type="text/css">
<!--
body {
	background-color: #009900;
}
.style1 {color: #FF0000}
-->
</style></head>

<body>

<?php

session_start();
session_destroy();


?>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="97%">
  <tr> 
    <td colspan="2" bgcolor="#000000">&nbsp; <p align="center">&nbsp;<font size="6" color="#FFFFFF">E-TEST</font><br>
    &nbsp;</td>
  </tr>
  <tr> 
    <td width="99%" valign="top" bgcolor="#FFFFFF"><p>
	<font face="System" color="#FFFFFF"><b>
	</b></font></p>
	  <p align="center"><strong></strong></p>
      <table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
        <tr> 
          <td height="105" bgcolor="#FFFFFF"> 
            <div align="center"><strong><font size="6">STUDENT'S DATA HAS BEEN MODIFED. </font></strong></div>
            <p align="center">&nbsp;</p>
            <p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            </p></td>
        </tr>
        <tr> 
          <td>
<div align="center" class="style1"><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font face="Arial Black">[Return]</font></a></font></div></td>
        </tr>
      </table>
	  <p>&nbsp;</p>
      <p>&nbsp;</p> </td>
    <td width="1%" rowspan="2" valign="top" bgcolor="#000000" align="right">&nbsp;	</td>
  </tr>
  <tr> 
    <td valign="top" bgcolor="#CCCCCC">&nbsp;      </td>
  </tr>
  <tr bgcolor="#000099"> 
    <td colspan="2" valign="bottom" bgcolor="#000000">&nbsp;</td>
  </tr>
</table>

</body>

</html>