<?php

include('dbconnect.php');

mysql_query("UPDATE `registration_table` SET `semester`='FIRST' WHERE `semester`='SECOND'");

echo "SEMESTER UPGRADED TO FIRST";

echo "<a href=javascript:history.back()> << Return </a>";

?>