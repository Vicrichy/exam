<?php

include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
mysql_select_db('datamix');

include('dbconnect.php');

$table_name = "meet";

$query_create = "CREATE TABLE $table_name (name VARCHAR( 20 ) NOT NULL , sex VARCHAR( 20 ) NOT NULL)";
$result = mysql_query($query_create);

echo "PLS WORK";
}
?>
