<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 2) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>DATAMIX Test Engine [Registration]</title>

<!-- BASIC CALENDAR HEADER -->
<style type="text/css">

.main {
width:200px;
border:1px solid black;
}

.month {
background-color:black;
font:bold 12px verdana;
color:white;
}

.daysofweek {
background-color:gray;
font:bold 12px verdana;
color:white;
}

.days {
font-size: 12px;
font-family:verdana;
color:black;
background-color: lightyellow;
padding: 2px;
}

.days #today{
font-weight: bold;
color: red;
}

</style>


<script type="text/javascript" src="basiccalendar.js">


</script>

<!-- BASIC CALENDAR HEADER ENDS -->

</head>

<body background="images/reg_stuff.jpg">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("username","reg_no","title","surname","first_name","sex","address","mobile_phone","email","course","amount_paid","receipt_no");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("USERNAME","REG. NUMBER","TITLE","SURNAME","FIRST NAME","SEX","ADDRESS","MOBILE PHONE","EMAIL","COURSE","AMOUNT PAID","RECEIPT NUMBER");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
	
  <tr> 
    <td height="77" colspan="3" bgcolor="#008000">
<p align="center">
<form name="form1" method="post" action="logout.php">
        <div align="right">
          <input type="submit" name="Submit" value="Logout">
        </div>
      </form>
      
    </td>
		
    <td bgcolor="#FFFFFF">&nbsp; </td>
	</tr>
	<tr>
		
    <td width="23%" bgcolor="#000000" rowspan="3" valign="top"><strong><a href="additional_payment.php"><font color="#00FF33" size="3">[ADDITIONAL 
      PAYMENT]</font></a></strong> &nbsp; 
      <p>&nbsp;<a href="registration_page.php"><img border="0" src="images/register_students_bt.jpg" width="165" height="35"></a></p>
		
      <p> &nbsp;<a href="retrieve_data_scheduler_reg2.php"><img border="0" src="images/retrieve_reg_data_bt.jpg" width="165" height="35"></a></p>
      <p><a href="modify_reg_data.php"><img border="0" src="images/modify_reg_data_butt.jpg" width="172" height="35"></a></p>
		<p>&nbsp;
		</p>
		<p>&nbsp;<br>
		<br>
		&nbsp;</p>
		<p>&nbsp;
		</p>
		<p>&nbsp;</p>
		<p></td>
		
    <td width="74%" height="30" valign="top" bgcolor="#808000"><font color="#00FF00"><b> 
      </b></font></td>
		<td width="2%" valign="top">&nbsp; </td>
		<td width="1%" bgcolor="#008000" rowspan="3">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="74%" valign="top" height="377" rowspan="2">&nbsp;<font size="2"><b> 
      </b></font>
      <table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
        <tr> 
          <td height="67" colspan="3" bgcolor="#000000"> <p align="right"> <b><font size="2" color="#008000"> 
              <a href="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/help.html"> 
              </a></font></b></p>
            <p align="left"> <font size="5">&nbsp;<b> <font color="#00FF00" face="Copperplate Gothic Bold"><u>MODIFY 
              REGISTRATION RECORDS</u></font></b></font></td>
        </tr>
        <tr> 
          <td width="75%" valign="top" bgcolor="#808000"><u> <font color="#FFFFFF"><b>RETRIEVE 
            REGISTRATION RECORDS</b></font></u></td>
          <td width="75%" colspan="-1" valign="top">&nbsp; </td>
          <td width="1%" bgcolor="#000000" rowspan="4">&nbsp;</td>
        </tr>
        <tr> 
          <td width="75%" height="200" colspan="2" valign="top">&nbsp; <form method="POST" action="sh_all_registration_records.php">
              <p align="center"> 
                <input type="submit" value="SHOW ALL STUDENTS REGULAR REGISTRATION RECORDS" name="B1">
              </p>
            </form>
            <form method="POST" action="sh_payment_history.php">
              <p align="center"> 
                <input type="submit" value="SHOW ALL PAYMENT HISTORY" name="B1">
              </p>
            </form>
            <form name="form3" method="post" action="searchregno_payment_history.php">
              <div align="center"> 
                <input name="reg_no" type="text" id="reg_no">
                <br>
                <input type="submit" name="Submit3" value="SEARCH PAYMENT HISTORY BY REG. NUMBER">
              </div>
            </form></td>
        </tr>
        <tr> 
          <td width="75%" valign="top" height="19" colspan="2" bgcolor="#000000"><font color="#FFFF00"> 
            MODIFY/ CHANGE REG. NUMBER</font></td>
        </tr>
        <tr> 
          <td height="141" colspan="2" valign="top"> <p> 
            <form name="form4" method="post" action="change_regno_registration.php">
              <p> SPECIFY REG.NUMBER 
                &nbsp; &nbsp; &nbsp; &nbsp; 
                <input name="change_old" type="text" id="change_old">
              </p>
              <p> SPECIFY NEW REG.NUMBER 
                <input name="change_new" type="text" id="change_new">
              </p>
              <p>
                <input type="submit" name="Submit4" value="CHANGE">
              </p>
            </form>
			
			<table width="100%" border="1">
              <tr>
                <td bordercolor="0" bgcolor="#000000"><font color="#FFFF00">MODIFY/ 
                  CHANGE CLASS RESUMPTION DATE</font></td>
				
              </tr>
            </table>
			
			<form name="form4" method="post" action="change_classresume_date_registration.php">
              <p> SPECIFY DATE&nbsp; &nbsp; &nbsp; &nbsp; 
                 <b><font size="2"> <b><font size="2"><b><font color="#CCCCCC"> 
                <select name="day" id="day">
                  <option selected value=""></option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="17">17</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
                </font></b></font></b> </font> </b><font size="2"><b> <font color="#CCCCCC"> 
                <select name="month" id="selectmonth" style="width:49; height:22">
                  <option selected value=""></option>
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                </select>
                </font> 
                <select name="year" id="selectyear" size="1">
                  <option selected></option>
                  <option value="2005">2005</option>
                  <option value="2006">2006</option>
                  <option value="2007">2007</option>
                  <option value="2008">2008</option>
                  <option value="2009">2009</option>
                  <option value="2010">2010</option>
                  <option value="2011">2011</option>
                  <option value="2012">2012</option>
                  <option value="2013">2013</option>
                  <option value="2014">2014</option>
                  <option value="2015">2015</option>
                  <option value="2016">2016</option>
                  <option value="2017">2017</option>
                  <option value="2018">2018</option>
                  <option value="2019">2019</option>
                  <option value="2020">2020</option>
                  <option value="2021">2021</option>
                  <option value="2022">2022</option>
                  <option value="2023">2023</option>
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                  <option value="2029">2029</option>
                  <option value="2030">2030</option>
                  <option value="2031">2031</option>
                  <option value="2032">2032</option>
                  <option value="2033">2033</option>
                  <option value="2034">2034</option>
                  <option value="2035">2035</option>
                  <option value="2036">2036</option>
                  <option value="2037">2037</option>
                  <option value="2038">2038</option>
                  <option value="2039">2039</option>
                  <option value="2040">2040</option>
                  <option value="2041">2041</option>
                  <option value="2042">2042</option>
                  <option value="2043">2043</option>
                  <option value="2044">2044</option>
                  <option value="2045">2045</option>
                  <option value="2046">2046</option>
                  <option value="2047">2047</option>
                  <option value="2048">2048</option>
                  <option value="2049">2049</option>
                  <option value="2050">2050</option>
                  <option value="2051">2051</option>
                  <option value="2052">2052</option>
                  <option value="2053">2053</option>
                  <option value="2054">2054</option>
                  <option value="2055">2055</option>
                  <option value="2056">2056</option>
                  <option value="2057">2057</option>
                  <option value="2058">2058</option>
                  <option value="2059">2059</option>
                  <option value="2059">2060</option>
                  <option value="2061">2061</option>
                  <option value="2062">2062</option>
                  <option value="2063">2063</option>
                  <option value="2064">2064</option>
                  <option value="2065">2065</option>
                  <option value="2066">2066</option>
                  <option value="2067">2067</option>
                  <option value="2068">2068</option>
                  <option value="2069">2069</option>
                  <option value="2070">2070</option>
                  <option value="2071">2071</option>
                  <option value="2072">2072</option>
                  <option value="2073">2073</option>
                  <option value="2074">2074</option>
                  <option value="2075">2075</option>
                  <option value="2076">2076</option>
                  <option value="2077">2077</option>
                  <option value="2078">2078</option>
                  <option value="2079">2079</option>
                  <option value="2080">2080</option>
                  <option value="2081">2081</option>
                  <option value="2082">2082</option>
                  <option value="2083">2083</option>
                  <option value="2084">2084</option>
                  <option value="2085">2085</option>
                  <option value="2086">2086</option>
                  <option value="2087">2087</option>
                  <option value="2088">2088</option>
                  <option value="2089">2089</option>
                  <option value="2090">2090</option>
                </select>
              </p>
              <p> SPECIFY NEW DATE 
                 <b><font size="2"> <b><font size="2"><b><font color="#CCCCCC"> 
                <select name="day2" id="day2">
                  <option selected value=""></option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="17">17</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
                </font></b></font></b> </font> </b><font size="2"><b> <font color="#CCCCCC"> 
                <select name="month2" id="selectmonth" style="width:49; height:22">
                  <option selected value=""></option>
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                </select>
                </font> 
                <select name="year2" id="selectyear" size="1">
                  <option selected></option>
                  <option value="2005">2005</option>
                  <option value="2006">2006</option>
                  <option value="2007">2007</option>
                  <option value="2008">2008</option>
                  <option value="2009">2009</option>
                  <option value="2010">2010</option>
                  <option value="2011">2011</option>
                  <option value="2012">2012</option>
                  <option value="2013">2013</option>
                  <option value="2014">2014</option>
                  <option value="2015">2015</option>
                  <option value="2016">2016</option>
                  <option value="2017">2017</option>
                  <option value="2018">2018</option>
                  <option value="2019">2019</option>
                  <option value="2020">2020</option>
                  <option value="2021">2021</option>
                  <option value="2022">2022</option>
                  <option value="2023">2023</option>
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                  <option value="2029">2029</option>
                  <option value="2030">2030</option>
                  <option value="2031">2031</option>
                  <option value="2032">2032</option>
                  <option value="2033">2033</option>
                  <option value="2034">2034</option>
                  <option value="2035">2035</option>
                  <option value="2036">2036</option>
                  <option value="2037">2037</option>
                  <option value="2038">2038</option>
                  <option value="2039">2039</option>
                  <option value="2040">2040</option>
                  <option value="2041">2041</option>
                  <option value="2042">2042</option>
                  <option value="2043">2043</option>
                  <option value="2044">2044</option>
                  <option value="2045">2045</option>
                  <option value="2046">2046</option>
                  <option value="2047">2047</option>
                  <option value="2048">2048</option>
                  <option value="2049">2049</option>
                  <option value="2050">2050</option>
                  <option value="2051">2051</option>
                  <option value="2052">2052</option>
                  <option value="2053">2053</option>
                  <option value="2054">2054</option>
                  <option value="2055">2055</option>
                  <option value="2056">2056</option>
                  <option value="2057">2057</option>
                  <option value="2058">2058</option>
                  <option value="2059">2059</option>
                  <option value="2059">2060</option>
                  <option value="2061">2061</option>
                  <option value="2062">2062</option>
                  <option value="2063">2063</option>
                  <option value="2064">2064</option>
                  <option value="2065">2065</option>
                  <option value="2066">2066</option>
                  <option value="2067">2067</option>
                  <option value="2068">2068</option>
                  <option value="2069">2069</option>
                  <option value="2070">2070</option>
                  <option value="2071">2071</option>
                  <option value="2072">2072</option>
                  <option value="2073">2073</option>
                  <option value="2074">2074</option>
                  <option value="2075">2075</option>
                  <option value="2076">2076</option>
                  <option value="2077">2077</option>
                  <option value="2078">2078</option>
                  <option value="2079">2079</option>
                  <option value="2080">2080</option>
                  <option value="2081">2081</option>
                  <option value="2082">2082</option>
                  <option value="2083">2083</option>
                  <option value="2084">2084</option>
                  <option value="2085">2085</option>
                  <option value="2086">2086</option>
                  <option value="2087">2087</option>
                  <option value="2088">2088</option>
                  <option value="2089">2089</option>
                  <option value="2090">2090</option>
                </select>
              </p>
              <p>
                <input type="submit" name="Submit4" value="CHANGE">
              </p>
            </form></p>
            <p>&nbsp;</p></td>
        </tr>
        <tr> 
          <td colspan="3" bgcolor="#000000"> <p align="center"><b> <font color="#000000" size="2">Technology 
              by WebOptions ICT (www.weboptionsict.com/08069802185)</font></b></td>
        </tr>
      </table>
      <p align="right"> <strong>DELETE RECORD</strong></p>
      <p><strong><font size="3"> <form name="form2" method="post" action="delete_scheduled_test.php">
        <p align="right">REG NUMBER 
          <input name="reg_no" type="text" id="reg_no">
          <br>
          COURSE 
          <input name="course" type="text" id="course">
          <br>
          RECEIPT.NO 
          <input name="receipt_no" type="text" id="receipt_no">
          <br>
          <br>
          <input type="submit" name="Submit2" value="DELETE ">
        </p>
        <p>&nbsp;</p>
      </form><br>
      </p></td>
		
    <td width="2%" valign="top" height="95">&nbsp; 
      <p>&nbsp;<script language="JavaScript" src="calendar.js"></script>

	<!-- BASIC CALENDAR BODY -->
	
	<script type="text/javascript">

var todaydate=new Date()
var curmonth=todaydate.getMonth()+1 //get current month (1-12)
var curyear=todaydate.getFullYear() //get current year

document.write(buildCal(curmonth ,curyear, "main", "month", "daysofweek", "days", 1));
</script>

<!-- BASIC CALENDAR BODY ENDS -->
</p>
		
    </td>
	</tr>
	<tr>
		
    <td width="2%" valign="top" height="704">&nbsp; </td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#008000">
		  <p align="center"></td>
		<td bgcolor="#008000">&nbsp;
		</td>
		<td bgcolor="#FFFF00">&nbsp;
		</td>
	</tr>
</table>

</body>

</html>
<?php
}
?>