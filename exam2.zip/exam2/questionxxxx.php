<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with correct details</p></i></b>";
} 

else { 

?> 
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST ::: TESTING ROOM</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=2.0,Transition=21)">
<base target="rtop">
</head>

<body bgcolor="#CCCCCC" background="images/bg1.jpg">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="">
<tr>
    <td height="27" bgcolor="#000000"> 
      <div align="left"><font color="#00FF33" size="4" face="Courier New, Courier, 

mono"><strong>ELECTRONIC TESTING 
        ROOM </strong></font></div></td></tr></table>
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" 

height="44%">
  <tr bgcolor="#006600"> 
    <td height="19" colspan="4"> 
      <p align="center"><font face="Bodoni MT Black" color="#FFFFFF"><b> 

QUESTION</b></font></td>
  </tr>
	<tr>
		
    <td width="2%" bgcolor="#006600" rowspan="2">&nbsp;</td>
		
    <td width="47%" bgcolor="#CCCCCC" valign="top"> <img border="0" src="images/qmark4.jpg" 

width="78" height="87" align="left"> 
      <table>
	  
        <tr>
          <td width="600"><font size="+2"><b> 
 <?php
	   
		   
		   
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{







// GENERATE RANDOM AND NON-REPETITIVE QUESTIONS. (I am using a Do loop to effect this).

do
{
include ('dbconnect.php');



// Determine the course code

$query_cc = mysql_query("SELECT course_code from course_list where course = '$_SESSION[course]'");
$query_coursecode = mysql_result($query_cc, 0, "course_code");


// Determine the total number of questions available
$query_c = mysql_query("select count(question) from $query_coursecode where correct = 'right'");
$query_count = mysql_result($query_c, 0, "count(question)");


// Use this total to set the limit and initiate the random engine
mt_srand((double)microtime() * 1000000);
$number = mt_rand(1,$query_count);


//Check if the candidate has previously answered the question

$query_checkp = ("SELECT id FROM answered_questions WHERE reg_no = '$_SESSION[reg_no]' and 

course = '$_SESSION[course]' and id = '$number'");
$checkp = mysql_query($query_checkp);

$no_of_rows = mysql_num_rows($checkp) ;			 

}while($no_of_rows > 0);
// RANDOM GENERATION ENDS






// SELECT A QUESTION
$query =mysql_query("select question from $query_coursecode where id = '$number'");
$now =mysql_result($query, 0, "question"); 
echo "$now";
}

?>
<br>

<?php


include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{



// RETRIEVE THE NUMBER OF ANSWERED QUESTIONS

$query =mysql_query("select count(question) from answered_questions where reg_no = 

'$_SESSION[reg_no]' and course = '$_SESSION[course]'");
$question_query =mysql_result($query, 0, "count(question)");
$question_count = $question_query ;



if (($_SESSION['test_type']) == 'Quiz')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}






if (($_SESSION['test_type']) == 'Exam')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_tyoe = 'exam'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'exam'");
$query_max_time =mysql_result($query4, 0, "duration");

}





if (($_SESSION['test_type']) == 'Exam Re-sit')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}

// DETERMINE THE AMOUNT OF TIME (IN MINUTES) SPENT BY THE CANDIDATE IN THIS SESSION

  $spent_time = round((time() - $_SESSION['start']) / 60) ; 
   

}
?>
<?php

if (($question_count) >= $query_max_questions ) { 
header('Location: test_over.php');
}
?>
<?php
if (($spent_time) >= $query_max_time ) { 
header('Location: test_over.php');
}
?>  
            </b></font></td>
        </tr>
      </table>
      <p>&nbsp;</p> <br> </td>
		
    <td width="2%" bgcolor="#006600">&nbsp;</td>
		
    <td width="1%" bgcolor="#006600"><strong></strong></td>
	</tr>
	<tr>
		
    <td width="50%" height="19" bgcolor="#006600" colspan="3">&nbsp;</td>
	</tr>
</table>
<p align="center"><font face="Bradley Hand ITC" color="#FFFFFF" size="4"><b> <span 

style="background-color: black">OPTIONS</span></b></font><font size="1"><br>
  <font size="2">Click A,B,C or D to answer the question. Click the best option. </font></font></p>
<table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" 

width="100%" bordercolorlight="#000080" bordercolordark="#800000" bordercolor="#000080" 

bgcolor="white">
	<tr>
		<td width="49"><p align="left">
		
		

		
		<form method="POST" action="answer_clicked_a.php">
			
						<?php 
			$query1 =mysql_query("select id from $query_coursecode where 

question = '$now'");
             $move =mysql_result($query1, 0, "id"); 
             ?>
			<input type="submit" value="A" name="submit" style="float: left">
			<input type="hidden" name="move_number" size="20" value='<?php
	echo mysql_result($query1, 0, "id");
	?>'>
			</p>
		</form>
		</td>
		<td font size="+8">
		
		
		<?php
		// THE BLOCK OF CODES BELOW, PRINTS OUT THE OPTIONS FOR EACH INDIVIDUAL 

//QUESTION BESIDE EACH OPTION BUTTON
		
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'A'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);


echo "<table border = 0>";


//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?></td>
	</tr>
	<tr>
		<td width="49" height="44">
		<form method="POST" action="answer_clicked_b.php">
			<!--webbot bot="SaveResults" U-File="C:\Program 

Files\EasyPHP1-7\www\smartquiz\_private\form_results.csv" S-Format="TEXT/CSV" 

S-Label-Fields="TRUE" -->
			<p><input type="submit" value="B" name="submit" style="float: left">
			<input type="hidden" name="move_number" size="20" value="<?php
	echo mysql_result($query1, 0, "id");?>"/>
			</p>
		</form>
		</td>
		<td height="44"><?php
	
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'B'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);


echo "<table border = 0>";

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?>&nbsp;</td>
	</tr>
	<tr>
		<td width="49">
		<form method="POST" action="answer_clicked_c.php">
			<!--webbot bot="SaveResults" U-File="C:\Program 

Files\EasyPHP1-7\www\smartquiz\_private\form_results.csv" S-Format="TEXT/CSV" 

S-Label-Fields="TRUE" -->
			<p><input type="submit" value="C" name="submit" style="float: left">
			<input type="hidden" name="move_number" size="20" value="<?php
	echo mysql_result($query1, 0, "id");?>"/>
			</p>
		</form>
		</td>
		<td><?php
$query =("select obj from $query_coursecode where id = '$number' and alpha = 'C'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);


echo "<table border = 0>";

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

?>&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td width="49">
		<form method="POST" action="answer_clicked_d.php">
			<!--webbot bot="SaveResults" U-File="C:\Program 

Files\EasyPHP1-7\www\smartquiz\_private\form_results.csv" S-Format="TEXT/CSV" 

S-Label-Fields="TRUE" -->
			<p><input type="submit" value="D" name="submit" style="float: left">
			<input type="hidden" name="move_number" size="20" value="<?php
	echo mysql_result($query1, 0, "id");?>"/>
			</p>
		</form>
		<p></td>
		<td><?php

$query =("select obj from $query_coursecode where id = '$number' and alpha = 'D'");
$result = mysql_query($query)
or die (mysql_error());
$num_fields = mysql_num_fields($result);

echo "<b>\n";
echo "<table border = 0>";

//create table body
echo "<b>\n";
echo "<tr font size=+10>";
while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
echo "<b>\n";
echo "<b>";
while( list ($key, $value) = each($row) )
{
echo "<b>\n";
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";



// OPTION PRINTING ENDS
?>&nbsp;&nbsp;</td>
	</tr>
</table>

<p>&nbsp;</p>
</body>

</html>
<?php
}

?>