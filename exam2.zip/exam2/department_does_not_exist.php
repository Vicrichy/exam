<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST ::: Error</title>
<meta http-equiv="Page-Enter" content="blendTrans(Duration=4.0)">
</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="100%">
	
  <tr bgcolor="#333333"> 
    <td height="41" colspan="3"> <font face="Bodoni MT Black" color="#FFFFFF">&nbsp;</font></td>
  </tr>
	<tr>
		<td height="27" colspan="3" bgcolor="#808080">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="20%" bgcolor="#333333">&nbsp;</td>
		<td width="62%" bgcolor="#000000" valign="top">
		&nbsp;<p align="center"><font face="Arial Black" size="7">&nbsp;&nbsp;&nbsp; 
		</font><font face="Arial Black" style="font-size: 45pt" color="#FF0000">
		ERROR !</font></p>
		<p align="center"><font color="#FFFFFF" face="Arial Black" size="5">&nbsp;&nbsp;&nbsp;</font><font color="#FFFFFF" face="Arial Black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
		THE SPECIFIED </font><u><font color="#FFFF00" face="Arial Black">DEPARTMEN</font></u><font color="#FFFFFF" face="Arial Black"> WAS NOT 
		FOUND.</font><font color="#FFFFFF" face="Arial Black" size="5">&nbsp;&nbsp;<br>
        </font><i><font color="#FFFFFF" face="Arial" size="2">Either it 
        does not exist in this institution, or it was not written exactly as it 
        was createdin the database.<br>
		<br>
        </font></i><font color="#FFFFFF" face="Arial Black" size="5"><br>
		</font><b><i><font face="Arial Black" size="5" color="#00FFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</font><font face="Arial Black" size="5" color="#FF0000">RECORD <u>NOT</u> 
		SAVED</font></i></b></p>
		<p align="center"><font face="Arial Black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#FF0000"> </font>
		<a href="javascript:history.back()">[ RETRY ]</a></font></td>
		
    <td width="18%" bgcolor="#333333">&nbsp;</td>
	</tr>
	<tr>
		<td height="26" width="100%" bgcolor="#808080" colspan="3">&nbsp;</td>
	</tr>
	
  <tr bgcolor="#333333"> 
    <td height="26" width="100%" colspan="3"><div align="center"></div></td>
	</tr>
</table>

</body>

</html>
