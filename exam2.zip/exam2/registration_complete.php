<?php
session_start();
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST ::: Registration Complete!</title>
<meta http-equiv="Page-Enter" content="blendTrans(Duration=4.0)">
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
.style3 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #003300;
}
.style8 {font-family: Verdana, Arial, Helvetica, sans-serif; color: #660000; }
-->
</style>
</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="449">
	<tr>
		<td height="55" colspan="3" bgcolor="#006600">
		<font face="Bodoni MT Black" color="#FFFFFF">&nbsp;</font></td>
	</tr>
	<tr>
		<td height="36" colspan="3" bgcolor="#808080"><div align="center" class="style1">REGISTRATION COMPLETE </div></td>
	</tr>
	<tr>
		<td width="20%" bgcolor="#006600" height="290">&nbsp;</td>
		<td width="63%" bgcolor="#FFFFFF" valign="top" height="290">
		<a href="receipt.php"><span class="style3">Click Here to print out receipt</span> &nbsp;
		</a>
		<p>
		 
		  <font color="#FFFFFF" face="Arial Black">RDED. </font>
		  <font color="#FFFFFF" face="Arial Black" size="5"><br>
	      </font><span class="style3"><font size="5">Congratulations <font color ="#006600"><b><u><?php echo "$_SESSION[full_name]"; ?></u></b></font>, your registration was completed successfully.</font></span></p>
		<p class="style3"><strong>YOUR TEMPORARY REG NO IS:</strong><?php echo "$_SESSION[reg_no]";?></p>
		<p class="style3"><strong>YOUR PASSWORD IS:</strong> <u><font color ="#006600"><b><u><?php echo "$_SESSION[password]"; ?></u></b></font></u> </p>
		<p><?php
	   $pixs = $_SESSION['pix'] ;
	  echo "<img src = 'pix/$pixs' height = '95' width = '100'>";
	 // echo "No picture available";
	  ?>
	 </p>
		<p><span class="style8">PLEASE WRITE YOUR PASSWORD DOWN, AND KEEP IT SAFELY.</span> <font color="#FFFFFF" face="Arial Black" size="5"><br>
	      </font><b><i><font face="Arial Black" size="5" color="#00FFFF">&nbsp;&nbsp;&nbsp;
	        </font></i></b></p>
		<p align="center"><font face="Arial Black"><font color="#FF0000">&nbsp;</font><a href="candidate_login.php">[ 
	  PROCEED ]</a></font><br>
        <br>
        <font face="Impact">
      <marquee bgcolor="#00FF00">Now, you can take your test.... We trust that you are well prepared, and we wish you the best of luck!. Enjoy the experience.</marquee></font></p></td>
		<td width="17%" bgcolor="#006600" height="290">&nbsp;</td>
	</tr>
	<tr>
		<td height="34" width="100%" bgcolor="#808080" colspan="3">&nbsp;</td>
	</tr>
	<tr>
		<td height="34" width="100%" bgcolor="#006600" colspan="3">&nbsp;</td>
	</tr>
</table>

</body>
</html>
</html>