<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>E-TEST Testing Engine [CONTROL PANEL]</title>
<style type="text/css">
<!--
body {
	background-color: #CCCCFF;
}
.style1 {color: #000000}
.style2 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
</head>

<body>

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array( "course","course_type","question_text","option_a","option_b","option_c","option_d","select");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array( "COURSE NAME","COURSE TYPE","QUESTION","OPTION A","OPTION B","OPTION C","OPTION D","CORRECT OPTION");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>




<script language="JavaScript">

function formCheck2(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type","question_text","option_true","option_false","select");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE", "COURSE TYPE", "QUESTION","OPTION TRUE","OPTION FALSE","CORRECT OPTION");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>






<script language="JavaScript">

function formCheck3(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type","question_text","option_a","option_b","option_c","option_d","correct_option");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE","COURSE TYPE","QUESTION","OPTION A","OPTION B","OPTION C","OPTION D","CORRECT OPTION");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>






<script language="JavaScript">

function formCheck4(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type","qid","desired");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE","COURSE TYPE","QUESTION ID","DESIRED TEXT");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>












<script language="JavaScript">

function formCheck5(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type","qid","option","desired");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE","COURSE TYPE","QUESTION ID","OPTION","DESIRED TEXT");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<script language="JavaScript">

function formCheck6(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type","qid","option");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE","COURSE TYPE","QUESTION ID","CORRECT OPTION");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>




<script language="JavaScript">

function formCheck7(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE NAME","COURSE TYPE");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>


<script language="JavaScript">

function formCheck8(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE NAME","COURSE TYPE");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>



<script language="JavaScript">

function formCheck10(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("course","course_type","delete");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("COURSE","COURSE TYPE","QUESTION ID");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>







<p align="center"><span style="background-color: #000000"><b>
<font face="Copperplate Gothic Bold" size="5" color="#FFFFFF">MANAGE TEST 
QUESTIONS</font></b></span></p>
<p align="left"><font color="#FF0000" face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000" face="Arial Black">&lt;&nbsp;GO BACK</font></a></p>
<p align="left"><span style="background-color: #000080"><b>
<font face="Verdana" color="#FFFFFF">INSERT/UPLOAD TEST QUESTIONS</font></b></span></p>
<form method="POST" action="insert_question_stage1.php" onSubmit="return formCheck3(this)">
  <table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bordercolor="#000080">
    <tr> 
      <td bgcolor="#006600" colspan="3">
	  <p align="center"></td>
    </tr>
    <tr> 
      <td bgcolor="#CCCCCC" colspan="3">&nbsp;</td>
    </tr>
    <tr> 
      <td width="363" bgcolor="#006600"><font color="#FFFFFF">SPECIFY COURSE 
		NAME </font></td>
      <td width="182" bgcolor="#006600">&nbsp;</td>
      <td bgcolor="#006600">&nbsp;</td>
    </tr>
    <tr> 
      <td bgcolor="#CCCCCC" colspan="3"><br>
        <select name="course" id="course">
          <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
        </select>
        <br>
&nbsp;</td>
    </tr>
    <tr> 
      <td width="363" bgcolor="#006600"><font color="#FFFFFF">INSERT QUESTION</font></td>
      <td width="182" bgcolor="#006600">&nbsp;</td>
      <td bgcolor="#006600"><font color="#FFFFFF">INSERT OPTIONS</font></td>
    </tr>
    <tr> 
      <td width="363" colspan="2" valign="top" bgcolor="#CCCCCC"><font color="#000080"><b><span style="background-color: #00FFFF"> 
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; QUESTION&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        </span></b> </font> <p>
          <textarea rows="5" name="question_text" cols="40"></textarea>
        </p>
      <p></td>
      <td valign="top" bgcolor="#CCCCCC"><br>
        <font color="#000080"><b><span style="background-color: #00FFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        OPTIONS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b></font> 
        <p>A 
          <input name="option_a" type="text" id="option_a" size="55" onKeyUp="javascript:this.value=this.value.toUpperCase();" onBlur="this.onkeyup">
        </p>
        <p>B 
          <input name="option_b" type="text" id="option_b" size="55" onKeyUp="javascript:this.value=this.value.toUpperCase();" onBlur="this.onkeyup">
        </p>
        <p>C 
          <input name="option_c" type="text" id="option_c" size="55" onKeyUp="javascript:this.value=this.value.toUpperCase();" onBlur="this.onkeyup">
        </p>
        <p>D 
          <input name="option_d" type="text" id="option_d" size="55" onKeyUp="javascript:this.value=this.value.toUpperCase();" onBlur="this.onkeyup">
        <p> 
        <p><span class="style1">Correct option =</span>
          <select name="correct_option" id="correct_option">
            <option selected > </option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
          </select>
        
        <p><br>
      </td>
    </tr>
  </table>
	<p align="center">
    <input type="submit" value="UPLOAD QUESTION" name="B1">
    &nbsp;&nbsp;&nbsp;
	<input type="reset" value="RESET" name="B2"></p>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="98%" border="1" bordercolor="#0000FF">
  <tr bgcolor="#000066"> 
    <td width="50%" bgcolor="#006600"><font color="#FFFFFF">VIEW QUESTIONS &amp; OPTIONS </font></td>
    <td width="50%" bgcolor="#006600"><font color="#FFFFFF">DELETE A QUESTION</font></td>
  </tr>
  <tr> 
    <td height="18" rowspan="3" bgcolor="#CCCCCC">
<form action="sh_all_stage1_questions.php" method="post" name="" onSubmit="return formCheck8(this)">
        <div align="left">
          COURSE NAME<br>
          <select name="course" id="course">
            <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
                    </select>
          <br>
            <br>
            COURSE TYPE <br>
            <select name="course_type" id="course_type">
              <option selected></option>
              <option>Quiz</option>
              <option>Exam</option>
              <option>Exam Re-sit</option>
            </select>
            <p class="style1">
            <input type="submit" name="Submit" value="VIEW QUESTIONS &amp; OPTIONS">
          </p>
        </div>
      </form>
	  <table width="100%" border="0">
        <tr>
          <td bgcolor="#006600"><font color="#FFFFFF">VIEW QUESTIONS ONLY </font></td>
        </tr>
      </table>
      <form action="sh_all_stage1_questions_only.php" method="POST" onSubmit="return formCheck8(this)">
        <span class="style1">
        <!--webbot bot="SaveResults" U-File="C:\Program Files\EasyPHP1-7\www\datamix\_private\form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
        COURSE NAME<br>
        </span>
        <select name="course" id="course">
          <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
                </select>
        <br>
        <br>
        COURSE TYPE
        <br>
        <select name="course_type" id="course_type">
          <option selected></option>
          <option>Quiz</option>
          <option>Exam</option>
          <option>Exam Re-sit</option>
        </select>
        <br>
        <br>
        <input type="submit" value="VIEW QUESTIONS ONLY" name="B3">
      </form>
    <p>&nbsp;</p></td>
    <td valign="top" bgcolor="#CCCCCC"> <form action="delete_stage1_questions.php" method="post" name="" onSubmit="return formCheck10(this)">
        <p><span class="style1"> COURSE NAME 
            <select name="course" id="course">
              <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
                        </select>
          <br>
          COURSE TYPE    
          &nbsp;&nbsp;<select name="course_type" id="course_type">
            <option selected></option>
            <option>Quiz</option>
            <option>Exam</option>
            <option>Exam Re-sit</option>
          </select>
          <br>
          SPECIFY QUESTION ID</span> 
          <input name="delete" type="text" id="delete" size="5">
        </p>
        <p> 
          <input type="submit" name="Submit2" value="DELETE QUESTION">
        </p>
      </form>    </td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#006600"><span class="style2">DELETE ALL QUESTIONS </span></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#FF0000"><form action="wipeout_questions.php" method="post" name="" onSubmit="return formCheck7(this)">
      <p><span class="style1"> COURSE NAME
          <select name="course" id="course">
            <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
                    </select>        
          <br>
        <br>
        COURSE TYPE 
        &nbsp;&nbsp;<select name="course_type" id="course_type">
          <option selected></option>
          <option>Quiz</option>
          <option>Exam</option>
          <option>Exam Re-sit</option>
        </select>
          <br>
      </span></p>
      <p align="center">
        <input name="Submit22" type="submit" value="GO">
      </p>
    </form></td>
  </tr>
  <tr> 
    <td height="19" bgcolor="#006600"><font color="#FFFFFF">MODIFY QUESTION </font></td>
    <td valign="top" bgcolor="#006600"><font color="#FFFFFF">MODIFY OPTION </font></td>
  </tr>
  <tr> 
    <td height="184" rowspan="3" valign="top" bgcolor="#CCCCCC"> 
      <form name="form1" method="post" action="modify_questions_stage1.php" onSubmit="return formCheck4(this);">
        <p><span class="style1">COURSE NAME<br>
          <select name="course" id="course">
            <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
                    </select>
        </span><br>
          <br>
        COURSE TYPE<br>
        <span class="style1">
        <select name="course_type" id="course_type">
          <option selected></option>
          <option>Quiz</option>
          <option>Exam</option>
          <option>Exam Re-sit</option>
        </select>
        </span></p>
        <p class="style1"> SPECIFY QUESTION ID <br>
          <input name="qid" type="text" id="delete22" size="5">
        </p>
        <p class="style1">ENTER THE DESIRED TEXT</p>
        <p> 
          <textarea name="desired" cols="40" rows="5" id="desired"></textarea>
          <br>
          <br>
          <input type="submit" name="Submit3" value="MODIFY QUESTION">
          <input type="reset" name="Submit5" value="Reset">
        </p>
      </form>
    <p>&nbsp;</p></td>
    <td valign="top" bgcolor="#CCCCCC"><form name="form1" method="post" action="#" onSubmit="return formCheck5(this);">
        <p class="style1">COURSE NAME<br>
          <select name="course" id="course">
            <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
                    </select>
        <br>
          <br>
          COURSE TYPE <br>
          <select name="course_type" id="course_type">
            <option selected></option>
            <option>Quiz</option>
            <option>Exam</option>
            <option>Exam Re-sit</option>
          </select>
        </p>
        <p class="style1">SPECIFY QUESTION ID <br>
          <input name="qid" type="text" id="delete22" size="5">
        </p>
        <p class="style1">SPECIFY OPTION<br>
          <select name="option" id="option">
            <option selected></option>
            <option>A</option>
            <option>B</option>
            <option>C</option>
            <option>D</option>
          </select>
        </p>
        <p class="style1">ENTER THE DESIRED TEXT</p>
        <p> 
          <input name="desired" type="text" id="desired" size="55">
          <br>
          <br>
          <input type="submit" name="Submit3" value="MODIFY OPTION">
          <input type="reset" name="Submit6" value="Reset">
        </p>
      </form>
    �</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#006600"><font color="#FFFFFF">CHANGE THE CORRECT 
      OPTION</font></td>
  </tr>
  <tr> 
    <td height="104" valign="top" bgcolor="#CCCCCC"> 
      <form name="form2" method="post" action="#" onSubmit="return formCheck6(this);">
        <font size="2"><span class="style1">COURSE NAME 
        <select name="select" id="select">
          <?php
				include('dbconnect.php');
				$sql = mysql_query("SELECT `course` FROM `course_list` ORDER BY course")or die(mysql_error());
				while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 
	 foreach($rows as $col_value)
	 {
	   echo "<option>$col_value</option>";	   
	   
	   
	  } 
	
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	  
	 }

				
				?>
        </select>        
        <br>
        COURSE TYPE 
        &nbsp;&nbsp;<select name="course_type" id="course_type">
          <option selected></option>
          <option>Quiz</option>
          <option>Exam</option>
          <option>Exam Re-sit</option>
        </select>
        <br>
        S PECIFY QUESTION ID 
        <input name="qid" type="text" id="delete222" size="5">
        <br>
        <br>
        SELECT THE DESIRED CORRECT OPTION</span></font><font color="#FFFFFF" size="2"> 
        <select name="option" id="option">
          <option selected></option>
          <option>A</option>
          <option>B</option>
          <option>C</option>
          <option>D</option>
        </select>
        <br>
        <br>
        <input type="submit" name="Submit4" value="CHANGE">
        <input type="reset" name="Submit7" value="Reset">
        </font> 
      </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr> 
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p><br>
</p>
<table width="100%" border="0" bgcolor="#000000">
  <tr> 
    <td bgcolor="#009900">&nbsp;</td>
  </tr>
</table>
&nbsp;</P> 
</body>

</html>

<?php
}
?>