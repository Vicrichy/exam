<?php
//session_start();
// FIRST, LETS DELETE THIS registration_table PRE-EXISTING RECORD
include('dbconnect.php');
//$reg_no = $_POST['reg_no'];
$moved_regno = $_POST['move_reg']; // this is the value of a hidden field
//$query_delete = "DELETE FROM registration_table WHERE reg_no = '$_SESSION[reg_no]'";
//$resultd = mysql_query($query_delete);
if ( isset($_POST['B1']) ){
// THEN INSERT THE NEWLY MODIFIED DATA
//uncomment for debugging
echo $reg_no =$_POST['reg_no'];
$surname =$_POST['surname'];
$first_name =$_POST['firstname'];
$othernames =$_POST['othernames'];
//$department =$_POST['department'];
//$department2 =$_POST['department2'];
$reg_no =$_POST['reg_no'];
//$batch_no =$_POST['batch_no'];
//$classroom =$_POST['classroom'];
//$trainer =$_POST['trainer'];
//$testmode =$_POST['testmode'];
$gender =$_POST['gender'];
$course =$_POST['course'];
$password =$_POST['password'];
$reg_date =$_POST['reg_date'];
$address =$_POST['address'];
$phone =$_POST['phone'];
//$email=$_POST['email'];
 
 // RETRIEVE other stuffs

$query10 =mysql_query("select quiz from registration_table where reg_no = '$reg_no'");
$quiz =mysql_result($query10, 0, "quiz");

$query11 =mysql_query("select exam from registration_table where reg_no = '$reg_no'");
$exam =mysql_result($query11, 0, "exam");

$query12 =mysql_query("select exam_resit from registration_table where reg_no = '$reg_no'");
$exam_resit =mysql_result($query12, 0, "exam_resit");
   // INSERT TO DATABASE
//global $link ;
 $update_Student =( "UPDATE registration_table SET reg_date='$reg_date', password='$password', reg_no='$reg_no', surname='$surname', first_name='$first_name', othernames='$othernames', gender='$gender', course='$course', quiz='$quiz', exam='$exam', exam_resit='$exam_resit', address='$address',phone='$phone' WHERE reg_no='$reg_no'");
$result3 = mysql_query($update_Student);
	//confirm_query($result_set);
			//mysql_close($link); 
 //$result = mysql_query($query);
			 
			  //echo $query . "<br>\n";
 
          //include('dbconnect.php');	
			
// MODIFY THE DEPARTMENT IN TEST_RECORDS	

//$update_dept = mysql_query("UPDATE test_records SET department = '$department2' WHERE reg_no = '$reg_no'");		
mysql_close($link); 	  
//we should state the order was sent
header('Location: record_modified_data.php');
}
?>