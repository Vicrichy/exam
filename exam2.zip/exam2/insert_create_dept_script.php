<?php

$dept_name =$_POST['dept_name'];
//$credit_load =$_POST['credit_load'];
//$course_cost =$_POST['course_cost'];




include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{



// CHECK IF THE COURSE EXISTS

$query2="Select department from departments_table where department = '$dept_name'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) > 0 ) {
header('Location: dept_already_exists.php');
mysql_close($link);
} 
else 
{




// INSERT TO DATABASE 


include('dbconnect.php');

$query  = "INSERT INTO departments_table
              ( department )";
			
  $query .= " VALUES
             ( '$dept_name' )";
			 
			 $result = mysql_query($query);




header('Location: department_created.php');

mysql_close($link);

}
}

?>