<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST [ERROR!]</title>
<meta http-equiv="Page-Enter" content="blendTrans(Duration=4.0)">
<style type="text/css">
<!--
.style1 {
	color: #00FF00;
	font-style: italic;
	font-size: 16px;
}
-->
</style>
</head>

<body>
<?php

$test_type = $_POST['test_type'];
?>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="100%">
	
  <tr bgcolor="#333333"> 
    <td height="41" colspan="3" bgcolor="#003300"> <font face="Bodoni MT Black" color="#FFFFFF">&nbsp;</font></td>
  </tr>
	<tr>
		<td height="27" colspan="3" bgcolor="#808080">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="20%" bgcolor="#333333">&nbsp;</td>
		<td width="62%" bgcolor="#000000" valign="top">
		&nbsp;<p align="center"><font face="Arial Black" size="7">&nbsp;&nbsp;&nbsp;</font><span style="font-size: 9pt"><font face="Arial Black" style="font-size: 35pt" color="#FF0000">ACCESS DENIED </font></span></p>
		<p align="center" class="style1"><font face="Arial Black">Incorrect Password for user. 
		</font></p>
		<p align="center"><font face="Arial Black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#FF0000"> </font>
		<a href="javascript:history.back()">[ RETRY ]</a></font></td>
		
    <td width="18%" bgcolor="#333333">&nbsp;</td>
	</tr>
	<tr>
		<td height="26" width="100%" bgcolor="#808080" colspan="3">&nbsp;</td>
	</tr>
	
  <tr bgcolor="#333333"> 
    <td width="100%" height="26" colspan="3" bgcolor="#003300"><div align="center"></div></td>
  </tr>
</table>

</body>

</html>
