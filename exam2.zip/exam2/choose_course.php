<?php
$code = addslashes($_POST['code']);
	$month = addslashes($_POST['month']);
	$year = addslashes($_POST['year']);
	$no = addslashes($_POST['no']);
	$reg_no = $code.''.$month.'/'.$year.'/'.$no;
	
	include('dbconnect.php');
	$query = mysql_query("SELECT `course` FROM `mycourses` WHERE `reg_no` = '$reg_no' AND `status` = 'NOT WRITTEN'")or die(mysql_error());
	$num_rows = @mysql_num_rows($query);
	if($num_rows<1)
	{
	?>
	<script type="text/javascript">
	alert("Sorry! Reg No not found. Please make sure you are registered");
	window.location = "index.php";
	</script>
	<?php
	}
	
	?>
<html>


<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>E-TEST ::: Test Login</title>
<style type="text/css">
<!--
.style2 {
	font-family: "Century Gothic";
	font-weight: bold;
}
-->
</style>
</head>

<body bgcolor="#FFFFFF">

<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("test_type","course","code", "no","name","department");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("TEST TYPE","COURSE","CODE","REG NO","NAME","DEPARTMENT");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="91%" align="center">
<?php

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

include('dbconnect.php');



// DISABLE PREVIOUS DAYS TEST SCHEDULE


// Disable Quiz, Exam or Exam Re-sit.

$delete1 = "DELETE FROM candidate_login_table WHERE test_date != '$system_date'";
$result = mysql_query($delete1);


$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "/";

$ans_date = $computer_date_day.$dash.$computer_date_month.$dash.$computer_date_year ;

$delete2 = "DELETE FROM answered_questions WHERE exam_date != '$ans_date'";
$result2 = mysql_query($delete2);



?>


  <tr bgcolor="#006600"> 
    <td colspan="6" bgcolor="#000000">&nbsp; 
      <p align="center"><br>
    &nbsp;</td>
  </tr>
  <tr> 
    <td valign="top" bgcolor="#CCFF99" colspan="5" height="98">
	<p align="center"><font face="Copperplate Gothic Bold">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>ELECTRONIC 
	EXAMINATION SYSTEM</u></font><br>
	</p>
	<p>     
	<form method="POST" action="authenticate_candidate_script.php" onSubmit="return formCheck(this);">
    
	<p><br>
    <td width="22%" valign="top" bgcolor="#006600" rowspan="12" bordercolor="#008000"> 
      <p align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
        &nbsp;<font face="Verdana" size="2"><span style="font-weight: 700; background-color: #FFFF00">COURSE 
		LIST</span></font><br>
		<iframe name="I1" width="146" height="289" src="course_list_frame.php">
      Your browser does not support inline frames or is currently configured not to display inline frames.</iframe></p>      </td>
  
  <tr> 
    <td valign="top" bgcolor="#000000" colspan="5">
	<font face="Small Fonts" color="#FFFFFF" style="font-size: 11pt">
	<marquee behavior="alternate" scrollamount="5">
	PLEASE CHOOSE YOUR COURSE
	</marquee></font></td>
  </tr>
  <tr>
    <td width="12%" rowspan="7" valign="top" bgcolor="#000000">&nbsp;</td>
    <td height="21" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td width="26%" height="21" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td height="21" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td width="20%" rowspan="7" valign="top" bgcolor="#000000">&nbsp;</td>
  </tr>
  
  <tr>
    
  <tr>
    <td width="11%" valign="top" bgcolor="#CCFF99" class="style2"><div align="center">Course</div></td>
    <td valign="top" bgcolor="#CCFF99"><label>
    <select name="course" id="course">
	<?php
	include('dbconnect.php');
	$query3 = mysql_query("SELECT `course` FROM `mycourses` WHERE `reg_no` = '$reg_no' AND status = 'NOT WRITTEN'")or die(mysql_error());

echo "<option selected></option>";
while ($row = mysql_fetch_array($query3, MYSQL_ASSOC))
{

foreach($row as $value){
echo "<option>";
echo "$value";
echo "</option>";

}}
	?>
    </select>
    </label></td>
    <td width="8%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
  </tr>
  <tr>
    <td width="11%" valign="top" bgcolor="#CCFF99" class="style2">&nbsp;</td>
    <td valign="top" bgcolor="#CCFF99"><label>
    <input name="reg_no" type="hidden" id="reg_no" value="<?php echo $reg_no;?>">
    </label></td>
    <td width="8%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
  </tr>
  <tr>
    <td width="11%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
    <td valign="top" bgcolor="#CCFF99">&nbsp;</td>
    <td width="8%" valign="top" bgcolor="#CCFF99">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CCCCCC">&nbsp;</td>
    <td valign="top" bgcolor="#CCCCCC"><input type="submit" value="Login" name="login"></td>
    <td valign="top" bgcolor="#CCCCCC">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#000000" colspan="2"></td>
    <td valign="top" bgcolor="#000000">
      <div align="left"></form>
        </td><td valign="top" bgcolor="#000000">&nbsp;</td>
    <td valign="top" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CCFF99" colspan="5" height="22">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#CCFF99" colspan="5"><div align="center">
      <font color="#00FF00"><strong><span style="background-color: #000000">
      <a href="students_registration_login_page.php" style="text-decoration: none"></a></span></strong></font></div></td>
  </tr>
  <tr> 
    <td bgcolor="#000000" valign="bottom" colspan="5">
	<p align="center">&nbsp; 
      <img border="0" src="images/book.gif" width="83" height="47"><font color="#FFFF00"><b>
      <marquee></marquee>
    </b></font></td>
    <td width="23%" valign="bottom" bgcolor="#000000"><font size="2"><font color="#00FF00">
	Powered by</font> <font color="#FFFF00"><br>
	e-NERGY Software Solutions. 08039098042 </font>&nbsp;</font></td>
  </tr>
</table>

</body>

</html>