<?php
session_start();
$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Pacific Computer::Admission Letter</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style2 {
	font-size: 16px;
	font-weight: bold;
}
.style6 {
	font-size: 18px;
	font-weight: bold;
}
.style8 {
	font-size: 20px;
	font-weight: bold;
}
.style3 {font-size: 9px}
.style9 {
	font-size: 14px;
	font-style: italic;
}
.style10 {font-size: 16px}
.style11 {font-size: 18px}
.style12 {
	font-size: 18;
	font-weight: bold;
}
-->
</style></head>

<body onload="window.print();">
<table width="790" border="0" align="left" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td colspan="2" rowspan="2" valign="top"><img src="logos.JPG" alt="logo" width="121" height="128" /></td>
    <td height="88" colspan="4" valign="top"><p class="style8">PACIFIC COMPUTER AND MANAGEMENT COLLEGE NIGERIA LIMITED </p>      <p>&nbsp; </p></td>
    <td width="45">&nbsp;</td>
  </tr>
  <tr>
    <td width="274" height="59">&nbsp;</td>
    <td colspan="3" rowspan="2" valign="top"><p><strong>119 Ndidem Usang Iso Road,</strong></p>
      <p><strong>Calabar,</strong></p>
    <p><strong>Cross River State</strong></p>      <p><strong>08035838500, 08033009035</strong></p></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="59" colspan="2" valign="top"><strong>RC. 355641 </strong></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="14" colspan="6" valign="top"><hr /></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2" rowspan="2" valign="top"><p><strong>Ref: PCMC/ADM/</strong></p>    </td>
    <td height="22" valign="top"><span class="style11"> <?php echo $_SESSION['name'];?></span>&nbsp;</td>
    <td height="28" colspan="3" rowspan="2" valign="top"><strong>Date:</strong> <?php echo $system_date;?></td>
  <td rowspan="2"></td>
  </tr>
  <tr>
    <td height="23" valign="top"><hr /></td>
  </tr>
  <tr>
    <td colspan="3" valign="top"><hr /></td>
    <td width="35" height="22">&nbsp;</td>
    <td width="236">&nbsp;</td>
    <td width="25"></td>
    <td></td>
  </tr>
  <tr>
    <td width="126" height="13"></td>
    <td width="49"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="26"></td>
    <td colspan="4" valign="top" bordercolor="#000033" border=1><span class="style6">OFFER OF PROVISIONAL ADMISSION </span></td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="160" colspan="4" valign="top"><p class="style9">For: Diploma/Certificate in</p>
      <p class="style10"><strong>- Information Technology</strong></p>
      <p class="style10"><strong>- Computer Repairs and Maintenance</strong></p>
    <p class="style10"><strong>- Hardware and Solar Energy Technology</strong></p>      <p class="style10"><strong>- Computer Studies/Secretarial Administration    </strong></p></td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="493" colspan="7" valign="top"><p>&nbsp;</p>
      <p class="style2">With reference to your application for admission to the above Certificate/Diploma </p>
      <p class="style2">programmes, I write on behalf of the Admission/Examination Committee to offer you provisional admission to the programme to study:<span class="style11"><?php echo $_SESSION['course'];?></span> With effect from:<span class="style11"><?php echo $_SESSION['date'];?></span></p>
      <p class="style2">The programme will last for <strong>Six Months</strong> and you will be required to attend lectures at: <span class="style11"><?php echo $_SESSION['venue'];?></span></p>
      <p class="style2">This offer of admission will lapse if you have not registered and paid the prescribed fees </p>
      <p class="style2">within the approved period. Payment of the prescribed course fees will be regarded as </p>
      <p class="style2">acceptance of this offer.</p>
      <p class="style2">Please accept my congratulations.</p>
      <p class="style2">Yours Faithfully,</p>
      <p class="style3">&nbsp;</p>
    <p class="style2">...............................................................</p>      <p class="style2">For: Admission Committee </p></td>
  </tr>
</table>
</body>
</html>
