<?php
session_start();

include('dbconnect.php');

$n_name = addslashes($_POST['name']);
$n_code = addslashes($_POST['code']);
$n_date = addslashes($_POST['date']);
$n_amount = addslashes($_POST['amount']);
$n_course = addslashes($_POST['course']);


$query = mysql_query("UPDATE `receipt` SET `name` = '$n_name',`code` = '$n_code',`date` = '$n_date',`amount` = '$n_amount',
`course` = '$n_course' WHERE `reg_no` = '$_SESSION[reg_no]'");

session_register['$n_name'];
session_register['$n_code'];
session_register['$n_date'];
session_register['$n_amount'];
session_register['$n_course'];

$_SESSION['n_name'] = $n_name;
$_SESSION['n_code'] = $n_code;
$_SESSION['n_date'] = $n_date;
$_SESSION['n_amount'] = $n_amount;
$_SESSION['n_course'] = $n_course;

header("location:n_receipt.php");
?>