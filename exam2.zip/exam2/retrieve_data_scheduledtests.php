<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>DATAMIX</title>
</head>

<body bgcolor="#CC99FF">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
  <tr bgcolor="#000000"> 
    <td colspan="5"> <p align="right"> <b><font size="2" color="#008000"> <a href="file:///C|/Program%20Files/EasyPHP1-7/www/zenon2.0/help.html"> 
        </a></font><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;GO 
        BACK</font></a></font></b></p>
      <p align="center"> <font size="5">&nbsp;</font><b><font size="5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u><font color="#0000FF" face="Copperplate Gothic Bold">SCHEDULED 
        TESTS RECORDS</font></u></font></b></td>
  </tr>
  <tr> 
    <td width="49%" valign="top" bgcolor="#808000" colspan="3"><u> <font color="#FFFFFF"></font></u></td>
    <td width="50%" valign="top">&nbsp; </td>
    <td width="1%" bgcolor="#000000" rowspan="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="369" height="48" colspan="2" valign="top" bgcolor="#0033CC">&nbsp;<font size="2"><b> 
      <br>
&nbsp;<u><font color="#00FF00"><a href="retrieve_data_scheduler_reg.php"><font color="#00FF00">REGISTRATION RECORDS &gt;&gt;</font></a></font></u></b></font><p>
	<font size="2"><b>&nbsp;<u><font color="#00FF00"><a href="test_results.php"><font color="#00FF00">TEST RESULTS &gt;&gt;</font></a></font></u></b></font></p>
	  <p><font size="2"><b>&nbsp;<u><font color="#00FF00"><a href="retrieve_data_scheduledtests.php"><font color="#00FF00">SCHEDULED 
        TESTS &gt;&gt;</font></a></font></u><br>
	&nbsp; </b></font></p></td>
    <td width="37%" height="48" colspan="2" valign="top" bgcolor="#CC99FF">&nbsp;</td>
  </tr>
  <tr> 
    <td width="75%" height="47" colspan="4" valign="top" bgcolor="#CC99FF">&nbsp;
      <form method="POST" action="show_scheduled_tests.php">
        <p align="center"> 
          <input type="submit" value="SHOW ALL SCHEDULED TESTS" name="B1">
        </p>
      </form></td>
  </tr>
  <tr> 
    <td width="49%" valign="top" height="19" bgcolor="#0033CC" colspan="3">&nbsp; </td>
    <td width="50%" valign="top" height="19" bgcolor="#0033CC">&nbsp;</td>
  </tr>
  <tr> 
    <td width="75%" valign="top" height="19" colspan="4" bgcolor="#000000"> <font color="#FFFF00">&nbsp;SEARCH 
      BY NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SEARCH 
      BY REG. DATE</font></td>
  </tr>
  <tr> 
    <td width="47%" valign="top" height="140"> <form method="POST" action="searchname_testschedule.php">
        <p><b>SURNAME</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="surname" size="20">
          <br>
          <b>FIRST NAME</b>&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="first_name" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B2">
        </p>
      </form>
      <p></td>
    <td width="2%" valign="top" height="140" rowspan="3" bgcolor="#000000" colspan="2">&nbsp;</td>
    <td width="50%" valign="top" height="140"><form method="POST" action="searchdate_testschedule.php">
        <p><font color="#000000"><b>DATE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          </b></font>&nbsp;&nbsp;&nbsp; <b><font size="2"> <b><font size="2"><b><font color="#CCCCCC"> 
          <select name="day" id="day">
            <option selected value=""></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
          </font></b></font></b> </font> </b><font size="2"><b> <font color="#CCCCCC"> 
          <select name="month" id="selectmonth" style="width:49; height:22">
            <option selected value=""></option>
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
            <option>6</option>
            <option>7</option>
            <option>8</option>
            <option>9</option>
            <option>10</option>
            <option>11</option>
            <option>12</option>
          </select>
          </font> 
          <select name="year" id="select" size="1">
            <option selected></option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
            <option value="2028">2028</option>
            <option value="2029">2029</option>
            <option value="2030">2030</option>
            <option value="2031">2031</option>
            <option value="2032">2032</option>
            <option value="2033">2033</option>
            <option value="2034">2034</option>
            <option value="2035">2035</option>
            <option value="2036">2036</option>
            <option value="2037">2037</option>
            <option value="2038">2038</option>
            <option value="2039">2039</option>
            <option value="2040">2040</option>
            <option value="2041">2041</option>
            <option value="2042">2042</option>
            <option value="2043">2043</option>
            <option value="2044">2044</option>
            <option value="2045">2045</option>
            <option value="2046">2046</option>
            <option value="2047">2047</option>
            <option value="2048">2048</option>
            <option value="2049">2049</option>
            <option value="2050">2050</option>
            <option value="2051">2051</option>
            <option value="2052">2052</option>
            <option value="2053">2053</option>
            <option value="2054">2054</option>
            <option value="2055">2055</option>
            <option value="2056">2056</option>
            <option value="2057">2057</option>
            <option value="2058">2058</option>
            <option value="2059">2059</option>
            <option value="2059">2060</option>
            <option value="2061">2061</option>
            <option value="2062">2062</option>
            <option value="2063">2063</option>
            <option value="2064">2064</option>
            <option value="2065">2065</option>
            <option value="2066">2066</option>
            <option value="2067">2067</option>
            <option value="2068">2068</option>
            <option value="2069">2069</option>
            <option value="2070">2070</option>
            <option value="2071">2071</option>
            <option value="2072">2072</option>
            <option value="2073">2073</option>
            <option value="2074">2074</option>
            <option value="2075">2075</option>
            <option value="2076">2076</option>
            <option value="2077">2077</option>
            <option value="2078">2078</option>
            <option value="2079">2079</option>
            <option value="2080">2080</option>
            <option value="2081">2081</option>
            <option value="2082">2082</option>
            <option value="2083">2083</option>
            <option value="2084">2084</option>
            <option value="2085">2085</option>
            <option value="2086">2086</option>
            <option value="2087">2087</option>
            <option value="2088">2088</option>
            <option value="2089">2089</option>
            <option value="2090">2090</option>
          </select>
          </b></font><br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          &nbsp;<br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
  </tr>
  <tr> 
    <td width="47%" valign="top" height="38" bgcolor="#000000">&nbsp;<font color="#FFFF00">SEARCH 
      BY REG. NUMBER</font></td>
    <td width="50%" valign="top" height="38" bgcolor="#000000">&nbsp;<font color="#FFFF00">SEARCH 
      BY COURSE</font></td>
  </tr>
  <tr> 
    <td width="47%" valign="top" height="242"> <form method="POST" action="searchregno_testschedule.php">
        <p><b>REG. NUMBER</b>&nbsp;&nbsp; 
          <input type="text" name="reg_no" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
    <td width="50%" valign="top" height="242"><form method="POST" action="searchcourse_testschedule.php">
        <p><b>COURSE</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="text" name="course" size="20">
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <input type="submit" value="SEARCH" name="B3">
        </p>
      </form></td>
  </tr>
  <tr> 
    <td colspan="5" bgcolor="#000000"> <p align="center"></td>
  </tr>
</table>

</body>

</html>