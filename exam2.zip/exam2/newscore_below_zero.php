<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST [ERROR!]</title>
<meta http-equiv="Page-Enter" content="blendTrans(Duration=4.0)">
<style type="text/css">
<!--
.style1 {
	color: #000099;
	font-style: italic;
	font-size: 16px;
	font-weight: bold;
}
.style2 {
	font-size: 36px;
	font-weight: bold;
	color: #FF0000;
}
.style3 {
	font-size: 18px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<?php

$test_type = $_POST['test_type'];
?>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="100%">
	
  <tr bgcolor="#333333"> 
    <td height="41" colspan="3" bgcolor="#000066"> <div align="center" class="style2"><font face="Bodoni MT Black">ERROR</font></div></td>
  </tr>
	<tr>
		<td height="27" colspan="3" bgcolor="#808080">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="20%" bgcolor="#000066">&nbsp;</td>
		<td width="62%" bgcolor="#00FFFF" valign="top">
		&nbsp;
		<p align="center"><font face="Arial Black" size="7">&nbsp;&nbsp;&nbsp;</font><span class="style3">The candidates New Score cannot be below zero.  </span></p>
		<p align="center" class="style1">DATA NOT PROCESSED </p>
		<p align="center"><font face="Arial Black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#FF0000"> </font>
	  <a href="javascript:history.back()">[ RETRY ]</a></font></td>
		
    <td width="18%" bgcolor="#000066">&nbsp;</td>
	</tr>
	<tr>
		<td height="26" width="100%" bgcolor="#808080" colspan="3">&nbsp;</td>
	</tr>
	
  <tr bgcolor="#333333"> 
    <td width="100%" height="26" colspan="3" bgcolor="#003300"><div align="center"></div></td>
  </tr>
</table>

</body>

</html>
