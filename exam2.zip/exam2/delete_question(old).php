
<?php
//session_destroy();
  $Id =$_GET['Id'];
 $table=$_GET['table'];
 $type=$_GET['coursetype'];
 include ('dbconnect.php');
 
 if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


 $courses=$_GET['course'];
$delete = "DELETE FROM $table WHERE id = ' $Id'";
$result = mysql_query($delete);
//echo <a href='sh_all_stage1_questions_only.php?&coursename=$courses'></a>;
header("Location: sh_all_stage1_questions_only.php?&coursename=$courses&etype=$type");
mysql_close($link);
}

  ?>

