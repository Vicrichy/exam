<?php
include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


session_start();


/// RETRIEVE THE NUMBER OF ANSWERED QUESTIONS

$querya = "select count(question) from answered_questions where reg_no = '$_SESSION[reg_no]' and course = '$_SESSION[course]'";
$resulta = mysql_query($querya);


$question_count = 0;

$query =mysql_query("select count(question) from answered_questions where reg_no = 

'$_SESSION[reg_no]' and course = '$_SESSION[course]'");
$question_query =mysql_result($query, 0, "count(question)");
$question_count = $question_query ;

$display_no = $question_query + 1 ;
}


if (($_SESSION['test_type']) == 'Quiz')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}






if (($_SESSION['test_type']) == 'Exam')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'exam'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'exam'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}





if (($_SESSION['test_type']) == 'Exam Re-sit')

{
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query2 =mysql_query("select max_questions from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_questions =mysql_result($query2, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = 

'$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam re-sit'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}




// DETERMINE THE AMOUNT OF TIME (IN MINUTES) SPENT BY THE CANDIDATE IN THIS SESSION

  $spent_time = round((time() - $_SESSION['start']) / 60) ; 
   echo "$spent_time";   
   
// CALCULATE REMAINING TIME
$remaining_time = $query_max_time - $spent_time ; 


?>
<font color = "red">
<?php
if (($spent_time) >= $query_max_time ) { 
echo "YOUR TIME IS UP!!";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="refresh" content="2;url=indicator.php">

</head>

<body bgcolor="#000000">
<p>
</font>
<font color = "Yellow" size="3">REMAINING TIME =</font> <font color = "red" size="3"><?php echo "$remaining_time"; ?>minutes</font><font size="3"><br>
<font color = "Yellow"> QUESTIONS NUMBER=</font></font><font color = "red" size="3"> <?php echo "$display_no" ?> </font><font size="3">&nbsp;<font color = "Yellow"> of</font>&nbsp;&nbsp;<font color = "red"><?php echo "$query_max_questions"; ?></font></font></p>
</body>
</html>
