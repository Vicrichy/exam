<?php

$surnamex =trim ($_POST['surname']);
$first_namex =$_POST['firstname'];
$othernamesx =$_POST['othernames'];
//$departmentx =$_POST['department'];
$reg_nox = trim ($_POST['reg_no']);
//$batch_nox =$_POST['batch_no'];
//$classroomx =$_POST['classroom'];
//$trainerx =$_POST['trainer'];
//$testmode =$_POST['testmode'];
$genderx =$_POST['gender'];
$coursex =$_POST['course'];
$pix=$_POST['pix'];
 $address=$_POST['address'];
 $phone=$_POST['phone'];
// $emailx=$_POST['email'];
$amountx=$_POST['amount'];
$semesterx=$_POST['semester'];



// Filtered variables (To prevent SQL Injection, Command Injection and XSS attacks from hackers and malicious users)

$surname = escapeshellcmd(strip_tags($surnamex)) ;
$first_name =escapeshellcmd(strip_tags($first_namex)) ;
$othernames =escapeshellcmd(strip_tags($othernamesx));
//$department =escapeshellcmd(strip_tags($departmentx));
$reg_no = escapeshellcmd(strip_tags($reg_nox));
//$batch_no =escapeshellcmd(strip_tags($batch_nox));
//$classroom =escapeshellcmd(strip_tags($classroomx));
//$trainer =escapeshellcmd(strip_tags($trainerx));
//$testmode =$_POST['testmode'];
$gender =escapeshellcmd(strip_tags($genderx));
$course =escapeshellcmd(strip_tags($coursex));
//$email =escapeshellcmd(strip_tags($emailx));
$amount =escapeshellcmd(strip_tags($amountx));
$semester =escapeshellcmd(strip_tags($semesterx));
$amount = "$amount Naira Only";
$full_name = $surname.', '.$first_name.' '.$othernames ;

//SESSION SELECTION
include ('dbconnect.php');
$query6 =mysql_query("select Description from session ");
$Description =mysql_result($query6, 0, "Description");
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;





include ('dbconnect.php');




// CHECK IF THE COURSE EXISTS

$query2="Select course from course_list where course = '$course'";
$result2=mysql_query($query2);

if (mysql_num_rows($result2) == 0) {
header('Location: course_does_not_exist.php');
mysql_close($link);
} 
else 
{


// GENERATE AUTO PASSWORD (WE HAVE TO LOOP IT: IF THE GENERATED PASSWORD WAS FOUND TO MATCH ANY PREVIOUS ONE IN THE TABLE, THE RANDOM ENGINE SHOULD BE FIRED AGAIN).

do
{
mt_srand((double)microtime() * 1000000);
$number1 = mt_rand();

mt_srand((double)microtime() * 1000000);
$number2 = mt_rand(50,90);

$passwd = $surname.$number1.$number2 ;

$passwd=$number1 ;
//DETERMINE IF THE PASSWORD ALREADY EXISTS

$query_checkp = ("SELECT password FROM registration_table WHERE password = '$passwd'");
$checkp = mysql_query($query_checkp);

$no_of_rows = mysql_num_rows($checkp) ;			 
}while($no_of_rows > 0);
	 


// CHECK REG.NUMBER TO KNOW IF IT PREVIOUSLY EXISTS IN THE TABLE

include ('dbconnect.php');
$query1="Select reg_no from registration_table where reg_no = '$reg_no'";
$result1=mysql_query($query1);

if (mysql_num_rows($result1) > 0) {
header('Location: reg_no_already_exists.php');
mysql_close($link);
} 
else 
{

//PICTURE UPLOADING
$file_name = $_FILES['userfile']['name'];
$file_ext = strtolower(substr($file_name,strrpos($file_name,".")));

if ((($_FILES["userfile"]["type"] == "image/gif")
|| ($_FILES["userfile"]["type"] == "image/jpeg")
|| ($_FILES["userfile"]["type"] == "image/pjpeg"))
&& ($_FILES["userfile"]["size"] < 40000))
  {
  if ($_FILES["userfile"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["userfile"]["error"] ."<br />";
    }
		if (file_exists("pix/" .$passwd.$file_ext))
      {
      echo $_FILES["userfile"]["name"] . " already exists.   <a href=javascript:history.back()> << Return </a>";
      }
    else
      {
       move_uploaded_file($_FILES["userfile"]["tmp_name"],
      "pix/" .$passwd.$file_ext);
      //echo "Stored in: " . "pix/" . $_FILES["userfile"]["name"];
      }
    }
else
  {
  echo "Invalid file";
  }




// INSERT TO DATABASE
include ('dbconnect.php');

 $query  = "INSERT INTO registration_table
              ( reg_date, reg_no, surname, first_name, othernames, gender, course, pic,Session,Address,phone,semester)";
			
   $query .= " VALUES
             ( '$system_date', '$reg_no', '$surname', '$first_name', '$othernames', '$gender', '$course', '$passwd$file_ext','$Description','$address','$phone','$semester')";
			 
			 $result = mysql_query($query);
			 







// REGISTER PASSWORD SESSION VARIABLE
 $pics= $passwd.$file_ext;
session_start();
session_register('$passwd');
session_register('$full_name');
session_register('$pics');
session_register('$amount');
session_register('$course');

$_SESSION['amount'] = $amount;
$_SESSION['password'] = $passwd;
$_SESSION['full_name'] = $full_name;
$_SESSION['pix'] = $pics;
$_SESSION['course'] = $course;
$_SESSION['date'] = $system_date;
$_SESSION['reg_no'] = $reg_no;
$_SESSION['code'] = rand();


// UPDATE THE TABLE TO FEED IN THE STUDENTS PASSWORD

$query_update1 = ("UPDATE registration_table SET password = '$passwd' WHERE reg_no = '$reg_no'");
$result3 = mysql_query($query_update1);

$full_name = "$surname, $first_name $othernames" ;

 mysql_query("INSERT INTO receipt(name,reg_no,amount,code,course)VALUES
('$_SESSION[full_name]','$_SESSION[reg_no]','$_SESSION[amount]','$_SESSION[code]','$_SESSION[course]')");
mysql_close($link);

//echo "$payment_date";
header('Location: registration_complete.php');
}
}

		 
?> 