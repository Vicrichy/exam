<?php
//print_r($_POST);



if($_POST["action"] == "Upload Image")
{
unset($imagename);

if(!isset($_FILES) && isset($HTTP_POST_FILES))
$_FILES = $HTTP_POST_FILES;

if(!isset($_FILES['image_file']))
$error["image_file"] = "An image was not found.";


$imagename = basename($_FILES['image_file']['name']);
//echo $imagename;

if(empty($imagename))
$error["imagename"] = "The name of the image was not found.";

if(empty($error))
{
$newimage = "pix/" . $imagename;
//echo $newimage;
$result = @move_uploaded_file($_FILES['image_file']['tmp_name'], $newimage);
if(empty($result))
$error["result"] = "There was an error moving the uploaded file.";
}

}

?>
<title>DATAMIX TEST ENGINE</title><body bgcolor="#006600">
<form method="POST" enctype="multipart/form-data" name="image_upload_form" action="<?php$_SERVER["PHP_SELF"];?>">
  <p align="center"><strong><font color="#00FF00" size="6">RECORD SAVED</font></strong></p>
  <p align="center"><strong><font color="#00FF00" size="6"><em>Please Upload Picture.</em></font></strong></p>
  <p>&nbsp; </p>
  <p>&nbsp;</p>
  <p> 
    <input type="file" name="image_file" size="20">
  </p>
<p><input type="submit" value="Upload Image" name="action"></p>
</form>

<p><font color="#CCCCCC">Before you upload, PLEASE NOTE THE FOLLOWING:</font></p>
<p><font color="#CCCCCC">1) The picture MUST be named after the student's registration 
  number. </font></p>
<p><font color="#CCCCCC">2) The students registration number MUST be in this format: 
  LGN-ENO1-EC01 (there should be no back or frontslashes &quot;/&quot;)</font></p>
<p><font color="#CCCCCC">3) The image format MUST be jpeg or jpg.</font></p>
<p><strong></strong></p>
<p><strong><a href="registration_page.php"><font color="#FFFF00">&lt;&lt; Return</font></a></strong></p>


<?php
if(is_array($error))
{
while(list($key, $val) = each($error))
{
echo $val;
echo "<br>\n";
}
}
?>
