<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E-TEST :: Error</title>
<meta http-equiv="Page-Enter" content="revealTrans(Duration=4.0,Transition=3)">
<style>
.jc{
position:relative;
}
.style2 {position: relative; font-size: 36px; }
.style4 {font-size: 16pt}
</style>

<script language="JavaScript1.2">

var ns6=document.getElementById&&!document.all
var ie=document.all

var customcollect=new Array()
var i=0

function jiggleit(num){
if ((!document.all&&!document.getElementById)) return;
customcollect[num].style.left=(parseInt(customcollect[num].style.left)==-1)? customcollect[num].style.left=1 : customcollect[num].style.left=-1
}

function init(){
if (ie){
while (eval("document.all.jiggle"+i)!=null){
customcollect[i]= eval("document.all.jiggle"+i)
i++
} 
}
else if (ns6){
while (document.getElementById("jiggle"+i)!=null){
customcollect[i]= document.getElementById("jiggle"+i)
i++
}
}

if (customcollect.length==1)
setInterval("jiggleit(0)",80)
else if (customcollect.length>1)
for (y=0;y<customcollect.length;y++){
var tempvariable='setInterval("jiggleit('+y+')",'+'100)'
eval(tempvariable)
}
}

window.onload=init

</script>

</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="100%">
	<tr>
		<td height="41" colspan="9" bgcolor="#000000"><div align="center"><font face="Arial Black" color="#00FF00"><span class="style2">Access Denied!</span></font></div></td>
	</tr>
	<tr>
		<td height="27" colspan="9" bgcolor="#808080">&nbsp;</td>
	</tr>
	<tr>
		<td width="20%" bgcolor="#000000" rowspan="7">&nbsp;</td>
		<td width="1%" bgcolor="#C0C0C0" valign="top" rowspan="7">&nbsp;
		</td>
		<td width="1%" bgcolor="#000000" valign="top" rowspan="7">&nbsp;
		</td>
		<td width="1%" bgcolor="#C0C0C0" valign="top" rowspan="7">&nbsp;
		</td>
		<td width="56%" bgcolor="#000000" valign="top" height="23">&nbsp;
		</td>
		<td width="1%" bgcolor="#C0C0C0" valign="top" rowspan="7">&nbsp;
		</td>
		<td width="1%" bgcolor="#000000" valign="top" rowspan="7">&nbsp;
		</td>
		<td width="1%" bgcolor="#C0C0C0" valign="top" rowspan="7">&nbsp;
		</td>
		<td width="18%" bgcolor="#000000" rowspan="7">&nbsp;</td>
	</tr>
	<tr>
		<td width="56%" bgcolor="#C0C0C0" valign="top" height="19">&nbsp;
		</td>
	</tr>
	<tr>
		<td width="56%" bgcolor="#000000" height="170"><p align="center" class="style4"><font color="#FFFF00" face="System">TEST IN NOT ACTIVATED FOR TODAY. </font></p>	  </td>
	</tr>
	<tr>
		<td width="56%" bgcolor="#C0C0C0" valign="top" height="19">&nbsp;
		</td>
	</tr>
	<tr>
		<td width="56%" bgcolor="#C0C0C0" valign="top" height="23">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <font face="Arial Black">&nbsp;</font></td>
	</tr>
	<tr>
		<td width="56%" bgcolor="#000000" valign="top" height="25">
		<p align="center"><font color="#00FF00" face="Copperplate Gothic Bold">MAKE SURE YOU CHOSE THE RIGHT TEST TYPE. BUT IF YOU DID, THEN THE ADMINISTRATOR DID NOT ACTIVATE THE TEST. </font></td>
	</tr>
	<tr>
		<td width="56%" bgcolor="#C0C0C0" valign="top">
		<p align="center">
		<a href="javascript:history.back()" style="margin-right:5px;">
		<font color="#000000" face="Arial Black">[Retry]</font></a></font></td>
	</tr>
	<tr>
		<td height="26" width="100%" bgcolor="#808080" colspan="9">&nbsp;</td>
	</tr>
	<tr>
		<td height="26" width="20%" bgcolor="#000000">&nbsp;</td>
		<td height="22" width="62%" bgcolor="#000000" colspan="7">&nbsp;</td>
		<td height="26" width="18%" bgcolor="#000000">&nbsp;</td>
	</tr>
</table>

</body>

</html>