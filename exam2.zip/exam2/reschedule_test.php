<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 24px;
}
.style2 {
	color: #00FF00;
	font-weight: bold;
	font-style: italic;
}
.style3 {
	color: #FFFFFF;
	font-weight: bold;
}
.style6 {
	color: #00FF00;
	font-style: italic;
}
-->
</style>



<script language="JavaScript">

function formCheck(formobj){
	// Enter name of mandatory fields
	var fieldRequired = Array("testmode","reg_no","course","day","month","year","start_time","duration","max_questions", "max_score");
	


	// Enter field description to appear in the dialog box
	var fieldDescription = Array("TEST MODE","REG.NUMBER","COURSE","DAY","MONTH","YEAR","TEST START TIME","TEST DURATION","NO.OF QUESTIONS", "MAXIMUM SCORE");
	// dialog message
	var alertMsg = "Please you MUST complete the following fields:\n";
	
	var l_Msg = alertMsg.length;
	
	for (var i = 0; i < fieldRequired.length; i++){
		var obj = formobj.elements[fieldRequired[i]];
		if (obj){
			switch(obj.type){
			case "select-one":
				if (obj.selectedIndex == -1 || obj.options[obj.selectedIndex].text == ""){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "select-multiple":
				if (obj.selectedIndex == -1){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			case "text":
			case "textarea":
				if (obj.value == "" || obj.value == null){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
				break;
			default:
			}
			if (obj.type == undefined){
				var blnchecked = false;
				for (var j = 0; j < obj.length; j++){
					if (obj[j].checked){
						blnchecked = true;
					}
				}
				if (!blnchecked){
					alertMsg += " - " + fieldDescription[i] + "\n";
				}
			}
		}
	}

	if (alertMsg.length == l_Msg){
		return true;
	}else{
		alert(alertMsg);
		return false;
	}
}
// -->
</script>





</head>

<body bgcolor="#CC99FF">
<table width="100%" height="311" border="0">
  <tr>
    <td width="2%" height="25" bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000"><div align="center"><span class="style1">RE-SCHEDULE A PREVIOUSLY TAKEN TEST </span></div></td>
    <td width="2%" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td rowspan="6" bgcolor="#000000">&nbsp;</td>
    <td width="43%" rowspan="6"><p>To reschedule a previously taken test for a student, please enter the details below.</p>
      <p>Please NOTE that when you reschedule a test, the operation and date of executing this operation is permanently recorded for monitoring purposes. </p>
      <p>Also NOTE that the students previous scores would be ovewritten by the new one. <br />
        <br />
      <em><strong>IMPORTANT: </strong>Please note that once a student has taken his/her Exam, DO NOT re-schedule his/her Quiz. It would affect the computation. UNLESS you  re-schedule BOTH the Quiz and the Exam. </em></p>
      <form id="form1" name="form1" method="post" action="insert_test_reschedule.php" onSubmit="return formCheck(this);">
        <table width="100%" border="0">
          <tr>
            <td bgcolor="#000000"><span class="style2">TEST MODE </span></td>
          </tr>
          <tr>
            <td><select name="testmode" id="testmode">
              <option selected="selected"></option>
              <option>Quiz</option>
              <option>Exam</option>
              <option>Exam Re-sit</option>
            </select></td>
          </tr>
          <tr>
            <td bgcolor="#000000"><span class="style2">COURSE</span></td>
          </tr>
          <tr>
            <td><input name="course" type="text" id="course" /></td>
          </tr>
          <tr>
            <td bgcolor="#000000"><span class="style2">STUDENT'S REG_NO. </span></td>
          </tr>
          <tr>
            <td><input name="reg_no" type="text" id="reg_no" /></td>
          </tr>
          <tr>
            <td bgcolor="#000000" class="style2">TEST START TIME (12 Hour format)</td>
          </tr>
          <tr>
            <td bgcolor="#CC99FF"><font size="2"><b><font color="#CCCCCC">
              <select name="start_time" id="selectmonth0" style="width:49; height:22">
                <option selected="selected"></option>
                <option value="1">1 am</option>
                <option value="2">2 am</option>
                <option value="3">3 am</option>
                <option value="4">4 am</option>
                <option value="5">5 am</option>
                <option value="6">6 am</option>
                <option value="7">7 am</option>
                <option value="8">8 am</option>
                <option value="9">9 am</option>
                <option value="10">10 am</option>
                <option value="11">11 am</option>
                <option value="12">12 noon</option>
                <option value="13">1 pm</option>
                <option value="14">2 pm</option>
                <option value="15">3 pm</option>
                <option value="16">4 pm</option>
                <option value="17">5 pm</option>
                <option value="18">6 pm</option>
                <option value="19">7 pm</option>
                <option value="20">8 pm</option>
                <option value="21">9 pm</option>
                <option value="22">10 pm</option>
                <option value="23">11 pm</option>
                <option value="24">12 am</option>
              </select>
            </font></b></font></td>
          </tr>
          <tr>
            <td bgcolor="#000000"><span class="style2"><span style="background-color: #000000">TEST DURATION&nbsp;&nbsp;(Minutes)</span></span></td>
          </tr>
          <tr>
            <td bgcolor="#CC99FF"><input name="duration" type="text" id="duration" size="3" /> 
              minutes </td>
          </tr>
          <tr>
            <td bgcolor="#000000"><span class="style6"><span style="font-weight: 700; background-color: #000000">NUMBER OF QUESTIONS&nbsp;&nbsp;</span></span></td>
          </tr>
          <tr>
            <td bgcolor="#CC99FF"><input name="max_questions" type="text" id="max_questions" size="6" /></td>
          </tr>
          <tr>
            <td bgcolor="#000000"><span class="style6"><span style="font-weight: 700; background-color: #000000">MAXIMUM SCORE</span></span></td>
          </tr>
          <tr>
            <td bgcolor="#CC99FF"><input name="max_score" type="text" id="max_score" size="6" /> 
              marks  </td>
          </tr>
          <tr>
            <td bgcolor="#000000">&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#000000"><input type="submit" name="Submit" value="SCHEDULE/ACTIVATE" /> <input type="reset" name="Submit2" value="Reset" /></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form>
      <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>
    <td width="1%" rowspan="6" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="0%" rowspan="6" bgcolor="#000000">&nbsp;</td>
    <td width="1%" rowspan="6" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="51%" valign="top" bgcolor="#000000"><span class="style3">VIEW SCHEDULED TESTS </span></td>
    <td rowspan="6" bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top"><form action="show_scheduled_tests.php" method="post" name="form1" id="form1">
      <br />
      <input type="submit" name="Submit3" value="VIEW SCHEDULED TESTS" />
    </form></td>
  </tr>
  <tr>
    <td valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#000000"><span class="style3">VIEW MONITORING INFO </span></td>
  </tr>
  <tr>
    <td valign="top"><form action="show_reschedule_info.php" method="post" name="form1" id="form1">
      <br />
      <input type="submit" name="Submit3" value="VIEW INFO" />
    </form>�</td>
  </tr>
  <tr>
    <td valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#000000">&nbsp;</td>
    <td colspan="5" bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
  </tr>
</table>
</body>
</html>
