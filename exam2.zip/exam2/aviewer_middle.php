<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 9) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 

<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>E:TEST :: Test Manager Panel</title>
</head>

<body bgcolor="#CCCCCC">
<form name="form2" method="post" action="student_file.php">
  <div align="right"> Specify reg.no 
    <input name="reg_no" type="text" id="reg_no">
    <input type="submit" name="Submit2" value="OPEN STUDENT'S FILE">
  </div>
</form></p>
<p><font size="4">Welcome to the Authorized Viewer account of <strong>E-TEST Testing 
  Engine. </strong></font></p>
<p><font size="4">This account enables the user to view and retrieve database data sets and information, <br>
but cannot modify any data or perform any configuration operations.</font></p>
<p><font size="4">This is a read-only account. </font></p>
<p><font size="4">To perform any of these functions, click its respective button</font></p>
</body>

</html>

<?php
}
?>