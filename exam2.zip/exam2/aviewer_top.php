<?php 

// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p> <i><b>Please login with your password</p></i></b>";
} 

else { 

?> 

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>TEST SCHEDULER CONTROL PANEL</title>
</head>

<body bgcolor="#000000">
<table width="100%" border="0">
  <tr>
    <td colspan="2"><div align="center"><u><b><font color="#CC99FF" face="Copperplate Gothic Bold" size="5">AUTHORIZED VIEWER ACCOUNT </font></b></u></div></td>
  </tr>
  <tr>
    <td width="15%"><a href="user_manual.html" target="_blank"><font color="#00FF33" face="System">User Manual</font></a></td>
    <td width="85%"><form action="logout.php" method="post" name="form1" target="_parent">
      <div align="right"> <u><b><font color="#CC99FF" size="5" face="Copperplate Gothic Bold">
        <input type="submit" name="Submit" value="Logout">
      </font></b></u></div>
    </form></td>
  </tr>
  <tr>
    <td colspan="2"><a href="user_manual.html" target="_blank"></a> </td>
  </tr>
</table>

<u><b> <font color="#CC99FF" face="Copperplate Gothic Bold" size="5"><br>
</font></b></u><font color="#00FF00">
</font>
<div align="right"></div>
      
</body>

</html>

<?php
}
?>