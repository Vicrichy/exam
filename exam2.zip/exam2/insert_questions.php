<?php

session_start();

include('dbconnect.php');

//$course = $_POST['course'];

$pac = mysql_query("SELECT count(id) FROM $_SESSION[course] ORDER BY id");
$id = @mysql_result($pac, 0, "count(id)");
$numbers = range(1,$id);
shuffle($numbers);

$number1 .= $numbers[0];
$number2 .= $numbers[1];
$number3 .= $numbers[2];
$number4 .= $numbers[3];
$number5 .= $numbers[4];
$number6 .= $numbers[5];
$number7 .= $numbers[6];
$number8 .= $numbers[7];
$number9 .= $numbers[8];
$number10 .= $numbers[9];

$course = $_SESSION['course'];
//Insert 1st question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number1'");
$now = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now' AND id= '$number1'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number1','$course','$now','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','1')");
include('dbconnect.php');
mysql_query("INSERT INTO offline(username,course,correct_1)VALUES('$_SESSION[reg_no]','$course','$correct')");
//Insert 2nd question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number2'");
$now2 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now2' AND id= '$number2'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number2','$course','$now2','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','2')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_2` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
//Insert 3rd question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number3'");
$now3 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now3' AND id= '$number3'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number3','$course','$now3','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','3')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_3` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
//Insert 4th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number4'");
$now4 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now4' AND id= '$number4'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number4','$course','$now4','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','4')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_4` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
//Insert 5th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number5'");
$now5 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now5' AND id= '$number5'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number5','$course','$now5','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','5')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_5` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 6th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number6'");
$now6 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now6' AND id= '$number6'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number6','$course','$now6','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','6')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_6` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course`= '$course'");

//Insert 7th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number7'");
$now7 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now7' AND id= '$number7'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number7','$course','$now7','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','7')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_7` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 8th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number8'");
$now8 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now8' AND id= '$number8'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number8','$course','$now8','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','8')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_8` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 9th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number9'");
$now9 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now9' AND id= '$number9'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number9','$course','$now9','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','9')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_9` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

//Insert 10th question
include ('dbconnect.php');
// DETERMINE THE COURSE CODE

// SELECT A QUESTION
$query =mysql_query("select `question` from `$course` where `id` = '$number10'");
$now10 = @mysql_result($query, 0, "question"); 
//echo "$now";
$retrieve =mysql_query("SELECT * FROM $course WHERE question = '$now10' AND id= '$number10'");
while($row = @mysql_fetch_array($retrieve) )
{
 $A = $row['A'];
 $B = $row['B'];
 $C = $row['C'];
 $D = $row['D'];
 $correct = $row['correct'];
}
 
//echo "$number";
include('dbconnect.php');
mysql_query("INSERT INTO user_question(id,course,question,A,B,C,D,correct,username,page_no)VALUES('$number10','$course','$now10','$A','$B','$C','$D','$correct','$_SESSION[reg_no]','10')");
include('dbconnect.php');
mysql_query("UPDATE `offline` SET `correct_10` = '$correct' WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");

include('dbconnect.php');
$query =mysql_query("select count(id) from `user_question` where `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
$question_query = @mysql_result($query, 0, "count(id)");
//echo $question_query;

if($question_query<10)
{
  include('dbconnect.php');
  mysql_query("DELETE FROM `user_question` WHERE `username`='$_SESSION[reg_no]' AND `course` = '$course'");
  mysql_query("DELETE FROM `offline` WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$course'");
  header("location:insert_questions.php");
  exit();
}
else
{
  header("location:off.php");
} 
?>