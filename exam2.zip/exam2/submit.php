<?php
session_start(); 
if ($_SESSION['auth'] == 100 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
?>
<html>
<head>
<script type="text/javascript">
function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=1,statusbar=1,menubar=0,resizable=0,width=300,height=200,left = 412,top = 284');");
}
</script>
<?php	  
//Get form values  
//$username = $_POST['username'];

include('dbconnect.php');
$lilian = mysql_query("SELECT `reg_no` FROM `compute_results` WHERE `reg_no` = '$_SESSION[reg_no]' AND `course`='$_SESSION[course]'");

$num_rows = @mysql_num_rows($lilian);
	  
if($num_rows>=1)
{
?>
<html>
<script type="text/javascript">
alert("SORRY YOU CAN'T SUBMIT YOUR ANSWERS AGAIN!");
window.location = "index.php";
</script>
</html>
<?php
}
else
{ 	  
$A1 = $_POST['A1'];
$B1 = $_POST['B1'];
$C1 = $_POST['C1'];
$D1 = $_POST['D1'];

$no1 = trim($A1.''.$B1.''.$C1.''.$D1);

$A2 = $_POST['A2'];
$B2 = $_POST['B2'];
$C2 = $_POST['C2'];
$D2 = $_POST['D2'];

$no2 = trim($A2.''.$B2.''.$C2.''.$D2);

$A3 = $_POST['A3'];
$B3 = $_POST['B3'];
$C3 = $_POST['C3'];
$D3 = $_POST['D3'];

$no3 = trim($A3.''.$B3.''.$C3.''.$D3);

$A4 = $_POST['A4'];
$B4 = $_POST['B4'];
$C4 = $_POST['C4'];
$D4 = $_POST['D4'];

$no4 = trim($A4.''.$B4.''.$C4.''.$D4);

$A5 = $_POST['A5'];
$B5 = $_POST['B5'];
$C5 = $_POST['C5'];
$D5 = $_POST['D5'];

$no5 = trim($A5.''.$B5.''.$C5.''.$D5);

$A6 = $_POST['A6'];
$B6 = $_POST['B6'];
$C6 = $_POST['C6'];
$D6 = $_POST['D6'];

$no6 = trim($A6.''.$B6.''.$C6.''.$D6);

$A7 = $_POST['A7'];
$B7 = $_POST['B7'];
$C7 = $_POST['C7'];
$D7 = $_POST['D7'];

$no7 = trim($A7.''.$B7.''.$C7.''.$D7);

$A8 = $_POST['A8'];
$B8 = $_POST['B8'];
$C8 = $_POST['C8'];
$D8 = $_POST['D8'];

$no8 = trim($A8.''.$B8.''.$C8.''.$D8);

$A9 = $_POST['A9'];
$B9 = $_POST['B9'];
$C9 = $_POST['C9'];
$D9 = $_POST['D9'];

$no9 = trim($A9.''.$B9.''.$C9.''.$D9);

$A10 = $_POST['A10'];
$B10 = $_POST['B10'];
$C10 = $_POST['C10'];
$D10 = $_POST['D10'];

$no10 = trim($A10.''.$B10.''.$C10.''.$D10);

$A11 = $_POST['A11'];
$B11 = $_POST['B11'];
$C11 = $_POST['C11'];
$D11 = $_POST['D11'];

$no11 = trim($A11.''.$B11.''.$C11.''.$D11);

$A12 = $_POST['A12'];
$B12 = $_POST['B12'];
$C12 = $_POST['C12'];
$D12 = $_POST['D12'];

$no12 = trim($A12.''.$B12.''.$C12.''.$D12);

$A13 = $_POST['A13'];
$B13 = $_POST['B13'];
$C13 = $_POST['C13'];
$D13 = $_POST['D13'];

$no13 = trim($A13.''.$B13.''.$C13.''.$D13);

$A14 = $_POST['A14'];
$B14 = $_POST['B14'];
$C14 = $_POST['C14'];
$D14 = $_POST['D14'];

$no14 = trim($A14.''.$B14.''.$C14.''.$D14);

$A15 = $_POST['A15'];
$B15 = $_POST['B15'];
$C15 = $_POST['C15'];
$D15 = $_POST['D15'];

$no15 = trim($A15.''.$B15.''.$C15.''.$D15);

$A16 = $_POST['A16'];
$B16 = $_POST['B16'];
$C16 = $_POST['C16'];
$D16 = $_POST['D16'];

$no16 = trim($A16.''.$B16.''.$C16.''.$D16);

$A17 = $_POST['A17'];
$B17 = $_POST['B17'];
$C17 = $_POST['C17'];
$D17 = $_POST['D17'];

$no17 = trim($A17.''.$B17.''.$C17.''.$D17);

$A18 = $_POST['A18'];
$B18 = $_POST['B18'];
$C18 = $_POST['C18'];
$D18 = $_POST['D18'];

$no18 = trim($A18.''.$B18.''.$C18.''.$D18);

$A19 = $_POST['A19'];
$B19 = $_POST['B19'];
$C19 = $_POST['C19'];
$D19 = $_POST['D19'];

$no19 = trim($A19.''.$B19.''.$C19.''.$D19);

$A20 = $_POST['A20'];
$B20 = $_POST['B20'];
$C20 = $_POST['C20'];
$D20 = $_POST['D20'];

$no20 = trim($A20.''.$B20.''.$C20.''.$D20);

include('dbconnect.php');
//Get Database Values
$query = mysql_query("SELECT * FROM `offline` WHERE `username` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");

while($row = mysql_fetch_array($query) )
{
 $username = $row['username'];
 $correct_1 = $row['correct_1'];
 $correct_2 = $row['correct_2'];
 $correct_3 = $row['correct_3'];
 $correct_4 = $row['correct_4'];
 $correct_5 = $row['correct_5'];
 $correct_6 = $row['correct_6'];
 $correct_7 = $row['correct_7'];
 $correct_8 = $row['correct_8'];
 $correct_9 = $row['correct_9'];
 $correct_10 = $row['correct_10'];
 $correct_11 = $row['correct_11'];
 $correct_12 = $row['correct_12'];
 $correct_13 = $row['correct_13'];
 $correct_14 = $row['correct_14'];
 $correct_15 = $row['correct_15'];
 $correct_16 = $row['correct_16'];
 $correct_17 = $row['correct_17'];
 $correct_18 = $row['correct_18'];
 $correct_19 = $row['correct_19'];
 $correct_20 = $row['correct_20'];
 
} 

if($no1==$correct_1)
{
 $correct1 = 1;
}
else
{
 $wrong1 =1;
}

if($no2==$correct_2)
{
 $correct2 =1;
}
else
{
 $wrong2 =1;
}

if($no3==$correct_3)
{
 $correct3 =1;
}
else
{
 $wrong3 =1;
 
}

if($no4==$correct_4)
{
 $correct4 =1;
}
else
{
 $wrong4 =1;
 
}

if($no5==$correct_5)
{
 $correct5 =1;
}
else
{
 $wrong5 =1;
 
}

if($no6==$correct_6)
{
 $correct6 =1;
}
else
{
 $wrong6 =1;
 
}

if($no7==$correct_7)
{
 $correct7 =1;
}
else
{
 $wrong7 =1;
 
}

if($no8==$correct_8)
{
 $correct8 =1;
}
else
{
 $wrong8 =1;
 
}

if($no9==$correct_9)
{
 $correct9 =1;
}
else
{
 $wrong9 =1;
 
}

if($no10==$correct_10)
{
 $correct10 =1;
}
else
{
 $wrong10 =1;
 
}

if($no11==$correct_11)
{
 $correct11 = 1;
}
else
{
 $wrong11 =1;
}

if($no12==$correct_12)
{
 $correct12 =1;
}
else
{
 $wrong12 =1;
}

if($no13==$correct_13)
{
 $correct13 =1;
}
else
{
 $wrong13 =1;
 
}

if($no14==$correct_14)
{
 $correct14 =1;
}
else
{
 $wrong14 =1;
 
}

if($no15==$correct_15)
{
 $correct15 =1;
}
else
{
 $wrong15 =1;
 
}

if($no16==$correct_16)
{
 $correct16 =1;
}
else
{
 $wrong16 =1;
 
}

if($no17==$correct_17)
{
 $correct17 =1;
}
else
{
 $wrong17 =1;
 
}

if($no18==$correct_18)
{
 $correct18 =1;
}
else
{
 $wrong18 =1;
 
}

if($no19==$correct_19)
{
 $correct19 =1;
}
else
{
 $wrong19 =1;
 
}

if($no20==$correct_20)
{
 $correct20 =1;
}
else
{
 $wrong20 =1;
 
}


$correct = $correct1+$correct2+$correct3+$correct4+$correct5+$correct6+$correct7+$correct8+$correct9+$correct10+$correct11+$correct12+$correct13+$correct14+$correct15+$correct16+$correct17+$correct18+$correct19+$correct20;

$wrong = $wrong1+$wrong2+$wrong3+$wrong4+$wrong5+$wrong6+$wrong7+$wrong8+$wrong9+$wrong10+$wrong11+$wrong12+$wrong13+$wrong14+$wrong15+$wrong16+$wrong17+$wrong18+$wrong19+$wrong20;

$total = $correct * 5;

include('dbconnect.php');
$myname = mysql_query("SELECT `name` FROM `registration_table` WHERE `reg_no` = '$_SESSION[reg_no]'");
$_SESSION['name'] = @mysql_result($myname,0,"name");
mysql_query("INSERT INTO `compute_results` SET `no_passed`='$correct',`no_failed`='$wrong',`score`='$correct',`submitted`= 'YES',`total` = '$total', `course`='$_SESSION[course]',`name`='$_SESSION[name]',`reg_no`= '$_SESSION[reg_no]'");

include('dbconnect.php');
mysql_query("UPDATE `mycourses` SET `status` = 'WRITTEN' WHERE `reg_no` = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
$ud = mysql_query("SELECT `dept` FROM `registration_table` WHERE `reg_no` = '$_SESSION[reg_no]'");
$dept = @mysql_result($ud,0,"dept");
switch($dept)
{
case($dept == 'Comp. Repairs and Maintenance - 1st Semester'):
$sheet = "broadsheet_repairs";
break;
case($dept == 'Comp. Repairs and Maintenance - 2nd Semester'):
$sheet = "broadsheet_repairs2";
break;
case($dept == 'Sec.Administration - 1st Semester'):
$sheet = "broadsheet_sec";
break;
case($dept == 'Sec.Administration - 2nd Semester'):
$sheet = "secstudies_second";
break;
case($dept == 'Information Technology -1st Semester'):
$sheet = "broadsheet";
break;
case($dept == 'Information Technology -2nd Semester'):
$sheet = "infotech_second";
break;
case($dept == 'GCTP MOCK EXAMS'):
$sheet = "gctp_mock_exams";
break;
}
mysql_query("UPDATE `$sheet` SET `$_SESSION[course]` = '$total' WHERE `reg_no` = '$_SESSION[reg_no]'");
$query_clean = "DELETE FROM user_question WHERE username = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'";
$result = mysql_query($query_clean);
mysql_query("DELETE FROM offline WHERE username = '$_SESSION[reg_no]' AND `course` = '$_SESSION[course]'");
mysql_query("DELETE FROM mycourses WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]'");
}
if($wrong>0)
{
?>
<html>
<script type="text/javascript">
alert("You got <?php echo $correct;?> RIGHT and <?php echo $wrong;?> WRONG. You score is <?php echo $total;?>/100 ");
window.close();
</script>
</html>
<?php
}
else
{
?>
<html>
<script type="text/javascript">
alert("CONGRATS! You got all questions right");
window.close();
</script>
</html>
<?php
}
}
?>