<?php

$course = $_POST['course'];
$semester = addslashes($_POST['semester']);


if(($semester) =='FIRST')
{
include('dbconnect.php');
mysql_query("UPDATE `registration_table` SET `semester`='SECOND' WHERE `semester`='$semester' AND `course`= '$course'");

echo "SEMESTER UPGRADED TO SECOND";

echo "<a href=javascript:history.back()> << Return </a>";
}
else
{
include('dbconnect.php');
mysql_query("UPDATE `registration_table` SET `semester`='FIRST' WHERE `semester`='$semester' AND `course`= '$course'");

echo "SEMESTER UPGRADED TO FIRST";

echo "<a href=javascript:history.back()> << Return </a>";
}

?>