<?php
// start session 
session_start(); 

$course = addslashes($_POST['course']);
$test_type = "Exam";
$pwd = 1;
$password = 1;
$dept = $_POST['department'];
$code = $_POST['code'];
$name = $_POST['name'];
$year = $_POST['year'];
$month = $_POST['month'];
$reg_no = addslashes($_POST['reg_no']);
$_SESSION['course'] = $course;
$_SESSION['reg_no'] = $reg_no;
$_SESSION['dept'] = $department;
$_SESSION['name'] = $name;

include('dbconnect.php');
mysql_query("DELETE FROM `user_question` WHERE `username` = '$_SESSION[reg_no]'");
mysql_query("DELETE FROM `offline` WHERE `username` = '$_SESSION[reg_no]'");
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");

// EXTRACT SYSTEM TIME ( note that the time is formated in 24hr mode, and with a decimal point
// for example 4:35pm is 16.35

$computer_time = date("G");


// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;



// CHECK IF BOTH FIELDS CONTAIN VALUES

//if (isset($_POST['login'])) {
    // form submitted 
    // check for required values 
      
         
    // open connection 
include ('dbconnect.php');
 

$course = $_POST['course'];
$no = $_POST['no'];
$test_type = "Exam";
$pwd = 1;
$password = 1;
$reg_no = addslashes($_POST['reg_no']);


include('dbconnect.php');

// CHECK IF ACCESS CODE IS INCORRECT
$queryxx="SELECT password FROM quiz_password WHERE password = '$password'";
$resultxx=mysql_query($queryxx);


if (mysql_num_rows($resultxx) == 0) {
header('Location: password_incorrect.php');
}
else
{

// THIS CODE CHECKS IF THE CANDIDATE HAS PREVIOUSLY TAKEN THIS TEST
include('dbconnect.php');
$check_can = mysql_query("SELECT `reg_no` FROM compute_results WHERE `reg_no` = '$reg_no' AND `course` = '$course'");

$vik = mysql_num_rows($check_can);

if($vik ==1){
header("location:test_previously_taken_error.php");
exit();
}
else
{

// THIS CODE CHECKS IF THE SPECIFIED COURSE DOES NOT EXIST

include('dbconnect.php');

$queryx="SELECT course FROM course_list WHERE course = '$course'";
$resultx=mysql_query($queryx);

if (mysql_num_rows($resultx) ==100 ) {
header('Location: course_does_not_exist.htm');
mysql_close($link);
} 
else 
{

// THIS CODE CHECKS IF THE SPECIFIED PASSWORD MATCHES WITH THE REG.NUMBER

 include('dbconnect.php');

$queryx="SELECT * FROM registration_table WHERE password = '$pwd' AND reg_no = '$reg_no'";
$resultx=mysql_query($queryx);

if (@mysql_num_rows($resultx) ==1 ) {
header('Location: wrong_user_exam_password.php');
mysql_close($link);
} 
else 
{
  
// THIS CODE CHECKS IF THE SPECIFIED REG.NO DOES NOT EXIST
  
if (isset($reg_no)) {
 include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{
$queryx1="SELECT reg_no FROM registration_table WHERE reg_no = '$reg_no'";
$resultx1=mysql_query($queryx1);

if (mysql_num_rows($resultx1) == 100) {
header('Location: regno_does_not_exist.htm');
mysql_close($link);
} 
else 
{
 // THIS CODE CHECKS IF THE SPECIFIED COURSE DOES NOT EXISTS IN THE LOGIN TABLE. IT ALSO CHECKS IF THE SPECIFIED COURSE AND TEST TYPE WAS ACTIVATED.

if (isset($_POST['course'])) {

// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;



 include('dbconnect.php');
 
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


$queryxx="SELECT course FROM candidate_login_table WHERE course = '$course' AND test_date = '$system_date'";
$resultxx=mysql_query($queryxx);

if (mysql_num_rows($resultxx) == 0) {
header('Location: course_not_authorised.htm');
mysql_close($link);
} 
else 
{
// THIS CODE CHECKS IF THE SYSTEM TIME IS LESS THAN THE CONFIGURED TEST TIME
include('dbconnect.php');
$query_datex = mysql_query("SELECT test_set_time FROM candidate_login_table WHERE course = '$course' AND test_date = '$system_date'");
$query_datex1 =@mysql_result($query_datex, 0, "test_set_time"); 
 
    if (($computer_time) < $query_datex1) {
   header('Location: invalid_time.htm');
   mysql_close($link);
} 
else 
{

// THIS CODE CHECKS IF THE SYSTEM DATE
// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("m");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

include('dbconnect.php');


$query_datex = mysql_query("SELECT test_date FROM candidate_login_table WHERE course = '$course' AND test_type = '$test_type'");
$query_datex1 =@mysql_result($query_datex, 0, "test_date"); 
 
    if (($system_date) != $query_datex1) {
   header('Location: invalid_date.htm');
   mysql_close($link);
} 
else 
{
 // THIS CODE CHECKS IF THE SPECIFIED PASSWORD IS INCORRECT FOR EACH TEST TYPE

include('dbconnect.php');

/*
// THIS CODE CHECKS IF HE HAS WRITTEN EXAM, IF SO, THEN HE CANNOT TRY TO TAKE QUIZ
if(($test_type) == "Quiz")
{
$query_cr = "SELECT * FROM compute_results WHERE test_type = 'Exam' AND reg_no = '$reg_no' AND course = '$course'";

$result_cr = mysql_query($query_cr);

if (mysql_num_rows($result_cr) > 0)
{
header('Location: cant_take_quiz_after_exam.php');
//mysql_close($link);
}
}
else
{
*/

session_start();
$_SESSION['auth'] = 3;
$_SESSION['course'] = $course; 
$_SESSION['reg_no'] = $reg_no;
$_SESSION['test_type'] = $_POST['test_type']; 
$_SESSION['start'] = time();
$_SESSION['name'] = $_POST['name'];
$_SESSION['dept'] = $_POST['department'];
$_SESSION['sheet'] = $sheet;
session_register('course'); 
session_register('reg_no');
session_register('name'); 
session_register('test_type'); 
session_register('dept');
session_register('sheet');
//header('Location: quiz_frame.php');
	}
}     
}
}
}
}
}
}
}
}
}
}

header("location:insert_questions.php");
  
//}
//}
//}

?>