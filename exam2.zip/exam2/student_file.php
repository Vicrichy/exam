<?php
// THIS CODE CHECKS IF THE SPECIFIED REG.NO DOES NOT EXIST
 $reg_no = $_POST['reg_no'];
  
if (isset($_POST['Submit2'])) {
 include('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{


$queryx1="SELECT reg_no FROM registration_table WHERE reg_no = '$reg_no'";
$resultx1=mysql_query($queryx1);

if (mysql_num_rows($resultx1) == 0) {
header('Location: reg_does_not_exist.php');
mysql_close($link);
} 
else 
{

session_start();
$_SESSION['reg_no'] = $_POST['reg_no'];
session_register('reg_no'); 


//******************** EXTRACT THE REQUIRED DATA




// RETRIEVE CANDIDATE'S SURNAME

$query =mysql_query("select surname from registration_table where reg_no = '$reg_no'");
$surname =mysql_result($query, 0, "surname");


// RETRIEVE CANDIDATE'S FIRST NAME

$query2 =mysql_query("select first_name from registration_table where reg_no = '$reg_no'");
$firstname =mysql_result($query2, 0, "first_name");


// RETRIEVE CANDIDATE'S OTHERNAME

$query3 =mysql_query("select othernames from registration_table where reg_no = '$reg_no'");
$othernames =mysql_result($query3, 0, "othernames");


$fullname = $surname."&nbsp;".$othernames."&nbsp;".$firstname;



// RETRIEVE CANDIDATE'S REG NUMBER

$query4 =mysql_query("select reg_no from registration_table where reg_no = '$reg_no'");
$reg_no =mysql_result($query4, 0, "reg_no");



// RETRIEVE CANDIDATE'S BATCH NO

//$query5 =mysql_query("select batch from registration_table where reg_no = '$reg_no'");
//$batch_no =mysql_result($query5, 0, "batch");


// RETRIEVE CANDIDATE'S TRAINER

//$query6 =mysql_query("select trainer from registration_table where reg_no = '$reg_no'");
//$trainer =mysql_result($query6, 0, "trainer");



// RETRIEVE CANDIDATE'S COURSE

$query7 =mysql_query("select course from registration_table where reg_no = '$reg_no'");
$course =mysql_result($query7, 0, "course");


// RETRIEVE CANDIDATE'S GENDER

$query8 =mysql_query("select gender from registration_table where reg_no = '$reg_no'");
$sex =mysql_result($query8, 0, "gender");


// RETRIEVE CANDIDATE'S REG DATE

$query9 =mysql_query("select reg_date from registration_table where reg_no = '$reg_no'");
$reg_date =mysql_result($query9, 0, "reg_date");


// RETRIEVE CANDIDATE'S PASSWORD

$query10 =mysql_query("select password from registration_table where reg_no = '$reg_no'");
$password =mysql_result($query10, 0, "password");








// RETRIEVE CANDIDATE'S DEPARTMENT (Registration)

//$query2a =mysql_query("select department from registration_table where reg_no = '$reg_no'");
//$department =mysql_result($query2a, 0, "department");


// RETRIEVE CANDIDATE'S DEPARTMENT (Test Records)

//@$query3a =mysql_query("select department from test_records where reg_no = '$reg_no'");
//@$department2a =mysql_result($query3a, 0, "department");

// RETRIEVE CANDIDATE'S CLASSROOM

//$query2b =mysql_query("select classroom from registration_table where reg_no = '$reg_no'");
//$classroom =mysql_result($query2b, 0, "classroom");

// RETRIEVE CANDIDATE'S PICTURE
$query3b =mysql_query("select pic from registration_table where reg_no = '$reg_no'");
$pix=mysql_result($query3b, 0, "pic");


// RETRIEVE CANDIDATE'S ADDRESS
$query22 =mysql_query("select Address from registration_table where reg_no = '$reg_no'");
$address=mysql_result($query22, 0, "Address");

// RETRIEVE CANDIDATE'S PHONE
$query23 =mysql_query("select phone from registration_table where reg_no = '$reg_no'");
$phone=mysql_result($query23, 0, "phone");

// RETRIEVE CANDIDATE'S EMAIL
//$query24 =mysql_query("select email from registration_table where reg_no = '$reg_no'");
//$email=mysql_result($query24, 0, "email");



?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>E-TEST ::: Student File</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style1 {	color: #FFFFFF;
	font-weight: bold;
}
.style2 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
}
-->
</style>
<script LANGUAGE="JavaScript">
<!--

// JavaScript centering adapted by telophase: telophase@telophase.net
// from code by Kate Ward: http//www.kateandmouse.com
// Full permission is granted for use.

function popUp(URL,popW,popH) {

var w = 480, h = 340;

if (document.all || document.layers) {
   w = screen.availWidth;
   h = screen.availHeight;
}

var topPos = 0, leftPos = (w-popW)/2;


   window.open(URL,'popup','resizable, toolbar=no, location=no, status=no, scrollbars=yes, horizontal scrollbars=yes, scroll=yes, menubar=no, titlebar=no, width=' + popW + ',height=' + popH + ',left=' + leftPos + ',top=' + topPos + ',screenX=' + leftPos + ',screenY=' + topPos);
}
// -->
</script>
</head>

<body background = "images/reg_stuff.jpg">
<table width="98%" height="836" border="1">
  <tr> 
    <td height="28" colspan="5" bgcolor="#003300"><p align="center"><font color="#FFFFFF" size="5"><strong>Pacific Computers </strong></font></p>
      <p align="right"><b><font face="Arial Black"><a href="javascript:history.back()" style="margin-right:5px;"><font color="#FF0000">&lt;&nbsp;back</font></a></font></b></p></td>
  </tr>
  <tr> 
    <td height="37" colspan="5" bgcolor="#00FF00"><div align="center"><strong><font size="5">STUDENT 
        FILE </font></strong></div></td>
  </tr>
  <tr> 
    <td width="1%" rowspan="4" bgcolor="#003300"> <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    <p>&nbsp;</p></td>
    <td width="15%" height="31" valign="top" bgcolor="#CCCCCC"><strong>PICTURE</strong></td>
    <td colspan="2" bgcolor="#000000"><strong><font color="#FFFFFF">REGISTRATION 
      DATA</font></strong></td>
    <td width="1%" rowspan="4" bgcolor="#003300">&nbsp;</td>
  </tr>
  <tr> 
    <td height="289" valign="top" bgcolor="#00FF00"> 
      <p>&nbsp; </p>
      <p>&nbsp;
	  <?php
	  $reg_no = $_POST['reg_no'];
	  echo "<img src = 'pix/$pix' height = '150' width = '180'>";
	 // echo "No picture available";
	  ?>
	  </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp; </p></td>
    <td colspan="2" rowspan="2" valign="top" bgcolor="#FFFFFF"><h2><?php echo "$fullname"; ?></h2>
      </p>
      <form method="POST" action="modify_students_data_script.php" onSubmit="return formCheck(this);">
        <input type="hidden" name="move_reg" value="$reg_no">
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bordercolorlight="#000099" bordercolordark="#000080">
          <!--DWLayoutTable-->
          <tr>
            <td width="113" bgcolor="#006600"><span class="style1"><font face="Agency FB">First 
              Name</font></span></td>
            <td width="262" bgcolor="#B9BBC5"><input name="firstname" type="text" id="firstname" tabindex="1" value="<?php echo "$firstname"; ?>" size="25"></td>
            <td bgcolor="#006600"><span class="style1">Course</span></td>
            <td width="278" bgcolor="#CCCCCC"><input name="course" type="text" id="course" value="<?php echo "$course"; ?>" size="30" tabindex="8"></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Surname</font></span></td>
            <td bgcolor="#B9BBC5"><input name="surname" type="text" id="surname" tabindex="2" value="<?php echo "$surname"; ?>" size="25"></td>
            <td valign="top" bgcolor="#006600"><span class="style1">Gender</span></td>
            <td bgcolor="#B9BBC5"><input name="gender" type="text" id="gender" value="<?php echo "$sex"; ?>" size="30" tabindex="8"></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Othernames</font></span></td>
            <td bgcolor="#B9BBC5"><input name="othernames" type="text" id="othernames" tabindex="3" value="<?php echo "$othernames"; ?>" size="25"></td>
            <td bgcolor="#006600"><span class="style1">Password</span></td>
            <td bgcolor="#B9BBC5"><input name="password" type="text" id="password" tabindex="3" value="<?php echo "$password"; ?>" size="25"></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Reg. No</font></span></td>
            <td bgcolor="#B9BBC5"><input name="reg_no" type="text" id="reg_no" tabindex="3" value="<?php echo "$reg_no"; ?>" size="25"></td>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Reg Date</font></span></td>
            <td bgcolor="#B9BBC5"><input name="reg_date" type="text" id="reg_date" tabindex="3" value="<?php echo "$reg_date"; ?>" size="25"></td>
          </tr>
          <tr>
            <td height="24" valign="top" bgcolor="#006600"><span class="style1"><font face="Agency FB">Contact Address</font></span></td>
            <td valign="top" bgcolor="#B9BBC5"><input name="address" type="text" id="adsress" tabindex="3" value="<?php echo "$address"; ?>" ></td>
            <td bgcolor="#006600"><span class="style1"><font face="Agency FB">Phone Number</font></span></td>
            <td valign="top" bgcolor="#B9BBC5"><input name="phone" type="text" id="phone" tabindex="3" value="<?php echo "$phone"; ?>" size="25"></td>
          </tr>
          <tr>
            <td bgcolor="#006600"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td bgcolor="#B9BBC5"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td bgcolor="#006600"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td bgcolor="#B9BBC5"><!--DWLayoutEmptyCell-->&nbsp;</td>
          </tr>
          
          <tr>
            <td bgcolor="#006600"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td bgcolor="#B9BBC5"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td bgcolor="#006600"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td bgcolor="#B9BBC5"><!--DWLayoutEmptyCell-->&nbsp;</td>
          </tr>
          <tr>
            <td colspan="4"><!--DWLayoutEmptyCell-->&nbsp;</td>
          </tr>
        </table>
        <p align="left">
          <input type="submit" value="SAVE CHANGE" name="B1" style="font-weight: 700">
          &nbsp;&nbsp;&nbsp;
          <input type="reset" name="Reset" value="Reset">
        </p>
      </form>
      </p>
      <p>&nbsp;</p>
      <table width="100%" border="0">
        <tr>
          <td bgcolor="#000000"><strong><font color="#FFFFFF">TEST RESULTS </font></strong></td>
        </tr>
      </table>
      <p>
	  <?php
	  $queryv = ("SELECT TEST_TYPE, TEST_DATE, COURSE, MAX_QUESTIONS, NO_RIGHT 'NO. PASSED', SCORE 'TEST_SCORE', MAX_SCORE, GRADE FROM test_records WHERE reg_no = '$reg_no'");
	  
	$resultv = mysql_query($queryv)
or die (mysql_error());
$num_fields = mysql_num_fields($resultv);

if(mysql_num_rows($resultv) == 0)
{
echo "No results recorded";
}
else
{
//create table header
echo "<table border = 1>";
echo "<tr>";
for ($i=0; $i<$num_fields; $i++)
{
echo "<th>";
echo mysql_field_name ($resultv, $i);
echo "</th>";
}
echo "</tr>";
//end table header

//create table body

echo "<tr>";
while ($row = mysql_fetch_array($resultv, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";
}
	  
	  
	  
	  ?>
	  
	  </p>
      <p>&nbsp;</p>
      </p>
<p>&nbsp;</p>
      <p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td height="358" valign="top" bgcolor="#00FF00"><p><strong>COURSE(S) REGISTERED</strong></p>
      <p>
        <?php
	  $queryv = ("SELECT COURSE  FROM registration_table WHERE reg_no = '$reg_no' order by COURSE");
	$resultv = mysql_query($queryv)
or die (mysql_error());
$num_fields = mysql_num_fields($resultv);


echo "<table border = 0>";


//create table body

echo "<tr>";
while ($row = mysql_fetch_array($resultv, MYSQL_ASSOC))
{

while( list ($key, $value) = each($row) )
{
echo "<td>" . $value . "</td>";
}
echo "</tr>";
}
echo "</table>";

	  
//session_destroy();	  
	}}}
//session_start();
session_register('$reg_no');
$_SESSION['reg_no'] = $reg_no;	  
	  ?>
    </p>
      <p class="style2"><a href="JavaScript:popUp('reprint_receipt.php',1015,680)">Reprint Receipt&gt;&gt;&gt; </a></p></td>
  </tr>
  <tr> 
    <td height="23" valign="top" bgcolor="#003300">&nbsp;</td>
    <td width="29%" bgcolor="#003300">&nbsp;</td>
    <td width="54%" bgcolor="#003300">&nbsp;</td>
  </tr>
</table>
<p><FORM>
        <p align="center">
          <input name="button" type="button" onClick="window.print()" value="PRINT OUT">
  </p>
      </FORM>&nbsp;</p></body>
</html>
