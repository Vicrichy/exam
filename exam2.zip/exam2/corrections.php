<?php 
// start session 
session_start(); 
if (!@$_SESSION['auth'] == 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 

?> 


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>New Page 1</title>
<style type="text/css">
<!--
body {
	background-image: url(images/bg1.jpg);
}
.style1 {
	color: #00FF00;
	font-weight: bold;
	font-size: 24px;
}
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style7 {color: #FF9966; font-weight: bold; }
.style8 {color: #00FF00}
.style9 {
	color: #FFFFFF;
	font-style: italic;
	font-weight: bold;
}
.style10 {font-weight: bold}
.style11 {font-weight: bold}
.style12 {font-weight: bold}
.style13 {font-weight: bold}
.style14 {font-weight: bold}
.style15 {font-weight: bold}
.style16 {font-weight: bold}
.style17 {font-weight: bold}
-->
</style></head>

<body>

<?php
// RETRIEVE NUMBERS FOR THE QUESTIONS

include ('dbconnect.php');
if (!$link)
{
   echo "Could not connect: " . mysql_error();
}
else
{




$total_questions = "N/A";
$no_attempted = "N/A";
$no_passed = "N/A";
$no_failed = "N/A";
$actual_scorex = "N/A";
$max_scorex = "N/A";
$qgrade = "N/A";




// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");
$dash = "-";

$system_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;

$test_date = $computer_date_year.$dash.$computer_date_month.$dash.$computer_date_day ;


// RETRIEVE COUNT FOR THE RIGHT ANSWERS

$query =mysql_query("select count(question) from answered_questions where reg_no = '$_SESSION[reg_no]' and course = '$_SESSION[course]' and comment = 'RIGHT'");
$score_right =mysql_result($query, 0, "count(question)");






// CALCULATE PERCENTAGE SCORE

//$score_percent = round(($score_right / $query_max_questions) * 100) ;


// RETRIEVE CANDIDATE'S SURNAME

$query =mysql_query("select surname from registration_table where reg_no = '$_SESSION[reg_no]'");
$surname =mysql_result($query, 0, "surname");


// RETRIEVE CANDIDATE'S FIRST NAME

$query2 =mysql_query("select first_name from registration_table where reg_no = '$_SESSION[reg_no]'");
$firstname =mysql_result($query2, 0, "first_name");



// RETRIEVE CANDIDATE'S DEPARTMENT

$query2d =mysql_query("select department from registration_table where reg_no = '$_SESSION[reg_no]'");
$department =mysql_result($query2d, 0, "department");

//SELECT REGISTERED SESSION
$query25=mysql_query("select session from registration_table where reg_no = '$_SESSION[reg_no]'");
$SessionREg =mysql_result($query25, 0, "session");

$query12 =mysql_query("SELECT Batch FROM REGISTRATION_TABLE WHERE Reg_NO= '$_SESSION[reg_no]'");
 $batch=mysql_result($query12, 0, "batch");

// QUIZ
if (($_SESSION['test_type']) == 'Quiz')
{

// RETRIEVE THE MAX_CORE 

$query_date = mysql_query("SELECT max_score FROM candidate_login_table WHERE course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$max_score =mysql_result($query_date, 0, "max_score"); 

$max_score_quiz = $max_score ;


// RETRIEVE THE TIME SET FOR THE TEST

$query_datex = mysql_query("SELECT test_set_time FROM candidate_login_table WHERE course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_datex1 =mysql_result($query_datex, 0, "test_set_time"); 



// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query3 =mysql_query("select max_questions from candidate_login_table where test_date ='$system_date' and test_type = 'Quiz'");
$query_max_questions =mysql_result($query3, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Quiz'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}






//Exam

if (($_SESSION['test_type']) == 'Exam')
{

// RETRIEVE THE MAX_CORE 

$query_date = mysql_query("SELECT max_score FROM candidate_login_table WHERE course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'exam'");
$max_score =mysql_result($query_date, 0, "max_score"); 

$max_score_exam = $max_score ;

// RETRIEVE THE TIME SET FOR THE TEST

$query_datex = mysql_query("SELECT test_set_time FROM candidate_login_table WHERE course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'exam'");
$query_datex1 =mysql_result($query_datex, 0, "test_set_time"); 



// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query3 =mysql_query("select max_questions from candidate_login_table where test_date ='$system_date' and test_type = 'exam'");
$query_max_questions =mysql_result($query3, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'exam'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}



//Exam Re-sit

if (($_SESSION['test_type']) == 'Exam Re-sit')

{

// RETRIEVE THE MAX_CORE 

$query_date = mysql_query("SELECT max_score FROM candidate_login_table WHERE course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam Re-sit'");
$max_score =mysql_result($query_date, 0, "max_score"); 

$max_score_resit = $max_score ;


// RETRIEVE THE TIME SET FOR THE TEST

$query_datex = mysql_query("SELECT test_set_time FROM candidate_login_table WHERE course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam Re-sit'");
$query_datex1 =mysql_result($query_datex, 0, "test_set_time"); 



// SELECT MAX QUESTION SET FOR THE CANDIDATE

$query3 =mysql_query("select max_questions from candidate_login_table where test_date ='$system_date' and test_type = 'Exam Re-sit' and course = '$_SESSION[course]'");
$query_max_questions =mysql_result($query3, 0, "max_questions");


// SELECT MAX TIME SET FOR THE CANDIDATE

$query4 =mysql_query("select test_duration from candidate_login_table where course = '$_SESSION[course]' AND test_date ='$system_date' and test_type = 'Exam Re-sit'");
$query_max_time =mysql_result($query4, 0, "test_duration");

}






// RESULT ARITHMETIC

//Students score: Get the mark for each answer

$each_mark = $max_score / $query_max_questions ;

// Actual score

$actual_score = round ($score_right * $each_mark) ;


// Percent:

$score_percent = round(($actual_score / $max_score) * 100) ;



// SELECT THE CANDIDATE'S TEST ROOM

//$query4 =mysql_query("select test_room from candidate_login_table where reg_no = '$_SESSION[reg_no]' and course = '$_SESSION[course]'");
//$test_room =mysql_result($query4, 0, "test_room");




// RETRIEVE THE NUMBER OF ANSWERED QUESTIONS

$query =mysql_query("select count(question) from answered_questions where reg_no = '$_SESSION[reg_no]' and course = '$_SESSION[course]'");
$question_query =mysql_result($query, 0, "count(question)");
$question_count = $question_query ;



// EXTRACT SYSTEM DATE

$computer_date_day =date("d");
$computer_date_month =date("n");
$computer_date_year =date("Y");

$computer_date = date("d/n/Y");
}

// DETERMINE COMMENT

if (($score_percent) < 40)
{
$comment = "FAIL";
}
else
{
$comment = "PASS";
}


// DETERMINE GRADE
if(($score_percent) < 40)
{
$grade = "F";
}
elseif(($score_percent) >= 40 && ($score_percent) <= 44 )
{
$grade = "E";
}
elseif(($score_percent) >= 45 && ($score_percent) <= 49 )
{
$grade = "D";
}
elseif(($score_percent) >= 50 && ($score_percent) <= 59 )
{
$grade = "C";
}
elseif(($score_percent) >= 60 && ($score_percent) <= 69 )
{
$grade = "B";
}
else
{
$grade = "A";
}

// INSERT CANDIDATES SCORE AND DETAILS INTO TEST_RECORDS

$query  = "INSERT INTO test_records
              ( test_type, test_date, test_set_time , course , surname , first_name , reg_no ,  department , max_time , max_questions , no_answered , no_right, score , max_score, percentage , grade , comment, session, batch )";
			
   $query .= " VALUES
             ( '$_SESSION[test_type]','$test_date', '$query_datex1' , '$_SESSION[course]' , '$surname' , '$firstname' , '$_SESSION[reg_no]' , '$department' , '$query_max_time' , '$query_max_questions' , '$question_count'  , '$score_right', '$actual_score'  , '$max_score' , '$score_percent' , '$grade', '$comment','$SessionREg', '$batch')";
			 
			 $result = mysql_query($query);
		
		
	
	
// CALCULATE TOTAL SCORE, IF QUIZ

if (($_SESSION['test_type']) == 'Quiz')
{
include('dbconnect.php');


// Check if he has exam records
$check1 = "SELECT * FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'";
$resultcheck1 = mysql_query($check1);

$n_actual_score = 0 ;

if ((mysql_num_rows($resultcheck1)) > 0)
{
include('dbconnect.php');



//If there's an existing exam score, add it up to the Quiz score.
$query_no_passed = mysql_query("SELECT score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'exam'");
$n_actual_score = mysql_result($query_no_passed, 0, "score");
}

$total_score = $actual_score ;


//session_register("total_sc"); 
global $total_sc ;
$total_sc = $total_score ;

// DETERMINE TOTAL GRADE


if(($score_percent) < 40)
{
$total_grade = "F";
}
elseif(($score_percent ) >= 40 && ($score_percent ) <= 44 )
{
$total_grade = "E";
}
elseif(($score_percent ) >= 45 && ($score_percent ) <= 49 )
{
$total_grade = "D";
}
elseif(($score_percent ) >= 50 && ($score_percent) <= 59 )
{
$total_grade = "C";
}
elseif(($score_percent ) >= 60 && ($score_percent) <= 69 )
{
$total_grade = "B";
}
else
{
$total_grade = "A";
}
	

//$_SESSION['total_grade'] = $total_grade ;
//session_register("total_gr"); 
global $total_gr ;
$total_gr = $total_grade ;
	
}	
	



//If there's an exising Quiz score, add it to the Exam score
if (($_SESSION['test_type']) == 'Exam')
{
include('dbconnect.php');





$check1 = "SELECT * FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'";
$resultcheck1 = mysql_query($check1);

$n_actual_score = 0 ;

if ((mysql_num_rows($resultcheck1)) > 0)
{
include('dbconnect.php');



//If there's an existing exam score, add it up to the Quiz score.
$query_no_passed = mysql_query("SELECT score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
$n_actual_score = mysql_result($query_no_passed, 0, "score");
}
$total_score = $actual_score + $n_actual_score ;

global $total_score ;
session_register("total_score");

//$_SESSION['total_score'] = $total_score ;
//session_register("total_sc"); 



// DETERMINE TOTAL GRADE


if(($score_percent ) < 40)
{
$total_grade = "F";
}
elseif(($score_percent ) >= 40 && ($score_percent ) <= 44 )
{
$total_grade = "E";
}
elseif(($score_percent ) >= 45 && ($score_percent) <= 49 )
{
$total_grade = "D";
}
elseif(($score_percent ) >= 50 && ($score_percent) <= 59 )
{
$total_grade = "C";
}
elseif(($score_percent ) >= 60 && ($score_percent ) <= 69 )
{
$total_grade = "B";
}
else
{
$total_grade = "A";
}

//$_SESSION['total_grade'] = $total_grade ;	
//session_register("total_gr"); 

		
}
	
		
	





if (($_SESSION['test_type']) == 'Exam Re-sit')
{
include('dbconnect.php');




$total_score = $actual_score ;


//$_SESSION['total_score'] = $total_score ;
//session_register("total_sc"); 
global $total_sc ;
$total_sc = $total_score ;


// DETERMINE TOTAL GRADE


if(($score_percent ) < 40)
{
$total_grade = "F";
}
elseif(($score_percent ) >= 40 && ($score_percent ) <= 44 )
{
$total_grade = "E";
}
elseif(($score_percent ) >= 45 && ($score_percent ) <= 49 )
{
$total_grade = "D";
}
elseif(($score_percent ) >= 50 && ($score_percent ) <= 59 )
{
$total_grade = "C";
}
elseif(($score_percent) >= 60 && ($score_percent) <= 69 )
{
$total_grade = "B";
}
else
{
$total_grade = "A";
}
	
//$_SESSION['total_grade'] = $total_grade ;
//session_register("total_gr"); 
//$total_gr = $total_grade ;
global $total_gr ;
$total_gr = $total_grade ;
	
// INSERT THE TOTAL SCORE INTO THE COMPUTE_RESULTS TABLE


$query  = "INSERT INTO compute_results
              ( reg_no, course, test_type,  total, grade )";
			
$query .= " VALUES
             ( '$_SESSION[reg_no]', '$_SESSION[course]', '$_SESSION[test_type]', '$total_score' , '$grade'  )";	
	
	 $result = mysql_query($query);
		
}
	





		
			 
// UPDATE THE REGISTRATION TABLE TO INDICATE WHICH EXAMS THE CANDIDATE HAS SAT FOR

if(('$_SESSION[test_type]') == "Quiz")
{
$updatea = mysql_query("UPDATE registration_table SET quiz = 'Yes' WHERE reg_no ='$_SESSION[reg_no]'"); 
}



if(('$_SESSION[test_type]') == "Exam")
{
$updatea = mysql_query("UPDATE registration_table SET exam = 'Yes' WHERE reg_no ='$_SESSION[reg_no]'"); 
}



if(('$_SESSION[test_type]') == "Exam Re-sit")
{
$updatea = mysql_query("UPDATE registration_table SET exam_resit = 'Yes' WHERE reg_no ='$_SESSION[reg_no]'"); 
}



// COLLECT THE SCORE DETAILS VARIABLES

//Quiz
//--First checj if he has Exam records

$check1 = "SELECT * FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'";
$resultcheck1 = mysql_query($check1);


if ((mysql_num_rows($resultcheck1)) > 0)
{


$query_max_questions = mysql_query("SELECT max_questions FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
$total_questions = mysql_result($query_max_questions, 0, "max_questions");


$query_no_answered = mysql_query("SELECT no_answered FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
$no_attempted = mysql_result($query_no_answered, 0, "no_answered");


$query_max = mysql_query("SELECT max_score FROM candidate_login_table WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
$no_attempted = mysql_result($query_no_answered, 0, "no_answered");


$query_no_passed = mysql_query("SELECT no_right FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
$no_passed = mysql_result($query_no_passed, 0, "no_right");


$no_failed = $total_questions - $no_passed ;


$query_percentage = mysql_query("SELECT percentage FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
$qpercentage = mysql_result($query_percentage, 0, "percentage");

$query_grade = mysql_query("SELECT grade FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
$qgrade = mysql_result($query_grade, 0, "grade");
}






//Exam
//--First checj if he has Exam records

$check1 = "SELECT * FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'";
$resultcheck = mysql_query($check1);

if ((mysql_num_rows($resultcheck)) > 0)
{



$query_max_questions = mysql_query("SELECT max_questions FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$total_questions_exam = mysql_result($query_max_questions, 0, "max_questions");


$query_no_answered = mysql_query("SELECT no_answered FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$no_attempted_exam = mysql_result($query_no_answered, 0, "no_answered");


$query_no_passed = mysql_query("SELECT no_right FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$no_passed_exam = mysql_result($query_no_passed, 0, "no_right");

$query_no_actual = mysql_query("SELECT score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$actual_score_exam = mysql_result($query_no_actual, 0, "score");

$no_failed_exam = $total_questions_exam - $no_passed_exam ;


$query_percentage = mysql_query("SELECT percentage FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$qpercentage_exam = mysql_result($query_percentage, 0, "percentage");

$query_grade = mysql_query("SELECT grade FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$qgrade_exam = mysql_result($query_grade, 0, "grade");

}





//Exam Re-sit

//--First checj if he has Exam records

$check1 = "SELECT * FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam Re-sit'";
$resultcheck2 = mysql_query($check1);

if ((mysql_num_rows($resultcheck2)) > 0)
{

$query_max_questions = mysql_query("SELECT max_questions FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam Re-sit'");
$total_questions_resit = mysql_result($query_max_questions, 0, "max_questions");


$query_no_answered = mysql_query("SELECT no_answered FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam Re-sit'");
$no_attempted_resit = mysql_result($query_no_answered, 0, "no_answered");


$query_no_passed = mysql_query("SELECT no_right FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam Re-sit'");
$no_passed_resit = mysql_result($query_no_passed, 0, "no_right");

$query_no_actual = mysql_query("SELECT score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam Re-sit'");
$actual_score_resit = mysql_result($query_no_actual, 0, "score");


$no_failed_resit = $total_questions_resit - $no_passed_resit ;


$query_percentage = mysql_query("SELECT percentage FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam Re-sit'");
$qpercentage_resit = mysql_result($query_percentage, 0, "percentage");

$query_grade = mysql_query("SELECT grade FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam Re-sit'");
$qgrade_resit = mysql_result($query_grade, 0, "grade");
}





// CLEAN OUT THE DATA IN THE ANSWERED QUESTIONS TABLE BASED ON THE CANDIDATES REG NO AND COURSE

$query_clean = "DELETE FROM answered_questions WHERE reg_no = '$_SESSION[reg_no]' and course = '$_SESSION[course]'";
$result = mysql_query($query_clean);




 //////////////////////////////////////////////////////////////////////////////////////////////
 
  



// DELETE CANDIDATE LOGIN DETAILS FROM CANDIDATE_LOGIN_TABLE

//$delete = "DELETE FROM candidate_login_table WHERE reg_no = '$_SESSION[reg_no]' and course = '$_SESSION[course]'";
//$result_delete = mysql_query($delete);

// DELETE CANDIDATE LOGIN DETAILS FROM CLASSES

$delete2 = "DELETE FROM classes WHERE reg_no = '$_SESSION[reg_no]' and course = '$_SESSION[course]'";
$result_delete2 = mysql_query($delete2);


?>

<table width="100%" height="601" border="0" cellpadding="0" style="border-collapse: collapse">
	<tr>
		<td width="31" height="38" rowspan="2" bgcolor="#000000">&nbsp;</td>
		<td height="38" colspan="3" valign="middle" bgcolor="#000000"><div align="center"><form action="index.php" method="post" name="form1" target="_parent">
      <div align="right"> <u><b><font color="#CC99FF" size="5" face="Copperplate Gothic Bold">
        <input type="submit" name="Submit" value="Sign out">
      </font></b></u></div>
    </form> <br>
            <span class="style1">&nbsp;<span class="style2">TEST OVER </span></span> </div></td>
		<td width="32" rowspan="2" bgcolor="#000000">&nbsp;</td>
	</tr>
	<tr> 
	  <td height="33" colspan="3" bgcolor="#FFFFFF"><em><strong>
      <?php
	  if (($_SESSION['test_type']) == 'Quiz')

{
	  if (($score_percent) >= 40)
	  {
	  echo "<H1 align=center><font color = green><b> CONGRATULATIONS, YOU PASSED ! </b></font></h1>";
	  }
	  else
	  {
	   echo "<H1 align=center><font color = red><b> SORRY, YOU FAILED !! </b></font></h1>";
	  }
	  }


	 
	 
	 
	  if (($_SESSION['test_type']) == 'Exam')

{	  
$total_percent = ($total_score/100)* 100 ;



if (($total_percent) >= 40)
	  {
	  echo "<H2 align=center><font color = green><b> CONGRATULATIONS, YOU PASSED ! </b></font></h2>";
	  }
	  else
	  {
	   echo "<H2 align=center><font color = red><b> SORRY, YOU FAILED </b></font></h2>";
	  }
if(($total_percent ) < 40)
{
$grand_grade = "F";
}
elseif(($total_percent ) >= 40 && ($total_percent ) <= 44 )
{
$grand_grade = "E";
}
elseif(($total_percent ) >= 45 && ($total_percent ) <= 49 )
{
$grand_grade = "D";
}
elseif(($total_percent ) >= 50 && ($total_percent ) <= 59 )
{
$grand_grade = "C";
}
elseif(($total_percent) >= 60 && ($total_percent) <= 69 )
{
$grand_grade = "B";
}
else
{
$grand_grade = "A";
}	  
global $total_gr ;
$total_gr = $_grade ;
	
// INSERT THE TOTAL SCORE INTO THE COMPUTE_RESULTS TABLE


$query  = "INSERT INTO compute_results
              ( reg_no, course, test_type,  total, grade, total_grade )";
			
$query .= " VALUES
             ( '$_SESSION[reg_no]', '$_SESSION[course]', '$_SESSION[test_type]', '$total_score' , '$grade' , '$grand_grade'  )";	
	
	 $result = mysql_query($query);
		



}
	  ?>
&nbsp;</strong></em></td>
  </tr>
	<tr>
		<td width="31" height="467" bgcolor="#000000">&nbsp;</td>
		<td width="124"><p>&nbsp;</p>
		<p><br>
        <font face="Bodoni MT Black" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
		<br>
		</font><br>
&nbsp;</td>
		<td width="427" valign="top" background="images/scroll2.gif" bgcolor="#FFFFFF"><p>&nbsp;</p>
	    <p align="center"> <br>
	      <u><strong>THESE ARE THE QUESTIONS YOU FAILED </strong></u>	    </p>
	    <table width="80%" border="1" align="center">
          <tr bgcolor="#000000">
            <td width="25%" height="43"><span class="style8">Question No </span></td>
            <td width="60%"><span class="style7">QUESTION(S)</span></td>
            <td width="15%"><span class="style7">ANSWER</span></td>
          </tr>
          <tr>
		  <?php
		  ////////////////////////////////////////////
		  // GENERALLY, LETS PICK THE VARIABLES
		  /////////////////////////////////////////////
		  
		  //FOR QUIZ
		  


@$queryx = mysql_query("SELECT score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
@$actual_scorex = mysql_result($queryx, 0, "score");

@$queryx2 = mysql_query("SELECT max_score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Quiz'");
@$max_scorex = mysql_result($queryx2, 0, "max_score");

        
		// FOR EXAM
@$queryy2 = mysql_query("SELECT max_score FROM test_records WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
@$max_scorey = mysql_result($queryy2, 0, "max_score");


          // TOTAL GRADE
		  
		 if (($_SESSION['test_type']) == 'Quiz')
{
		 $grade_total = $qgrade;
		 }
		 else
		 {

$queryt = mysql_query("SELECT grade FROM compute_results WHERE course = '$_SESSION[course]' AND reg_no = '$_SESSION[reg_no]' AND test_type = 'Exam'");
$grade_total = mysql_result($queryt, 0, "grade");
          }

		  
		  ?>
            <td bgcolor="#006600">&nbsp;</td>
            <td><strong>
            <?php
			echo "$total_questions";
			?>
            &nbsp;</strong></td>
            <td>&nbsp;</td>
          </tr>
        </table>	    
	    <p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>        Your Total Score</strong> = <?php echo "$total_score"; ?><br>
	     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Grade = </strong> 
		 <?php echo "$grand_grade";?><br>
		 <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Course = </strong><?php
		  echo "$_SESSION[course]";
		  
		  ?></p>
      <p align="left">&nbsp;  </p></td>
		<td width="124">&nbsp;</td>
		<td width="32" bgcolor="#000000">&nbsp;</td>
	</tr>
	<tr>
		
    <td width="31" height="46" bgcolor="#000000">&nbsp;</td>
		
    <td height="46" colspan="3" bgcolor="#000000">  </td>
		<td width="32" bgcolor="#000000">&nbsp;</td>
	</tr>
</table>

</body>

</html>
<?php
}

?>
<?php

session_destroy();
{

}
?>