<?php
include('dbconnect.php');

$first = mysql_query("SELECT count(semester) FROM `registration_table` WHERE `semester`='FIRST'");
$n_first = mysql_result($first,0, "count(semester)");

$second = mysql_query("SELECT count(semester) FROM `registration_table` WHERE `semester`='SECOND'");
$n_second = mysql_result($second,0, "count(semester)");


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Upgrade Semester::</title>
<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
}
.style2 {
	color: #00FF00;
	font-weight: bold;
}
.style3 {color: #00FF00; font-weight: bold; font-size: 14px; }
.style4 {color: #00FF00; font-weight: bold; font-size: 18px; }
#Layer1 {
	position:absolute;
	width:38px;
	height:34px;
	z-index:1;
	left: 408px;
	top: 204px;
}
#Layer2 {
	position:absolute;
	width:33px;
	height:35px;
	z-index:2;
	left: 526px;
	top: 204px;
}
-->
</style>
</head>

<body>
<table width="849" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0033CC">
  <!--DWLayoutTable-->
  <tr>
    <td width="208" height="38"><div id="Layer2"><strong><?php echo $n_second;?></strong></div></td>
    <td width="439" align="center" valign="top"><p class="style2">&nbsp;</p>
      <p class="style2">This allows you upgrade to a new semester for all students. Please choose whether you are upgrading from first semester to second semester or vice versa.</p>
      <p class="style4">CURRENT REGISTERED STUDENTS</p>
      <p class="style3">First Semester | Second Semester</p>
      <div id="Layer1"><strong><?php echo $n_first;?></strong></div>      
    <p class="style2">&nbsp;  </p></td>
    <td width="202"></td>
  </tr>
  <tr>
    <td height="16"></td>
    <td></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="160"></td>
    <td valign="top" bgcolor="#CC99FF"><fieldset>
    <legend class="style1">First Semester</legend>
      <p>This Upgrades all first semester students to second semester automatically. Please click on the button to carry out this action.</p>
      <form id="form1" name="form1" method="post" action="upgrade_first.php">
        <label></label>
        <div align="center">
          <input type="submit" name="Submit" value="Upgrade" align="centre" />
        </div>
      </form>
      <p>&nbsp;</p>
    </fieldset></td>
    <td></td>
  </tr>
  <tr>
    <td height="25"></td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  
  <tr>
    <td height="161"></td>
    <td valign="top" bgcolor="#CC99FF"><fieldset>
    <legend class="style1">Second Semester</legend>
    <p>This Upgrades all second semester students to first semester automatically. Please click on the button to carry out this action.</p>
    <form id="form1" name="form1" method="post" action="upgrade_second.php">
      <label></label>
      <div align="center">
        <input type="submit" name="Submit2" value="Upgrade" align="centre" />
      </div>
    </form>
    <p>&nbsp;</p>
    </fieldset></td>
    <td></td>
  </tr>
  <tr>
    <td height="25"></td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="161"></td>
    <td valign="top" bgcolor="#CC99FF"><fieldset>
    <legend class="style1">By Programme </legend>
    <p>This upgrades based on programme. Please input the department and which semester you intend to upgrade. </p>
    <form id="form1" name="form1" method="post" action="upgrade_programme.php">
      <label></label>
      <div align="center">
        <table width="269">
          <tr>
            <td width="138"><strong>Programme</strong></td>
            <td width="119"><select name="course" id="course" tabindex="13">
              <option>UMITT</option>
                        </select></td>
          </tr>
          <tr>
            <td><strong>Semester</strong></td>
            <td><select name="semester" id="semester" tabindex="13">
              <option>FIRST</option>
              <option>SECOND</option>
            </select></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
            </tr>
          <tr>
            <td colspan="2"><input name="Submit" type="submit" id="Submit" value="Upgrade" align="centre" /></td>
            </tr>
        </table>
        </div>
    </form>
    <p>&nbsp;</p>
    </fieldset></td>
    <td></td>
  </tr>
  <tr>
    <td height="25"></td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="161"></td>
    <td valign="top" bgcolor="#CC99FF"><fieldset>
    <legend class="style1">Student Upgrade </legend>
    <p>This Upgrades an individual student. Please input the student's registration number to upgrade to a new semester. </p>
    <form id="form1" name="form1" method="post" action="upgrade_student.php">
      <label></label>
      <div align="center">
        <table width="353">
          <tr>
            <td width="160"><strong>Registration Number</strong> </td>
            <td width="181"><label>
              <input name="reg_no" type="text" id="reg_no" />
            </label></td>
          </tr>

          <tr>
            <td><strong>Semester</strong></td>
            <td><select name="semester" id="semester" tabindex="13">
              <option>FIRST</option>
              <option>SECOND</option>
            </select></td>
          </tr>
          <tr>
            <td colspan="2"><input name="Submit3" type="submit" id="Submit2" value="Upgrade" align="centre" /></td>
          </tr>
        </table>
      </div>
    </form>
    <p>&nbsp;</p>
    </fieldset></td>
    <td></td>
  </tr>
  <tr>
    <td height="15"></td>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>
